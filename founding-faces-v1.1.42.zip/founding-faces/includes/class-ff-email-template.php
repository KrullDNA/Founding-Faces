<?php
/**
 * The branded HTML email shell.
 *
 * Every programme email, welcome, promotion, password reset, application
 * received, is wrapped in one consistent, on-brand HTML layout: an optional
 * logo, a heading, the message body, an optional call-to-action button, and a
 * footer. The colours, logo and footer text are editable in Settings, so the
 * whole look can be tuned without touching code.
 *
 * Email HTML is deliberately old-fashioned: tables and inline styles, because
 * that is what mail clients (Outlook especially) reliably render.
 *
 * @package FoundingFaces
 */

// Stop anyone loading this file directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class FF_Email_Template
 */
class FF_Email_Template {

	// Editable design options.
	const OPT_LOGO         = 'ff_email_logo';          // Logo image URL, above the card.
	const OPT_LOGO_WIDTH   = 'ff_email_logo_width';    // How wide the logo is drawn, in pixels.
	const OPT_ACCENT       = 'ff_email_accent';        // Link colour in the body.
	const OPT_HEADING_BG   = 'ff_email_heading_bg';    // The heading band's fill.
	const OPT_HEADING_TEXT = 'ff_email_heading_text';  // The heading's own colour.
	const OPT_HEADING_SIZE   = 'ff_email_heading_size';    // Heading size, in pixels.
	const OPT_HEADING_WEIGHT = 'ff_email_heading_weight';  // Heading weight.
	const OPT_BG           = 'ff_email_bg';            // Page background behind the card.
	const OPT_BUTTON_BG    = 'ff_email_button_bg';     // CTA button background.
	const OPT_BUTTON_TEXT  = 'ff_email_button_text';   // CTA button text colour.
	const OPT_FOOTER       = 'ff_email_footer';        // Footer text, inside the card.
	const OPT_DISCLAIMER   = 'ff_email_disclaimer';    // Small print, below the card.

	/**
	 * The shipped design defaults.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			self::OPT_LOGO         => '',
			self::OPT_LOGO_WIDTH   => 240,
			self::OPT_ACCENT       => '#2b2d33',
			self::OPT_HEADING_BG   => '#2b2d33',
			self::OPT_HEADING_TEXT => '#ffffff',
			self::OPT_HEADING_SIZE   => 26,
			self::OPT_HEADING_WEIGHT => 700,
			self::OPT_BG           => '#f6f7f8',
			self::OPT_BUTTON_BG    => '#3a3d44',
			self::OPT_BUTTON_TEXT  => '#ffffff',
			self::OPT_FOOTER       => get_bloginfo( 'name' ),
			self::OPT_DISCLAIMER   => self::default_disclaimer(),
		);
	}

	/**
	 * The shipped small print.
	 *
	 * @return string
	 */
	public static function default_disclaimer() {
		return __(
			'This message was sent as part of the Founding Faces programme, between {site_name} and the addressee named above. If it has reached you by mistake, we would be grateful if you told us, deleted it from your mailbox, and did not forward it or any part of it to anyone else. Thank you for your understanding.',
			'founding-faces'
		);
	}

	/**
	 * Read a single design option, falling back to its default.
	 *
	 * @param string $key One of the OPT_* constants.
	 * @return string
	 */
	public static function option( $key ) {
		$defaults = self::defaults();
		$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
		$value    = get_option( $key, $default );
		return ( '' === $value || null === $value ) ? $default : $value;
	}

	/**
	 * Build a complete branded HTML email.
	 *
	 * @param array $args {
	 *     @type string $heading   The large heading at the top of the card.
	 *     @type string $body_html The message body, already valid HTML.
	 *     @type array  $cta         Optional ['label' => string, 'url' => string].
	 *     @type string $preheader   Optional hidden preview line.
	 *     @type string $unsubscribe Optional unsubscribe URL. The link only
	 *                               appears when one is given, so an applicant
	 *                               who has no account is never offered a way
	 *                               out of a list they are not on.
	 * }
	 * @return string The full HTML document.
	 */
	public static function build( $args ) {
		$heading   = isset( $args['heading'] ) ? $args['heading'] : '';
		$body_html = isset( $args['body_html'] ) ? $args['body_html'] : '';
		$cta       = isset( $args['cta'] ) && is_array( $args['cta'] ) ? $args['cta'] : array();
		$preheader = isset( $args['preheader'] ) ? $args['preheader'] : '';
		$unsub     = isset( $args['unsubscribe'] ) ? $args['unsubscribe'] : '';

		$logo      = self::option( self::OPT_LOGO );
		$logo_w    = max( 40, (int) self::option( self::OPT_LOGO_WIDTH ) );
		$accent    = self::option( self::OPT_ACCENT );
		$head_bg   = self::option( self::OPT_HEADING_BG );
		$head_text = self::option( self::OPT_HEADING_TEXT );
		$head_size = max( 12, (int) self::option( self::OPT_HEADING_SIZE ) );
		$head_wt   = max( 100, (int) self::option( self::OPT_HEADING_WEIGHT ) );
		$bg        = self::option( self::OPT_BG );
		$btn_bg    = self::option( self::OPT_BUTTON_BG );
		$btn_text  = self::option( self::OPT_BUTTON_TEXT );
		$footer    = self::option( self::OPT_FOOTER );

		$site = get_bloginfo( 'name' );

		// The small print takes {site_name} so it needs no editing between
		// staging and live.
		$disclaimer = strtr(
			(string) self::option( self::OPT_DISCLAIMER ),
			array( '{site_name}' => $site )
		);

		// No quoted font names anywhere in the stack. A quoted name inside an
		// inline style attribute has to survive being escaped, re-escaped and
		// decoded again on its way to a preview pane or a mail client, and if it
		// doesn't the whole font-family declaration is thrown away and the email
		// lands in the reader's default serif. Montserrat, then Arial, needs no
		// quotes at all.
		$family = 'Montserrat, Arial, Helvetica, sans-serif';

		// Montserrat has to be fetched, because mail clients don't embed fonts.
		// Apple Mail, iOS Mail and Samsung Mail honour the link; Gmail and
		// Outlook ignore it and fall to Arial, which is the point of the stack.
		$font_css = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap';

		ob_start();
		?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="color-scheme" content="light only" />
	<title><?php echo esc_html( $heading ? $heading : $site ); ?></title>
	<!--[if !mso]><!-->
	<link href="<?php echo esc_url( $font_css ); ?>" rel="stylesheet" type="text/css" />
	<style type="text/css">
		@import url('<?php echo esc_url( $font_css ); ?>');
		body, table, td, p, a, span, h1, li { font-family: <?php echo esc_html( $family ); ?>; }
		/* Links in the body take the heading colour. The button sets its own
		   colour inline, which wins over this. */
		a { color: <?php echo esc_html( $accent ); ?>; }

		/* A long word or address can't be allowed to force the card wider than
		   the screen. When that happens a phone shrinks the whole email to fit,
		   which is what makes every word too small to read. */
		td, p, a, li { word-break: break-word; }

		/* On a phone the card takes the full width and the generous desktop
		   padding comes in, so the words have somewhere to go. The body text
		   goes up rather than down: a phone is held closer but read faster. */
		@media only screen and (max-width: 620px) {
			.ff-pad { padding-left: 22px !important; padding-right: 22px !important; }
			.ff-band { padding: 26px 22px !important; }
			.ff-body { font-size: 16px !important; line-height: 1.7 !important; }
			.ff-foot { font-size: 13px !important; }
			.ff-small { font-size: 12px !important; }
			.ff-btn-table { width: 100% !important; }
			.ff-btn { display: block !important; text-align: center !important; }
		}
	</style>
	<!--<![endif]-->
	<!--[if mso]>
	<style type="text/css">
		body, table, td, p, a, span, h1, li {
			font-family: Arial, Helvetica, sans-serif !important;
		}
	</style>
	<![endif]-->
</head>
<body style="margin:0; padding:0; width:100%; background:<?php echo esc_attr( $bg ); ?>; font-family:<?php echo esc_attr( $family ); ?>; color:#2b2d33; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%;">
	<?php if ( '' !== trim( (string) $preheader ) ) : ?>
		<div style="display:none; max-height:0; overflow:hidden; opacity:0;"><?php echo esc_html( $preheader ); ?></div>
	<?php endif; ?>
	<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:<?php echo esc_attr( $bg ); ?>;">
		<tr>
			<td align="center" style="padding:28px 16px;">
				<?php
				// Outlook ignores max-width, so without this it would draw the
				// card at whatever width the window happens to be. Everything
				// else uses max-width and stays fluid, which is what stops a
				// phone shrinking the whole email to make a 600px card fit.
				?>
				<!--[if mso]><table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0"><tr><td><![endif]-->

				<?php if ( '' !== trim( (string) $logo ) ) : ?>
				<!-- The logo sits above the card, on the page, not inside it. -->
				<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%; max-width:600px;">
					<tr>
						<td align="center" style="padding:0 16px 26px;">
							<?php
						// The width is given as an attribute as well as a style:
						// Outlook ignores the style and would otherwise draw the
						// logo at whatever size the file happens to be.
						?>
						<img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $site ); ?>" width="<?php echo esc_attr( $logo_w ); ?>" style="width:<?php echo esc_attr( $logo_w ); ?>px; max-width:80%; height:auto; display:block; border:0;" />
						</td>
					</tr>
				</table>
				<?php endif; ?>

				<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%; max-width:600px; background:#ffffff; border-radius:10px; overflow:hidden;">
					<?php if ( '' !== trim( (string) $heading ) ) : ?>
					<!-- The heading band: its own fill, its own text colour, full
					     width of the card. -->
					<tr>
						<td align="center" class="ff-band" bgcolor="<?php echo esc_attr( $head_bg ); ?>" style="padding:34px 32px; background:<?php echo esc_attr( $head_bg ); ?>;">
							<h1 style="margin:0; font-family:<?php echo esc_attr( $family ); ?>; font-size:<?php echo esc_attr( $head_size ); ?>px; line-height:1.25; font-weight:<?php echo esc_attr( $head_wt ); ?>; color:<?php echo esc_attr( $head_text ); ?>;">
								<?php echo esc_html( $heading ); ?>
							</h1>
						</td>
					</tr>
					<?php endif; ?>
					<tr>
						<td class="ff-pad ff-body" style="padding:34px 40px 4px; font-family:<?php echo esc_attr( $family ); ?>; font-size:15px; line-height:1.7; color:#2b2d33;">
							<?php echo $body_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Body is pre-built, escaped HTML. ?>
						</td>
					</tr>
					<?php if ( ! empty( $cta['url'] ) && ! empty( $cta['label'] ) ) : ?>
					<tr>
						<td class="ff-pad" style="padding:12px 40px 8px;">
							<table role="presentation" cellpadding="0" cellspacing="0" class="ff-btn-table">
								<tr>
									<td align="center" bgcolor="<?php echo esc_attr( $btn_bg ); ?>" style="border-radius:6px; background:<?php echo esc_attr( $btn_bg ); ?>;">
										<a href="<?php echo esc_url( $cta['url'] ); ?>" class="ff-btn" style="display:inline-block; padding:13px 28px; font-family:<?php echo esc_attr( $family ); ?>; font-size:15px; font-weight:600; color:<?php echo esc_attr( $btn_text ); ?>; text-decoration:none; border-radius:6px;">
											<?php echo esc_html( $cta['label'] ); ?>
										</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<?php endif; ?>
					<?php if ( '' !== trim( (string) $footer ) ) : ?>
					<tr>
						<td align="center" class="ff-pad" style="padding:18px 40px 34px;">
							<p class="ff-foot" style="margin:0; font-family:<?php echo esc_attr( $family ); ?>; font-size:13px; line-height:1.6; color:#6b7280; text-align:center;">
								<?php echo nl2br( esc_html( $footer ) ); ?>
							</p>
						</td>
					</tr>
					<?php endif; ?>
				</table>

				<?php if ( '' !== trim( (string) $disclaimer ) || '' !== trim( (string) $unsub ) ) : ?>
				<!-- The small print and the way out, below the card. -->
				<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%; max-width:600px;">
					<?php if ( '' !== trim( (string) $disclaimer ) ) : ?>
					<tr>
						<td align="center" style="padding:20px 24px 0;">
							<p class="ff-small" style="margin:0; font-family:<?php echo esc_attr( $family ); ?>; font-size:11px; line-height:1.55; color:#8a9099; text-align:center;">
								<?php echo nl2br( esc_html( $disclaimer ) ); ?>
							</p>
						</td>
					</tr>
					<?php endif; ?>
					<?php if ( '' !== trim( (string) $unsub ) ) : ?>
					<tr>
						<td align="center" style="padding:14px 24px 8px;">
							<a href="<?php echo esc_url( $unsub ); ?>" class="ff-small" style="font-family:<?php echo esc_attr( $family ); ?>; font-size:11px; line-height:1.55; color:#8a9099; text-decoration:underline;">
								<?php esc_html_e( 'Unsubscribe', 'founding-faces' ); ?>
							</a>
						</td>
					</tr>
					<?php endif; ?>
				</table>
				<?php endif; ?>

				<!--[if mso]></td></tr></table><![endif]-->

			</td>
		</tr>
	</table>
</body>
</html>
		<?php
		return ob_get_clean();
	}
}
