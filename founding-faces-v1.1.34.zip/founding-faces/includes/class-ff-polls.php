<?php
/**
 * Polls: the poll content type, the admin editor and who-voted view, the
 * front-end voting logic, and the aggregate results.
 *
 * A poll is a question plus two or more options, each of which can carry an
 * image. Nick chooses the audience per poll and whether it's open or closed.
 * Votes are stored against the member in ff_poll_votes and logged to the
 * interaction spine; the front end only ever shows aggregates, while an
 * admin-only view shows exactly who voted for what.
 *
 * @package FoundingFaces
 */

// Stop anyone loading this file directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class FF_Polls
 *
 * Owns the ff_poll post type, its meta, voting and results.
 */
class FF_Polls {

	// The poll post type slug.
	const POLL_CPT = 'ff_poll';

	// Poll meta keys.
	const META_OPTIONS  = 'ff_poll_options';   // Array of ['id','label','image_id'].
	const META_AUDIENCE = 'ff_poll_audience';  // 'everyone' | 'the-35-only'.
	const META_STATUS   = 'ff_poll_status';    // 'open' | 'closed' | 'hidden'.
	const META_ACTIVE   = 'ff_poll_active';    // 1 if this is the current active poll.
	const META_OUTCOME  = 'ff_poll_outcome';   // Nick's reasoning, shown on close.
	const META_CLOSE_AT = 'ff_poll_close_at';  // GMT Unix time to auto-close (show results), or 0.
	const META_HIDE_AT  = 'ff_poll_hide_at';   // GMT Unix time to auto-hide entirely, or 0.
	const META_TAG      = 'ff_poll_tag';       // The label voters carry on the email platform.

	// The AJAX action name for casting a vote.
	const VOTE_ACTION = 'ff_vote';

	/**
	 * Wire up the post type, shortcode and voting endpoint.
	 */
	public static function register() {
		// Register the poll post type now. This runs on 'init' (register() is
		// called from the plugin's own init handler), so we register directly
		// rather than nesting another 'init' hook, a nested same-priority hook
		// added mid-'init' isn't reliably run, which could hide the Polls menu.
		self::register_cpt();
		add_shortcode( 'ff_poll', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'ff_polls_archive', array( __CLASS__, 'archive_shortcode' ) );

		// Voting is by logged-in members only, so only the priv handler is used.
		add_action( 'wp_ajax_' . self::VOTE_ACTION, array( __CLASS__, 'ajax_vote' ) );

		// Make the poll title field prompt for the question.
		add_filter( 'enter_title_here', array( __CLASS__, 'title_placeholder' ), 10, 2 );

		// Register the Elementor widget (harmless if Elementor isn't installed).
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widget' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
	}

	/**
	 * Register the Founding Faces widget category in Elementor.
	 *
	 * @param object $elements_manager Elementor's elements manager.
	 */
	public static function register_category( $elements_manager ) {
		$elements_manager->add_category( 'founding-faces', array(
			'title' => __( 'Founding Faces', 'founding-faces' ),
			'icon'  => 'fa fa-plug',
		) );
	}

	/**
	 * Register the poll widget with Elementor.
	 *
	 * @param object $widgets_manager Elementor's widgets manager.
	 */
	public static function register_widget( $widgets_manager ) {
		require_once FF_PATH . 'includes/class-ff-poll-widget.php';
		$widgets_manager->register( new FF_Poll_Widget() );
		$widgets_manager->register( new FF_Polls_Archive_Widget() );
	}

	/**
	 * Get all polls as id => question, for the widget's poll picker.
	 *
	 * @return array
	 */
	public static function poll_choices() {
		$choices = array( 0 => __( 'Current active poll', 'founding-faces' ) );
		$polls   = get_posts( array(
			'post_type'      => self::POLL_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		) );
		foreach ( $polls as $poll ) {
			$choices[ $poll->ID ] = $poll->post_title ? $poll->post_title : sprintf( __( 'Poll #%d', 'founding-faces' ), $poll->ID );
		}
		return $choices;
	}

	/**
	 * Wire up the admin editor and results metaboxes.
	 *
	 * Called in the admin area only.
	 */
	public static function register_admin() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metaboxes' ) );
		add_action( 'save_post_' . self::POLL_CPT, array( __CLASS__, 'save_poll' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin' ) );

		// The polls list, so a poll that is not on the site says so here
		// rather than leaving you hunting for it on the page.
		add_filter( 'manage_' . self::POLL_CPT . '_posts_columns', array( __CLASS__, 'poll_columns' ) );
		add_action( 'manage_' . self::POLL_CPT . '_posts_custom_column', array( __CLASS__, 'poll_column' ), 10, 2 );
	}

	/**
	 * How many votes a poll has had, in total.
	 *
	 * A count, never a list. Who voted for what is the member's own and is
	 * read nowhere but their own page.
	 *
	 * @param int $poll_id The poll.
	 * @return int
	 */
	public static function total_votes( $poll_id ) {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}ff_poll_votes WHERE poll_id = %d",
			absint( $poll_id )
		) );
	}

	/**
	 * Add a state column to the polls list.
	 *
	 * @param array $columns The existing columns.
	 * @return array
	 */
	public static function poll_columns( $columns ) {
		$out = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'title' === $key ) {
				$out['ff_state'] = __( 'On the site', 'founding-faces' );
				$out['ff_votes'] = __( 'Votes', 'founding-faces' );
			}
		}
		return $out;
	}

	/**
	 * Fill the state and votes columns.
	 *
	 * @param string $column  The column key.
	 * @param int    $post_id The poll.
	 */
	public static function poll_column( $column, $post_id ) {
		if ( 'ff_votes' === $column ) {
			echo esc_html( (string) self::total_votes( $post_id ) );
			return;
		}

		if ( 'ff_state' !== $column ) {
			return;
		}

		$state  = self::poll_state( $post_id );
		$labels = array(
			'open'   => __( 'Open, taking votes', 'founding-faces' ),
			'closed' => __( 'Closed, in past polls', 'founding-faces' ),
			'hidden' => __( 'Hidden, not on the site', 'founding-faces' ),
		);

		echo esc_html( isset( $labels[ $state ] ) ? $labels[ $state ] : $state );

		// Why, and a date beats the dropdown, so the date is what gets said.
		// A poll taken off the site by a schedule somebody set months ago is
		// the one state that is impossible to work out from the poll screen.
		$close_at = (int) get_post_meta( $post_id, self::META_CLOSE_AT, true );
		$hide_at  = (int) get_post_meta( $post_id, self::META_HIDE_AT, true );
		$now      = time();
		$reason   = '';

		if ( 'hidden' === $state && $hide_at > 0 && $now >= $hide_at ) {
			$reason = sprintf(
				/* translators: %s is a date and time. */
				__( 'auto-hidden on %s. Clear the auto-hide time to bring it back.', 'founding-faces' ),
				wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $hide_at )
			);
		} elseif ( 'closed' === $state && $close_at > 0 && $now >= $close_at ) {
			$reason = sprintf(
				/* translators: %s is a date and time. */
				__( 'auto-closed on %s', 'founding-faces' ),
				wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $close_at )
			);
		}

		if ( '' !== $reason ) {
			echo '<br /><span class="ff-consent">' . esc_html( $reason ) . '</span>';
		}
	}

	/**
	 * The tag a voter carries for this poll.
	 *
	 * Built from the poll's own words rather than its id, because "poll-14"
	 * means nothing in a segment builder six months later and
	 * "poll-packaging-colour" means exactly what it says. The wording can be
	 * set on the poll itself; left empty it comes from the title.
	 *
	 * Capped at a sensible length, and not for tidiness: Campaign Monitor's
	 * text fields hold 250 characters, all the tags share one of them, and a
	 * question written out in full eats a fifth of that on its own.
	 *
	 * @param int $poll_id The poll.
	 * @return string
	 */
	public static function poll_tag( $poll_id ) {
		$custom = trim( (string) get_post_meta( $poll_id, self::META_TAG, true ) );

		if ( '' !== $custom ) {
			$slug = sanitize_title( $custom );
		} else {
			$post = get_post( $poll_id );
			$slug = ( $post && '' !== $post->post_name ) ? $post->post_name : sanitize_title( get_the_title( $poll_id ) );
		}

		// Cut at a word rather than mid-syllable, and say which poll it was if
		// the cut lost enough to make two polls look alike.
		if ( strlen( $slug ) > 40 ) {
			$cut  = substr( $slug, 0, 40 );
			$last = strrpos( $cut, '-' );
			$slug = ( false !== $last && $last > 20 ) ? substr( $cut, 0, $last ) : $cut;
			$slug = trim( $slug, '-' ) . '-' . (int) $poll_id;
		}

		return 'poll-' . ( '' !== $slug ? $slug : (int) $poll_id );
	}

	/**
	 * Register the poll post type.
	 *
	 * Non-public and out of REST, like notes and products: polls reach a page
	 * only through the widget or shortcode, and the audience gate is enforced
	 * there.
	 */
	public static function register_cpt() {
		$labels = array(
			'name'          => __( 'Polls', 'founding-faces' ),
			'singular_name' => __( 'Poll', 'founding-faces' ),
			'add_new_item'  => __( 'Add New Poll', 'founding-faces' ),
			'edit_item'     => __( 'Edit Poll', 'founding-faces' ),
			'new_item'      => __( 'New Poll', 'founding-faces' ),
			'all_items'     => __( 'Polls', 'founding-faces' ),
			'menu_name'     => __( 'Polls', 'founding-faces' ),
		);

		register_post_type( self::POLL_CPT, array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_icon'           => 'dashicons-chart-bar',
			'menu_position'       => 28,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
			'has_archive'         => false,
			'rewrite'             => false,
			'supports'            => array( 'title' ),
			'show_in_rest'        => false,
		) );
	}

	/**
	 * Use the poll title field to ask for the question.
	 *
	 * @param string  $text The default placeholder.
	 * @param WP_Post $post The post being edited.
	 * @return string
	 */
	public static function title_placeholder( $text, $post ) {
		if ( $post && self::POLL_CPT === $post->post_type ) {
			return __( 'Poll question', 'founding-faces' );
		}
		return $text;
	}

	/*
	 * -----------------------------------------------------------------------
	 * Audience gate.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * The audiences a poll can target.
	 *
	 * @return array
	 */
	public static function audiences() {
		return array(
			'everyone'    => __( 'Everyone (all members)', 'founding-faces' ),
			'the-35-only' => __( 'The 35 only', 'founding-faces' ),
		);
	}

	/**
	 * Whether a user may see and vote on a poll.
	 *
	 * @param int      $poll_id The poll id.
	 * @param int|null $user_id A user id, or null for the current user.
	 * @return bool
	 */
	public static function can_view_poll( $poll_id, $user_id = null ) {
		if ( ! FF_Gating::is_member( $user_id ) ) {
			return false;
		}
		$audience = get_post_meta( $poll_id, self::META_AUDIENCE, true );
		if ( 'the-35-only' === $audience ) {
			return FF_Gating::is_the_35( $user_id );
		}
		return true;
	}

	/*
	 * -----------------------------------------------------------------------
	 * Voting and results (data).
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Whether a member has already voted on a poll.
	 *
	 * @param int $poll_id   The poll id.
	 * @param int $member_id The member id.
	 * @return bool
	 */
	public static function has_voted( $poll_id, $member_id ) {
		global $wpdb;
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}ff_poll_votes WHERE poll_id = %d AND member_id = %d LIMIT 1",
				$poll_id,
				$member_id
			)
		);
		return null !== $found;
	}

	/**
	 * The option id a member voted for, or 0 if they haven't voted.
	 *
	 * @param int $poll_id   The poll id.
	 * @param int $member_id The member id.
	 * @return int
	 */
	public static function member_vote( $poll_id, $member_id ) {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT option_id FROM {$wpdb->prefix}ff_poll_votes WHERE poll_id = %d AND member_id = %d LIMIT 1",
				$poll_id,
				$member_id
			)
		);
	}

	/**
	 * The aggregate tally for a poll: option id => vote count.
	 *
	 * @param int $poll_id The poll id.
	 * @return array
	 */
	public static function tally( $poll_id ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT option_id, COUNT(*) AS votes FROM {$wpdb->prefix}ff_poll_votes WHERE poll_id = %d GROUP BY option_id",
				$poll_id
			)
		);
		$tally = array();
		foreach ( $rows as $row ) {
			$tally[ (int) $row->option_id ] = (int) $row->votes;
		}
		return $tally;
	}

	/**
	 * Record a member's vote and log it to the spine.
	 *
	 * Guards against a second vote via the pre-check and the table's unique key.
	 *
	 * @param int $poll_id   The poll id.
	 * @param int $member_id The member id.
	 * @param int $option_id The chosen option id.
	 * @return true|WP_Error
	 */
	public static function record_vote( $poll_id, $member_id, $option_id ) {
		global $wpdb;

		if ( self::has_voted( $poll_id, $member_id ) ) {
			return new WP_Error( 'ff_already_voted', __( 'You have already voted in this poll.', 'founding-faces' ) );
		}

		$inserted = $wpdb->insert(
			$wpdb->prefix . 'ff_poll_votes',
			array(
				'member_id' => $member_id,
				'poll_id'   => $poll_id,
				'option_id' => $option_id,
				'voted_at'  => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%d', '%s' )
		);

		if ( ! $inserted ) {
			return new WP_Error( 'ff_vote_failed', __( 'Your vote could not be recorded. Please try again.', 'founding-faces' ) );
		}

		// The spine: a vote cast, attributed to the member and the poll.
		FF_Interactions::log( $member_id, 'vote_cast', $poll_id );

		// Two labels, because both questions get asked: who votes at all, and
		// who voted in this particular poll.
		FF_Members::add_tag( $member_id, 'voted' );
		FF_Members::add_tag( $member_id, self::poll_tag( $poll_id ) );

		return true;
	}

	/**
	 * A member's own poll votes, newest first.
	 *
	 * Reads only this member's rows from ff_poll_votes.
	 *
	 * @param int $member_id The member's user id.
	 * @return array Rows of poll_id, option_id, voted_at.
	 */
	public static function member_votes( $member_id ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT poll_id, option_id, voted_at FROM {$wpdb->prefix}ff_poll_votes WHERE member_id = %d ORDER BY voted_at DESC",
				(int) $member_id
			)
		);
	}

	/**
	 * The label of a specific option within a poll.
	 *
	 * @param int $poll_id   The poll id.
	 * @param int $option_id The option id.
	 * @return string The label, or an empty string if not found.
	 */
	public static function option_label( $poll_id, $option_id ) {
		foreach ( self::get_options( $poll_id ) as $opt ) {
			if ( (int) $opt['id'] === (int) $option_id ) {
				return $opt['label'];
			}
		}
		return '';
	}

	/**
	 * The id of the current active poll, or 0 if none.
	 *
	 * @return int
	 */
	public static function get_active_poll_id() {
		$ids = get_posts( array(
			'post_type'      => self::POLL_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
			'meta_key'       => self::META_ACTIVE, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		return empty( $ids ) ? 0 : (int) $ids[0];
	}

	/**
	 * The effective state of a poll: 'open', 'closed' (results shown), or 'hidden'.
	 *
	 * Combines the manual Status with the optional scheduled close/hide times:
	 *  - Past the hide time  -> hidden (gone from the site).
	 *  - Manually closed with NO close/hide times set -> hidden immediately.
	 *  - Past the close time, or manually closed with a time set -> closed
	 *    (results and reasoning shown, until the hide time passes).
	 *  - Otherwise -> open (accepting votes).
	 *
	 * @param int $poll_id The poll id.
	 * @return string 'open' | 'closed' | 'hidden'.
	 */
	public static function poll_state( $poll_id ) {
		$now      = time();
		$close_at = (int) get_post_meta( $poll_id, self::META_CLOSE_AT, true );
		$hide_at  = (int) get_post_meta( $poll_id, self::META_HIDE_AT, true );
		$status   = (string) get_post_meta( $poll_id, self::META_STATUS, true );

		// Taken off the site by hand, whatever the dates say.
		if ( 'hidden' === $status ) {
			return 'hidden';
		}

		if ( $hide_at > 0 && $now >= $hide_at ) {
			return 'hidden';
		}

		// Closed by hand is closed, and stays in the past polls. Hiding it is
		// a separate choice, made in the same dropdown, because a poll that
		// vanished the moment it closed used to be the only way to close one,
		// and nobody could tell the difference between that and a bug.
		if ( 'closed' === $status ) {
			return 'closed';
		}

		return ( $close_at > 0 && $now >= $close_at ) ? 'closed' : 'open';
	}

	/**
	 * Whether a poll is showing results (its effective state is 'closed').
	 *
	 * @param int $poll_id The poll id.
	 * @return bool
	 */
	public static function is_closed( $poll_id ) {
		return 'closed' === self::poll_state( $poll_id );
	}

	/**
	 * Convert a datetime-local admin value (site time) to a GMT Unix timestamp.
	 *
	 * @param string $value 'Y-m-d\TH:i' or 'Y-m-d H:i' in the site's timezone.
	 * @return int A GMT Unix timestamp, or 0 if empty/invalid.
	 */
	public static function local_to_gmt_ts( $value ) {
		$value = trim( str_replace( 'T', ' ', (string) $value ) );
		if ( '' === $value ) {
			return 0;
		}
		$gmt = get_gmt_from_date( $value, 'Y-m-d H:i:s' );
		$ts  = $gmt ? strtotime( $gmt . ' +0000' ) : false;
		return $ts ? (int) $ts : 0;
	}

	/**
	 * Convert a stored GMT timestamp to a datetime-local field value (site time).
	 *
	 * @param int $ts A GMT Unix timestamp, or 0.
	 * @return string 'Y-m-d\TH:i', or '' if 0.
	 */
	public static function gmt_ts_to_local( $ts ) {
		$ts = (int) $ts;
		if ( ! $ts ) {
			return '';
		}
		return get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $ts ), 'Y-m-d\TH:i' );
	}

	/**
	 * The ids of every poll the current member may see, newest first.
	 *
	 * @return int[]
	 */
	public static function viewable_poll_ids() {
		$ids = get_posts( array(
			'post_type'      => self::POLL_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
		) );
		$ids = array_filter( array_map( 'intval', $ids ), array( __CLASS__, 'can_view_poll' ) );
		// Drop polls past their hide time (or manually closed with no schedule).
		$ids = array_filter( $ids, function ( $id ) {
			return 'hidden' !== self::poll_state( $id );
		} );
		return array_values( $ids );
	}

	/**
	 * Every poll this viewer may see, open ones first, newest first within each.
	 *
	 * Open polls lead because they are the ones that still want something from
	 * a member. Closed polls follow while they are still inside their hide
	 * window, a decision is worth reading after the voting has finished, but
	 * only for as long as Nick said it should be on the site.
	 *
	 * @return int[] Poll ids in display order.
	 */
	public static function ordered_poll_ids() {
		$open   = array();
		$closed = array();

		// viewable_poll_ids() is already newest-first and already excludes
		// hidden polls and any the viewer isn't in the audience for.
		foreach ( self::viewable_poll_ids() as $id ) {
			if ( 'closed' === self::poll_state( $id ) ) {
				$closed[] = $id;
			} else {
				$open[] = $id;
			}
		}

		return array_merge( $open, $closed );
	}

	/**
	 * The single poll to show for the "latest" source.
	 *
	 * The first of the same ordering, so "latest" means the newest poll still
	 * taking votes, and falls back to the most recent decision when none is.
	 *
	 * @return int A poll id, or 0.
	 */
	public static function latest_poll_id() {
		$ids = self::ordered_poll_ids();
		return empty( $ids ) ? 0 : (int) $ids[0];
	}

	/**
	 * Render a set of polls as one list.
	 *
	 * @param int[] $ids   Poll ids, already ordered and gated.
	 * @param array $style Style args passed to each poll.
	 * @param array $text  Wording overrides passed to each poll.
	 * @return string
	 */
	public static function render_poll_list( $ids, $style = array(), $text = array() ) {
		$out = '';
		foreach ( $ids as $id ) {
			$html = self::render_poll( (int) $id, $style, $text );
			if ( '' !== $html ) {
				$out .= '<div class="ff-polls-list-item">' . $html . '</div>';
			}
		}

		return ( '' === $out ) ? '' : '<div class="ff-polls-list">' . $out . '</div>';
	}

	/**
	 * The [ff_polls_archive] shortcode: open poll(s) then past polls with results.
	 *
	 * For a dedicated polls page: any open poll shows first (votable, or results
	 * if the member has voted), followed by every past poll with its results and
	 * outcome. All gated, a poll the member can't see never appears.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function archive_shortcode( $atts, $text = array(), $empty = null ) {
		$atts = shortcode_atts(
			array(
				'headings'   => 'yes',
				'show'       => 'both', // 'both' | 'open' | 'past'.
				'layout'     => 'stacked', // 'stacked' | 'tabs'.
				'open_label' => '',
				'past_label' => '',
			),
			$atts,
			'ff_polls_archive'
		);

		if ( ! FF_Gating::can_view_members_area() ) {
			return FF_Display::members_only_notice();
		}

		self::enqueue_front();

		$show   = in_array( $atts['show'], array( 'both', 'open', 'past' ), true ) ? $atts['show'] : 'both';
		$ids    = self::viewable_poll_ids();
		$open   = array();
		$closed = array();
		foreach ( $ids as $id ) {
			if ( self::is_closed( $id ) ) {
				$closed[] = $id;
			} else {
				$open[] = $id;
			}
		}

		// Honour the "show" choice, so two widgets (one open, one past) can each
		// be styled separately on the same page.
		if ( 'past' === $show ) {
			$open = array();
		} elseif ( 'open' === $show ) {
			$closed = array();
		}

		// The two labels, which name the sections whether they are headings
		// above one another or tabs beside each other. {count} is filled in
		// from what is actually there, so a label can carry the number without
		// anybody keeping it up to date.
		$labels = array(
			'open' => '' !== trim( (string) $atts['open_label'] ) ? $atts['open_label'] : __( 'Open now', 'founding-faces' ),
			'past' => '' !== trim( (string) $atts['past_label'] ) ? $atts['past_label'] : __( 'Past polls', 'founding-faces' ),
		);

		// Tabs only make sense when both sides can appear. One of the two on
		// its own is a heading over a list, and a single tab is a label
		// pretending to be a choice.
		$tabs = ( 'tabs' === $atts['layout'] ) && ( 'both' === $show ) && ! empty( $open ) && ! empty( $closed );

		// Headings are only useful when both sections can appear together, and
		// never alongside the tabs, which name the sections already.
		$headings = ( 'yes' === $atts['headings'] ) && ( 'both' === $show ) && ! $tabs;
		$out      = '<div class="ff-polls-archive ff-polls-archive--' . esc_attr( $show ) . ( $tabs ? ' ff-polls-archive--tabs' : '' ) . '">';

		if ( empty( $open ) && empty( $closed ) ) {
			// A caller that supplied its own empty-state copy owns this moment
			// entirely, including choosing to say nothing.
			if ( null !== $empty ) {
				return ( '' === $empty ) ? '' : $out . $empty . '</div>';
			}

			$out .= '<p class="ff-empty-note">' . esc_html(
				'open' === $show
					? __( 'No open poll right now.', 'founding-faces' )
					: __( 'No polls yet, check back soon.', 'founding-faces' )
			) . '</p>';
			return $out . '</div>';
		}

		// Each widget on a page needs its own ids, so a tab points at its own
		// panel rather than the first one on the page with that name.
		static $instance = 0;
		$instance++;
		$uid = 'ff-polls-' . $instance;

		if ( $tabs ) {
			$out .= self::tab_bar( $labels, array( 'open' => count( $open ), 'past' => count( $closed ) ), $uid );
		}

		if ( ! empty( $open ) ) {
			if ( $headings ) {
				$out .= '<h2 class="ff-polls-archive-heading">' . self::label_html( $labels['open'], count( $open ) ) . '</h2>';
			}
			$out .= self::panel_open( 'open', $uid, $tabs, true );
			foreach ( $open as $id ) {
				$out .= '<div class="ff-polls-archive-item">' . self::render_poll( $id, array(), $text ) . '</div>';
			}
			$out .= self::panel_close( $tabs );
		}

		if ( ! empty( $closed ) ) {
			if ( $headings ) {
				$out .= '<h2 class="ff-polls-archive-heading">' . self::label_html( $labels['past'], count( $closed ) ) . '</h2>';
			}
			$out .= self::panel_open( 'past', $uid, $tabs, empty( $open ) );
			foreach ( $closed as $id ) {
				$out .= '<div class="ff-polls-archive-item">' . self::render_poll( $id, array(), $text ) . '</div>';
			}
			$out .= self::panel_close( $tabs );
		}

		$out .= '</div>';
		return $out;
	}

	/**
	 * A sample archive for the Elementor canvas.
	 *
	 * The same markup the page gets, tabs and all, so a tab row can be styled
	 * before a poll has ever closed. Both sides always have something in them
	 * here, which is the only way the editor can show the choice.
	 *
	 * @param string $show     both | open | past.
	 * @param string $layout   stacked | tabs.
	 * @param string $headings 'yes' to draw the stacked headings.
	 * @param string $open_lbl The open label as written.
	 * @param string $past_lbl The past label as written.
	 * @param array  $text     The widget's text overrides.
	 * @return string
	 */
	public static function sample_archive( $show, $layout, $headings, $open_lbl, $past_lbl, $text = array() ) {
		$labels = array(
			'open' => '' !== trim( (string) $open_lbl ) ? $open_lbl : __( 'Open now', 'founding-faces' ),
			'past' => '' !== trim( (string) $past_lbl ) ? $past_lbl : __( 'Past polls', 'founding-faces' ),
		);

		$tabs  = ( 'tabs' === $layout ) && ( 'both' === $show );
		$heads = ( 'yes' === $headings ) && ( 'both' === $show ) && ! $tabs;

		$out = '<div class="ff-polls-archive ff-polls-archive--' . esc_attr( $show ) . ( $tabs ? ' ff-polls-archive--tabs' : '' ) . '">';

		if ( $tabs ) {
			$out .= self::tab_bar( $labels, array( 'open' => 1, 'past' => 2 ), 'ff-polls-sample' );
		}

		if ( 'past' !== $show ) {
			if ( $heads ) {
				$out .= '<h2 class="ff-polls-archive-heading">' . self::label_html( $labels['open'], 1 ) . '</h2>';
			}
			$out .= self::panel_open( 'open', 'ff-polls-sample', $tabs, true );
			$out .= '<div class="ff-polls-archive-item">' . self::sample_poll( 'voting', $text ) . '</div>';
			$out .= self::panel_close( $tabs );
		}

		if ( 'open' !== $show ) {
			if ( $heads ) {
				$out .= '<h2 class="ff-polls-archive-heading">' . self::label_html( $labels['past'], 2 ) . '</h2>';
			}
			$out .= self::panel_open( 'past', 'ff-polls-sample', $tabs, 'past' === $show );
			// Two, so the columns have something to lay out against.
			$out .= '<div class="ff-polls-archive-item">' . self::sample_poll( 'results', $text ) . '</div>';
			$out .= '<div class="ff-polls-archive-item">' . self::sample_poll( 'results', $text ) . '</div>';
			$out .= self::panel_close( $tabs );
		}

		return $out . '</div>';
	}

	/**
	 * One label, with {count} filled in.
	 *
	 * Author-facing copy, so it is allowed its own markup, in line with every
	 * other piece of text the editor can set.
	 *
	 * @param string $label The label as written.
	 * @param int    $count How many polls are in that section.
	 * @return string
	 */
	private static function label_html( $label, $count ) {
		return str_replace( '{count}', (int) $count, FF_Text::inline( $label ) );
	}

	/**
	 * The row of tabs.
	 *
	 * Real buttons in a real tablist, so the keyboard and a screen reader get
	 * the same thing the mouse does.
	 *
	 * @param array  $labels Open and past labels.
	 * @param array  $counts How many polls are in each.
	 * @param string $uid    This widget's unique id stem.
	 * @return string
	 */
	private static function tab_bar( $labels, $counts, $uid ) {
		$out = '<div class="ff-poll-tabs" role="tablist">';

		foreach ( array( 'open', 'past' ) as $i => $which ) {
			$current = ( 0 === $i );
			$out    .= '<button type="button" class="ff-poll-tab' . ( $current ? ' is-current' : '' ) . '"'
				. ' id="' . esc_attr( $uid . '-tab-' . $which ) . '"'
				. ' role="tab"'
				. ' aria-controls="' . esc_attr( $uid . '-panel-' . $which ) . '"'
				. ' aria-selected="' . ( $current ? 'true' : 'false' ) . '"'
				. ' tabindex="' . ( $current ? '0' : '-1' ) . '">'
				. self::label_html( $labels[ $which ], $counts[ $which ] )
				. '</button>';
		}

		return $out . '</div>';
	}

	/**
	 * Open a section: a tab panel wrapping the grid, or just the grid.
	 *
	 * @param string $which   'open' or 'past'.
	 * @param string $uid     This widget's unique id stem.
	 * @param bool   $tabs    Whether this archive is tabbed.
	 * @param bool   $current Whether this section is the one on show.
	 * @return string
	 */
	private static function panel_open( $which, $uid, $tabs, $current ) {
		if ( ! $tabs ) {
			return '<div class="ff-polls-archive-grid">';
		}

		return '<div class="ff-poll-panel' . ( $current ? ' is-current' : '' ) . '"'
			. ' id="' . esc_attr( $uid . '-panel-' . $which ) . '"'
			. ' role="tabpanel"'
			. ' aria-labelledby="' . esc_attr( $uid . '-tab-' . $which ) . '"'
			. ( $current ? '' : ' hidden' ) . '>'
			. '<div class="ff-polls-archive-grid">';
	}

	/**
	 * Close a section opened by panel_open().
	 *
	 * @param bool $tabs Whether this archive is tabbed.
	 * @return string
	 */
	private static function panel_close( $tabs ) {
		return $tabs ? '</div></div>' : '</div>';
	}

	/*
	 * -----------------------------------------------------------------------
	 * The AJAX vote handler.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Handle a vote submitted over AJAX.
	 *
	 * Validates the nonce, the member, the poll's open state and audience, and
	 * the chosen option, records the vote, then returns the aggregate results
	 * HTML to reveal in place.
	 *
	 * @return void
	 */
	public static function ajax_vote() {
		check_ajax_referer( self::VOTE_ACTION, 'nonce' );

		$member_id = get_current_user_id();
		if ( ! $member_id || ! FF_Gating::is_member( $member_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Only members can vote.', 'founding-faces' ) ) );
		}

		$poll_id   = isset( $_POST['poll_id'] ) ? absint( wp_unslash( $_POST['poll_id'] ) ) : 0;
		$option_id = isset( $_POST['option_id'] ) ? absint( wp_unslash( $_POST['option_id'] ) ) : 0;

		$poll = $poll_id ? get_post( $poll_id ) : null;
		if ( ! $poll || self::POLL_CPT !== $poll->post_type ) {
			wp_send_json_error( array( 'message' => __( 'That poll could not be found.', 'founding-faces' ) ) );
		}

		// Audience gate.
		if ( ! self::can_view_poll( $poll_id, $member_id ) ) {
			wp_send_json_error( array( 'message' => __( 'This poll isn\'t available to you.', 'founding-faces' ) ) );
		}

		// Must be open (not closed by hand or by its scheduled close time).
		if ( 'open' !== self::poll_state( $poll_id ) ) {
			wp_send_json_error( array( 'message' => __( 'This poll is closed.', 'founding-faces' ) ) );
		}

		// The option must belong to this poll.
		$valid_ids = wp_list_pluck( self::get_options( $poll_id ), 'id' );
		if ( ! in_array( $option_id, array_map( 'intval', $valid_ids ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Please choose a valid option.', 'founding-faces' ) ) );
		}

		$result = self::record_vote( $poll_id, $member_id, $option_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		// The widget's wording comes back with the vote, so the results that
		// replace the buttons say what the rest of the poll says. It only ever
		// shapes this member's own screen, and it is stripped and escaped like
		// any other text before it is rendered.
		$text = array();
		foreach ( array_keys( self::text_defaults() ) as $key ) {
			if ( isset( $_POST[ 'text_' . $key ] ) ) {
				$text[ $key ] = sanitize_text_field( wp_unslash( $_POST[ 'text_' . $key ] ) );
			}
		}

		// Reveal the aggregate results, marking the member's own choice.
		wp_send_json_success( array(
			'html' => self::render_results( $poll_id, $option_id, false, $text ),
		) );
	}

	/*
	 * -----------------------------------------------------------------------
	 * Front-end rendering.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * The [ff_poll] shortcode: render a poll by id, or the active one.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'ff_poll' );
		return self::render_poll( absint( $atts['id'] ) );
	}

	/**
	 * Render a poll for the current member, in whatever state applies.
	 *
	 * A 35-only poll is invisible to anyone who isn't in The 35 (nothing is
	 * rendered, so its very existence stays private). Style options set inline
	 * CSS variables on the wrapper, defaulting to Apotheca tokens.
	 *
	 * @param int   $poll_id The poll id, or 0 for the active poll.
	 * @param array $style   Optional style overrides: accent, align, spacing.
	 * @return string
	 */
	/**
	 * The fixed wording a poll uses, before any widget overrides it.
	 *
	 * Every one of these is a phrase Nick may want to say differently, so each
	 * is a field in the widget rather than a string only a developer can reach.
	 *
	 * @return array Key => default text.
	 */
	public static function text_defaults() {
		return array(
			'closed'     => __( 'Poll closed', 'founding-faces' ),
			'hint'       => __( 'Results are revealed once you vote.', 'founding-faces' ),
			'yours'      => __( 'Your choice', 'founding-faces' ),
			'total_one'  => __( '%s vote', 'founding-faces' ),
			'total_many' => __( '%s votes', 'founding-faces' ),
			'outcome'    => __( 'Where we landed', 'founding-faces' ),
		);
	}

	/**
	 * Resolve a set of wording overrides against the defaults.
	 *
	 * A key that isn't supplied keeps its default. A key supplied as an empty
	 * string is a deliberate choice to say nothing, and that line is dropped
	 * from the markup entirely rather than rendered blank.
	 *
	 * @param array $overrides Widget-supplied wording.
	 * @return array
	 */
	public static function text( $overrides = array() ) {
		$text = self::text_defaults();

		foreach ( $text as $key => $default ) {
			if ( isset( $overrides[ $key ] ) ) {
				// Every one of these lands in a heading, a capsule or a label,
				// so inline markup only, bold a word, link a word, no more.
				$text[ $key ] = FF_Text::inline( $overrides[ $key ] );
			}
		}

		return $text;
	}

	public static function render_poll( $poll_id = 0, $style = array(), $text = array() ) {
		self::enqueue_front();

		if ( ! $poll_id ) {
			$poll_id = self::get_active_poll_id();
		}

		$poll = $poll_id ? get_post( $poll_id ) : null;
		if ( ! $poll || self::POLL_CPT !== $poll->post_type || 'publish' !== $poll->post_status ) {
			return '';
		}

		// Non-members and members outside the audience see nothing at all.
		if ( ! self::can_view_poll( $poll_id ) ) {
			return '';
		}

		// Past its hide time (or manually closed with no schedule): gone entirely.
		if ( 'hidden' === self::poll_state( $poll_id ) ) {
			return '';
		}

		$style = wp_parse_args( $style, array(
			'accent'  => '#3a3d44',
			'align'   => 'left',
			'spacing' => 16,
		) );

		$align = in_array( $style['align'], array( 'left', 'center', 'right' ), true ) ? $style['align'] : 'left';

		$wrapper_style = sprintf(
			'--ff-poll-accent:%1$s;--ff-poll-gap:%2$dpx;text-align:%3$s;',
			esc_attr( $style['accent'] ),
			absint( $style['spacing'] ),
			esc_attr( $align )
		);

		$text  = self::text( $text );
		$inner = self::render_inner( $poll_id, $text );

		// The wording travels with the markup so the results returned after a
		// vote, rendered by an AJAX call that knows nothing about this widget
		//, come back saying the same things this poll says now.
		$data = '';
		foreach ( $text as $key => $value ) {
			$data .= ' data-text-' . esc_attr( str_replace( '_', '-', $key ) ) . '="' . esc_attr( $value ) . '"';
		}

		return '<div class="ff-poll" data-poll="' . esc_attr( $poll_id ) . '" style="' . esc_attr( $wrapper_style ) . '"' . $data . '>'
			. $inner
			. '</div>';
	}

	/**
	 * Render the inner state of a poll: vote form, results, or closed state.
	 *
	 * @param int $poll_id The poll id.
	 * @return string
	 */
	private static function render_inner( $poll_id, $text = array() ) {
		$state     = self::poll_state( $poll_id );
		$member_id = get_current_user_id();
		$text      = self::text( $text );

		// Closed: show results and Nick's reasoning to everyone in the audience.
		if ( 'closed' === $state ) {
			return self::render_results( $poll_id, self::member_vote( $poll_id, $member_id ), true, $text );
		}

		// Open and already voted: show results, marking their choice.
		if ( self::has_voted( $poll_id, $member_id ) ) {
			return self::render_results( $poll_id, self::member_vote( $poll_id, $member_id ), false, $text );
		}

		// Open and not voted: show the voting form.
		return self::render_form( $poll_id, $text );
	}

	/**
	 * A sample poll for the Elementor editor.
	 *
	 * Uses the live markup and classes so every part, the closed capsule, the
	 * question, the bars (default, winning, your-choice), the labels and the
	 * vote count, can be styled before a real poll exists or is voted on.
	 *
	 * @param string $state 'results' or 'voting'.
	 * @return string
	 */
	public static function sample_poll( $state = 'results', $text = array() ) {
		$text = self::text( $text );
		$out  = '<div class="ff-poll ff-poll--sample">';

		if ( 'voting' === $state ) {
			$out .= '<div class="ff-poll-inner">';
			$out .= '<h3 class="ff-poll-question">' . esc_html__( 'Which shade should we take into the well-aging product?', 'founding-faces' ) . '</h3>';
			$out .= '<div class="ff-poll-options">';
			foreach ( array( __( 'Orange', 'founding-faces' ), __( 'Lime', 'founding-faces' ), __( 'Blush', 'founding-faces' ) ) as $label ) {
				$out .= '<button type="button" class="ff-poll-option"><span class="ff-poll-option-label">' . esc_html( $label ) . '</span></button>';
			}
			$out .= '</div>';
			if ( FF_Text::filled( $text['hint'] ) ) {
				$out .= '<p class="ff-poll-hint">' . FF_Text::inline( $text['hint'] ) . '</p>';
			}
			$out .= '</div></div>';
			return $out;
		}

		$out .= '<div class="ff-poll-inner">';
		if ( FF_Text::filled( $text['closed'] ) ) {
			$out .= '<div class="ff-poll-status"><span class="ff-poll-status-badge">' . FF_Text::inline( $text['closed'] ) . '</span></div>';
		}
		$out .= '<h3 class="ff-poll-question">' . esc_html__( 'Which shade should we take into the well-aging product?', 'founding-faces' ) . '</h3>';

		// Three options: the first is both the leader and the member's choice.
		$rows = array(
			array( __( 'Orange', 'founding-faces' ), 58, true, true ),
			array( __( 'Lime', 'founding-faces' ), 27, false, false ),
			array( __( 'Blush', 'founding-faces' ), 15, false, false ),
		);
		foreach ( $rows as $row ) {
			$classes = 'ff-poll-result';
			if ( $row[3] ) {
				$classes .= ' is-mine';
			}
			if ( $row[2] ) {
				$classes .= ' ff-poll-result--leading';
			}
			$out .= '<div class="' . esc_attr( $classes ) . '">';
			$out .= '<div class="ff-poll-result-head">';
			$out .= '<span class="ff-poll-result-label">' . esc_html( $row[0] );
			if ( $row[3] && FF_Text::filled( $text['yours'] ) ) {
				$out .= '<span class="ff-poll-yours">' . FF_Text::inline( $text['yours'] ) . '</span>';
			}
			$out .= '</span>';
			$out .= '<span class="ff-poll-result-percent">' . esc_html( $row[1] ) . '%</span>';
			$out .= '</div>';
			$out .= '<div class="ff-poll-bar"><span class="ff-poll-bar-fill" style="width:' . esc_attr( $row[1] ) . '%;"></span></div>';
			$out .= '</div>';
		}

		if ( FF_Text::filled( $text['total_many'] ) ) {
			$out .= '<p class="ff-poll-total">' . str_replace( '%s', esc_html( number_format_i18n( 100 ) ), FF_Text::inline( $text['total_many'] ) ) . '</p>';
		}
		$out .= '<div class="ff-poll-outcome">';
		if ( FF_Text::filled( $text['outcome'] ) ) {
			$out .= '<span class="ff-poll-outcome-label">' . FF_Text::inline( $text['outcome'] ) . '</span>';
		}
		$out .= '<p>' . esc_html__( 'Sample outcome text, so the reasoning block can be styled too.', 'founding-faces' ) . '</p>';
		$out .= '</div>';
		$out .= '</div></div>';

		return $out;
	}

	/**
	 * Render the voting form (question and clickable options).
	 *
	 * @param int $poll_id The poll id.
	 * @return string
	 */
	private static function render_form( $poll_id, $text = array() ) {
		$text    = self::text( $text );
		$options = self::get_options( $poll_id );

		$out  = '<div class="ff-poll-inner">';
		$out .= '<h3 class="ff-poll-question">' . esc_html( get_the_title( $poll_id ) ) . '</h3>';
		$out .= '<div class="ff-poll-error" role="alert"></div>';
		$out .= '<div class="ff-poll-options">';

		foreach ( $options as $opt ) {
			$out .= '<button type="button" class="ff-poll-option" data-option="' . esc_attr( $opt['id'] ) . '">';
			if ( ! empty( $opt['image_id'] ) ) {
				$img = wp_get_attachment_image( $opt['image_id'], 'medium', false, array( 'class' => 'ff-poll-option-img', 'loading' => 'lazy' ) );
				if ( $img ) {
					$out .= $img;
				}
			}
			$out .= '<span class="ff-poll-option-label">' . esc_html( $opt['label'] ) . '</span>';
			$out .= '</button>';
		}

		$out .= '</div>';
		if ( FF_Text::filled( $text['hint'] ) ) {
			$out .= '<p class="ff-poll-hint">' . FF_Text::inline( $text['hint'] ) . '</p>';
		}
		$out .= '</div>';
		return $out;
	}

	/**
	 * Render the aggregate results (and, when closed, Nick's reasoning).
	 *
	 * Aggregate only: counts and percentages, never who voted. The member's own
	 * choice is highlighted if known.
	 *
	 * @param int  $poll_id     The poll id.
	 * @param int  $member_vote The option id the member chose, or 0.
	 * @param bool $closed      Whether the poll is closed.
	 * @return string
	 */
	public static function render_results( $poll_id, $member_vote = 0, $closed = false, $text = array() ) {
		$text = self::text( $text );
		$options = self::get_options( $poll_id );
		$tally   = self::tally( $poll_id );
		$total   = array_sum( $tally );
		$max     = ! empty( $tally ) ? max( $tally ) : 0;

		$out = '<div class="ff-poll-inner ff-poll-results">';

		// Closed capsule, above the question. Its wording and styling both come
		// from the widget; cleared wording means no capsule at all.
		if ( $closed && FF_Text::filled( $text['closed'] ) ) {
			$out .= '<div class="ff-poll-status"><span class="ff-poll-status-badge">'
				. FF_Text::inline( $text['closed'] ) . '</span></div>';
		}

		$out .= '<h3 class="ff-poll-question">' . esc_html( get_the_title( $poll_id ) ) . '</h3>';

		foreach ( $options as $opt ) {
			$votes   = isset( $tally[ (int) $opt['id'] ] ) ? (int) $tally[ (int) $opt['id'] ] : 0;
			$percent = $total > 0 ? round( ( $votes / $total ) * 100 ) : 0;
			$mine    = ( (int) $member_vote === (int) $opt['id'] );
			$leading = ( $max > 0 && $votes === $max ); // The winning option(s).

			$classes = 'ff-poll-result';
			if ( $mine ) {
				$classes .= ' is-mine';
			}
			if ( $leading ) {
				$classes .= ' ff-poll-result--leading';
			}
			$out .= '<div class="' . esc_attr( $classes ) . '">';
			$out .= '<div class="ff-poll-result-head">';
			$out .= '<span class="ff-poll-result-label">' . esc_html( $opt['label'] );
			if ( $mine && FF_Text::filled( $text['yours'] ) ) {
				$out .= '<span class="ff-poll-yours">' . FF_Text::inline( $text['yours'] ) . '</span>';
			}
			$out .= '</span>';
			$out .= '<span class="ff-poll-result-percent">' . esc_html( $percent ) . '%</span>';
			$out .= '</div>';
			$out .= '<div class="ff-poll-bar"><span class="ff-poll-bar-fill" style="width:' . esc_attr( $percent ) . '%;"></span></div>';
			$out .= '</div>';
		}

		// str_replace, not sprintf: the wording is Nick's to write, and a stray
		// per-cent sign in it should read as a per-cent sign, not crash a format.
		$count_text = ( 1 === $total ) ? $text['total_one'] : $text['total_many'];
		if ( FF_Text::filled( $count_text ) ) {
			$out .= '<p class="ff-poll-total">' . str_replace(
				'%s',
				esc_html( number_format_i18n( $total ) ),
				FF_Text::inline( $count_text )
			) . '</p>';
		}

		// On close, show the outcome and Nick's reasoning (the "closed" status is
		// now shown as the capsule above the question).
		if ( $closed ) {
			$outcome = get_post_meta( $poll_id, self::META_OUTCOME, true );
			if ( trim( (string) $outcome ) !== '' ) {
				$out .= '<div class="ff-poll-outcome">';
				if ( FF_Text::filled( $text['outcome'] ) ) {
					$out .= '<span class="ff-poll-outcome-label">' . FF_Text::inline( $text['outcome'] ) . '</span>';
				}
				$out .= wpautop( wp_kses_post( $outcome ) );
				$out .= '</div>';
			}
		}

		$out .= '</div>';
		return $out;
	}

	/**
	 * Get a poll's options as a clean list of ['id','label','image_id'].
	 *
	 * @param int $poll_id The poll id.
	 * @return array
	 */
	public static function get_options( $poll_id ) {
		$options = get_post_meta( $poll_id, self::META_OPTIONS, true );
		return is_array( $options ) ? $options : array();
	}

	/**
	 * Enqueue the front-end poll script and styles (once).
	 */
	private static function enqueue_front() {
		wp_enqueue_style( 'founding-faces', FF_URL . 'assets/css/founding-faces.css', array(), FF_VERSION );

		wp_enqueue_script( 'ff-polls', FF_URL . 'assets/js/polls.js', array(), FF_VERSION, true );

		// Pass the AJAX url and a nonce to the script, once.
		static $localized = false;
		if ( ! $localized ) {
			wp_localize_script( 'ff-polls', 'ffPolls', array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => self::VOTE_ACTION,
				'nonce'   => wp_create_nonce( self::VOTE_ACTION ),
			) );
			$localized = true;
		}
	}

	/*
	 * -----------------------------------------------------------------------
	 * Admin: the poll editor and the who-voted view.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Add the poll editor and results metaboxes.
	 */
	public static function add_metaboxes() {
		add_meta_box( 'ff_poll_editor', __( 'Poll setup', 'founding-faces' ), array( __CLASS__, 'render_editor' ), self::POLL_CPT, 'normal', 'high' );
		add_meta_box( 'ff_poll_results', __( 'Results: who voted for what (admin only)', 'founding-faces' ), array( __CLASS__, 'render_admin_results' ), self::POLL_CPT, 'normal', 'default' );
	}

	/**
	 * Load the poll admin script (repeater + media) on the poll edit screen.
	 *
	 * @param string $hook The current admin page hook.
	 */
	public static function enqueue_admin( $hook ) {
		if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || self::POLL_CPT !== $screen->post_type ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'ff-admin', FF_URL . 'admin/admin-style.css', array(), FF_VERSION );
		wp_enqueue_script( 'ff-polls-admin', FF_URL . 'assets/js/polls-admin.js', array( 'jquery' ), FF_VERSION, true );
	}

	/**
	 * Render the poll setup metabox: options, audience, status, outcome.
	 *
	 * @param WP_Post $post The poll being edited.
	 */
	public static function render_editor( $post ) {
		wp_nonce_field( 'ff_save_poll', 'ff_poll_nonce' );

		$options  = self::get_options( $post->ID );
		$audience = get_post_meta( $post->ID, self::META_AUDIENCE, true ) ? get_post_meta( $post->ID, self::META_AUDIENCE, true ) : 'everyone';
		$status   = get_post_meta( $post->ID, self::META_STATUS, true ) ? get_post_meta( $post->ID, self::META_STATUS, true ) : 'open';
		$active   = (int) get_post_meta( $post->ID, self::META_ACTIVE, true );
		$outcome  = get_post_meta( $post->ID, self::META_OUTCOME, true );
		$close_at = self::gmt_ts_to_local( get_post_meta( $post->ID, self::META_CLOSE_AT, true ) );
		$hide_at  = self::gmt_ts_to_local( get_post_meta( $post->ID, self::META_HIDE_AT, true ) );

		// Ensure at least two empty rows to start with.
		if ( count( $options ) < 2 ) {
			$options = array_pad( $options, 2, array( 'id' => 0, 'label' => '', 'image_id' => 0 ) );
		}
		?>
		<p class="description"><?php esc_html_e( 'The poll question is the title above. Add two or more options; each can carry an image.', 'founding-faces' ); ?></p>

		<div id="ff-poll-options" class="ff-poll-editor">
			<?php foreach ( $options as $opt ) : ?>
				<?php self::render_option_row( $opt ); ?>
			<?php endforeach; ?>
		</div>
		<p><button type="button" class="button" id="ff-poll-add-option"><?php esc_html_e( 'Add option', 'founding-faces' ); ?></button></p>

		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="ff_poll_audience"><?php esc_html_e( 'Audience', 'founding-faces' ); ?></label></th>
				<td>
					<select name="ff_poll_audience" id="ff_poll_audience">
						<?php foreach ( self::audiences() as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $audience, $key ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="ff_poll_tag"><?php esc_html_e( 'Email marketing tag', 'founding-faces' ); ?></label></th>
				<td>
					<input type="text" name="ff_poll_tag" id="ff_poll_tag" class="regular-text" value="<?php echo esc_attr( get_post_meta( $post->ID, self::META_TAG, true ) ); ?>" />
					<p class="description">
						<?php
						printf(
							/* translators: %s: the tag as it will be sent. */
							esc_html__( 'The label everyone who votes in this poll carries on your email platform. Leave it empty to use the poll title. As it stands: %s', 'founding-faces' ),
							'<code>' . esc_html( self::poll_tag( $post->ID ) ) . '</code>'
						);
						?>
					</p>
					<p class="description">
						<?php esc_html_e( 'Worth shortening on a long question. Campaign Monitor holds all of a member\'s tags in one 250-character field, so a question written out in full uses a fifth of it.', 'founding-faces' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="ff_poll_status"><?php esc_html_e( 'Status', 'founding-faces' ); ?></label></th>
				<td>
					<select name="ff_poll_status" id="ff_poll_status">
						<option value="open" <?php selected( $status, 'open' ); ?>><?php esc_html_e( 'Open (accepting votes)', 'founding-faces' ); ?></option>
						<option value="closed" <?php selected( $status, 'closed' ); ?>><?php esc_html_e( 'Closed, kept in past polls (shows results and reasoning)', 'founding-faces' ); ?></option>
						<option value="hidden" <?php selected( $status, 'hidden' ); ?>><?php esc_html_e( 'Hidden (off the site entirely)', 'founding-faces' ); ?></option>
					</select>
					<p class="description"><?php esc_html_e( 'Closed keeps the poll in the past polls with its result on show. Hidden takes it off the site, votes kept. Or leave this on Open and let the times below do it on a schedule.', 'founding-faces' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="ff_poll_close_at"><?php esc_html_e( 'Auto-close at', 'founding-faces' ); ?></label></th>
				<td>
					<input type="datetime-local" name="ff_poll_close_at" id="ff_poll_close_at" value="<?php echo esc_attr( $close_at ); ?>" />
					<p class="description"><?php esc_html_e( 'Optional. At this time the poll stops taking votes and shows the final results and your reasoning. Leave blank to close it by hand with the Status above.', 'founding-faces' ); ?></p>
				</td>
			</tr>
			<?php
			$hide_ts = (int) get_post_meta( $post->ID, self::META_HIDE_AT, true );
			if ( $hide_ts > 0 && time() >= $hide_ts ) :
				?>
			<tr>
				<th scope="row"></th>
				<td>
					<div class="notice notice-warning inline" style="margin:0;padding:8px 12px;">
						<p style="margin:0;">
							<?php
							echo esc_html( sprintf(
								/* translators: %s is a date and time. */
								__( 'This poll is off the site. The auto-hide time passed on %s, which takes a poll away whatever its status says. Clear the field below to put it back in the past polls.', 'founding-faces' ),
								wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $hide_ts )
							) );
							?>
						</p>
					</div>
				</td>
			</tr>
			<?php endif; ?>
			<tr>
				<th scope="row"><label for="ff_poll_hide_at"><?php esc_html_e( 'Auto-hide at', 'founding-faces' ); ?></label></th>
				<td>
					<input type="datetime-local" name="ff_poll_hide_at" id="ff_poll_hide_at" value="<?php echo esc_attr( $hide_at ); ?>" />
					<p class="description"><?php esc_html_e( 'Optional, and a one-way door once it passes: the poll leaves the site entirely, past polls included, whatever the status above says. Leave it empty to keep a closed poll in the archive for good, or set it a little after the close time so members see the final votes for a while first.', 'founding-faces' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Active poll', 'founding-faces' ); ?></th>
				<td>
					<label><input type="checkbox" name="ff_poll_active" value="1" <?php checked( $active, 1 ); ?> />
						<?php esc_html_e( 'Make this the current active poll (a widget set to "current active" shows this one).', 'founding-faces' ); ?></label>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="ff_poll_outcome"><?php esc_html_e( 'Outcome / reasoning (shown when closed)', 'founding-faces' ); ?></label></th>
				<td>
					<textarea name="ff_poll_outcome" id="ff_poll_outcome" rows="4" class="large-text"><?php echo esc_textarea( $outcome ); ?></textarea>
					<p class="description"><?php esc_html_e( 'e.g. "You leaned 60/40 to the darker grey, but it failed small-print contrast, so here\'s where we landed."', 'founding-faces' ); ?></p>
				</td>
			</tr>
		</table>

		<?php
		// A hidden template row the admin script clones for new options.
		echo '<script type="text/html" id="ff-poll-row-template">';
		self::render_option_row( array( 'id' => 0, 'label' => '', 'image_id' => 0 ) );
		echo '</script>';
	}

	/**
	 * Render one option row in the poll editor.
	 *
	 * @param array $opt An option: id, label, image_id.
	 */
	private static function render_option_row( $opt ) {
		$id       = isset( $opt['id'] ) ? (int) $opt['id'] : 0;
		$label    = isset( $opt['label'] ) ? $opt['label'] : '';
		$image_id = isset( $opt['image_id'] ) ? (int) $opt['image_id'] : 0;
		$thumb    = $image_id ? wp_get_attachment_image( $image_id, 'thumbnail' ) : '';
		?>
		<div class="ff-poll-row">
			<input type="hidden" name="ff_poll_opt_id[]" value="<?php echo esc_attr( $id ); ?>" />
			<span class="ff-poll-row-image"><?php echo $thumb; // Escaped by WP. ?></span>
			<input type="hidden" name="ff_poll_opt_image[]" class="ff-poll-opt-image" value="<?php echo esc_attr( $image_id ); ?>" />
			<input type="text" name="ff_poll_opt_label[]" class="regular-text ff-poll-opt-label" placeholder="<?php esc_attr_e( 'Option label', 'founding-faces' ); ?>" value="<?php echo esc_attr( $label ); ?>" />
			<button type="button" class="button ff-poll-pick-image"><?php esc_html_e( 'Image', 'founding-faces' ); ?></button>
			<button type="button" class="button-link ff-poll-remove"><?php esc_html_e( 'Remove', 'founding-faces' ); ?></button>
		</div>
		<?php
	}

	/**
	 * Save the poll setup.
	 *
	 * @param int     $post_id The poll id.
	 * @param WP_Post $post    The poll object.
	 */
	public static function save_poll( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! isset( $_POST['ff_poll_nonce'] ) || ! wp_verify_nonce( wp_unslash( $_POST['ff_poll_nonce'] ), 'ff_save_poll' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Build the options, assigning a stable id to any new row.
		$labels = isset( $_POST['ff_poll_opt_label'] ) ? (array) wp_unslash( $_POST['ff_poll_opt_label'] ) : array();
		$images = isset( $_POST['ff_poll_opt_image'] ) ? (array) wp_unslash( $_POST['ff_poll_opt_image'] ) : array();
		$ids    = isset( $_POST['ff_poll_opt_id'] ) ? (array) wp_unslash( $_POST['ff_poll_opt_id'] ) : array();

		$existing = array_map( 'intval', $ids );
		$next_id  = $existing ? ( max( $existing ) + 1 ) : 1;

		$options = array();
		foreach ( $labels as $i => $label ) {
			$label = sanitize_text_field( $label );
			if ( '' === $label ) {
				continue; // Skip blank rows.
			}
			$oid = isset( $ids[ $i ] ) ? (int) $ids[ $i ] : 0;
			if ( $oid <= 0 ) {
				$oid = $next_id;
				$next_id++;
			}
			$options[] = array(
				'id'       => $oid,
				'label'    => $label,
				'image_id' => isset( $images[ $i ] ) ? absint( $images[ $i ] ) : 0,
			);
		}
		update_post_meta( $post_id, self::META_OPTIONS, $options );

		// Audience.
		$audience = isset( $_POST['ff_poll_audience'] ) ? sanitize_key( wp_unslash( $_POST['ff_poll_audience'] ) ) : 'everyone';
		if ( ! array_key_exists( $audience, self::audiences() ) ) {
			$audience = 'everyone';
		}
		update_post_meta( $post_id, self::META_AUDIENCE, $audience );

		// Status.
		$status = isset( $_POST['ff_poll_status'] ) ? sanitize_key( wp_unslash( $_POST['ff_poll_status'] ) ) : 'open';
		$status = in_array( $status, array( 'open', 'closed', 'hidden' ), true ) ? $status : 'open';
		update_post_meta( $post_id, self::META_STATUS, $status );

		// Scheduled close/hide times (stored as GMT timestamps; 0 = unset).
		$close_at = isset( $_POST['ff_poll_close_at'] ) ? self::local_to_gmt_ts( sanitize_text_field( wp_unslash( $_POST['ff_poll_close_at'] ) ) ) : 0;
		$hide_at  = isset( $_POST['ff_poll_hide_at'] ) ? self::local_to_gmt_ts( sanitize_text_field( wp_unslash( $_POST['ff_poll_hide_at'] ) ) ) : 0;
		update_post_meta( $post_id, self::META_CLOSE_AT, $close_at );
		update_post_meta( $post_id, self::META_HIDE_AT, $hide_at );

		// Outcome.
		update_post_meta( $post_id, self::META_OUTCOME, isset( $_POST['ff_poll_outcome'] ) ? wp_kses_post( wp_unslash( $_POST['ff_poll_outcome'] ) ) : '' );

		// Active flag, only one poll may be active at a time.
		$active = isset( $_POST['ff_poll_active'] ) ? 1 : 0;
		update_post_meta( $post_id, self::META_TAG, isset( $_POST['ff_poll_tag'] ) ? sanitize_title( wp_unslash( $_POST['ff_poll_tag'] ) ) : '' );
		update_post_meta( $post_id, self::META_ACTIVE, $active );
		if ( $active ) {
			self::clear_other_active_polls( $post_id );
		}
	}

	/**
	 * Clear the active flag on every poll except the given one.
	 *
	 * @param int $keep_id The poll to keep active.
	 * @return void
	 */
	private static function clear_other_active_polls( $keep_id ) {
		$others = get_posts( array(
			'post_type'      => self::POLL_CPT,
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'exclude'        => array( $keep_id ),
			'meta_key'       => self::META_ACTIVE, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		foreach ( $others as $other_id ) {
			update_post_meta( $other_id, self::META_ACTIVE, 0 );
		}
	}

	/**
	 * Render the admin-only "who voted for what" view.
	 *
	 * Shows each option with its count and the members who chose it (real name
	 * and number), plus a total. This is never exposed on the frontend.
	 *
	 * @param WP_Post $post The poll being edited.
	 */
	public static function render_admin_results( $post ) {
		global $wpdb;

		$options = self::get_options( $post->ID );
		if ( empty( $options ) ) {
			echo '<p>' . esc_html__( 'Add some options and save first.', 'founding-faces' ) . '</p>';
			return;
		}

		// All votes for this poll with their member ids.
		$votes = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT member_id, option_id, voted_at FROM {$wpdb->prefix}ff_poll_votes WHERE poll_id = %d ORDER BY voted_at ASC",
				$post->ID
			)
		);

		// Group voters by option.
		$by_option = array();
		foreach ( $votes as $vote ) {
			$by_option[ (int) $vote->option_id ][] = $vote;
		}

		echo '<p><strong>' . esc_html( sprintf( /* translators: %d is a vote count. */ _n( '%d vote in total.', '%d votes in total.', count( $votes ), 'founding-faces' ), count( $votes ) ) ) . '</strong></p>';

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'Option', 'founding-faces' ) . '</th>';
		echo '<th>' . esc_html__( 'Votes', 'founding-faces' ) . '</th>';
		echo '<th>' . esc_html__( 'Who voted', 'founding-faces' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $options as $opt ) {
			$rows  = isset( $by_option[ (int) $opt['id'] ] ) ? $by_option[ (int) $opt['id'] ] : array();
			$names = array();
			foreach ( $rows as $row ) {
				$number = get_user_meta( $row->member_id, FF_Members::META_NUMBER, true );
				$real   = get_user_meta( $row->member_id, FF_Members::META_REAL_NAME, true );
				$label  = $real ? $real : ( '#' . (int) $row->member_id );
				if ( $number ) {
					$label .= ' (#' . (int) $number . ')';
				}
				$names[] = $label;
			}

			echo '<tr>';
			echo '<td>' . esc_html( $opt['label'] ) . '</td>';
			echo '<td>' . esc_html( count( $rows ) ) . '</td>';
			echo '<td>' . ( $names ? esc_html( implode( ', ', $names ) ) : '<span style="color:#a0a5aa;">' . esc_html__( 'No votes yet', 'founding-faces' ) . '</span>' ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}
}
