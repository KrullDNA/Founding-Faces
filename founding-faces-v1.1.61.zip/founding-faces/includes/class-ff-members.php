<?php
/**
 * Membership: approving an application into a group, creating the WordPress
 * user, assigning and retiring Founding numbers, deactivating a member on
 * withdrawal, and firing the welcome email.
 *
 * This is where an application (the sensitive record) becomes a member (the
 * public-facing WordPress user). The two records stay deliberately separate:
 * the sensitive answers never move onto the member profile.
 *
 * @package FoundingFaces
 */

// Stop anyone loading this file directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class FF_Members
 *
 * All approval and numbering logic. Numbers are issued from a monotonic
 * sequence that only ever counts up, so a withdrawn number is never handed to
 * anyone else, the record stays truthful.
 */
class FF_Members {

	// User meta: the member's Founding number (only for The 35).
	const META_NUMBER = 'ff_number';

	// User meta: the group slug, mirrored from the taxonomy for fast checks.
	const META_GROUP = 'ff_group_slug';

	// User meta: the real name, kept private and hidden from the public profile.
	const META_REAL_NAME = 'ff_real_name';

	// User meta: the public identity (number for The 35, first name for Circle).
	const META_PUBLIC_NAME = 'ff_public_name';

	// User meta: how a member of The 35 chooses to appear in the members portal.
	// One of 'number' | 'first_number' | 'full_number'. Defaults to 'number':
	// showing a name is always a deliberate opt-up, never the reverse. The Circle
	// never uses this (their login is access-only, with no public display).
	const META_DISPLAY_TIER = 'ff_display_tier';

	// User meta: the id of the application this member was approved from.
	const META_APP_ID = 'ff_application_id';

	// User meta: whether this is a test account (used by the Stage 12 reset).
	const META_IS_TEST = 'ff_is_test';

	// User meta: set when a member is deactivated so their number stays reserved.
	const META_DEACTIVATED = 'ff_deactivated';

	// User meta: whether the member consents to programme emails (mirrored from
	// the application). This is the precondition for any external email sync.
	const META_CONSENT = 'ff_email_consent';

	// User meta: the member's four-digit postcode (mirrored from the
	// application). This is the ONLY location field the members map ever reads;
	// the postal address is a separate, admin-only field the map never touches.
	const META_POSTCODE = 'ff_postcode';

	// Loose behavioural labels: poll-07, feedback-r2, and whatever else is worth
	// segmenting on later. Stored as a real array here and serialised by each
	// connector on the way out, because the platforms disagree about how a list
	// of labels is written and only one of them should have to care.
	const META_TAGS = 'ff_tags';

	// Option: the last Founding number issued. Next number is always this + 1.
	const OPT_SEQUENCE = 'ff_number_sequence';

	// Option: the list of retired numbers, kept for audit and the Stage 12 reset.
	const OPT_RETIRED = 'ff_retired_numbers';

	// Option: how many places The 35 holds. Thirty-five, as the name says, but
	// a setting rather than a constant: the name is a promise to members, and
	// the number behind it should be changeable without a developer.
	const OPT_PLACES = 'ff_the_35_places';

	// The admin-post action used by every moderation button.
	const MODERATE_ACTION = 'ff_moderate';

	// User meta: the Unix timestamp (GMT) of the member's last login.
	const META_LAST_LOGIN = 'ff_last_login';

	/**
	 * Wire up the moderation handler and the deactivated-login block.
	 *
	 * Called once on plugin load.
	 */
	public static function register() {
		// Handle the approve / decline / withdraw / resend buttons.
		add_action( 'admin_post_' . self::MODERATE_ACTION, array( __CLASS__, 'handle_moderation' ) );

		// Stop a deactivated member from logging in, so a retired number's owner
		// can't come back in while their number stays reserved.
		add_filter( 'authenticate', array( __CLASS__, 'block_deactivated_login' ), 30, 3 );

		// Record each successful login, so the admin can see who's active.
		add_action( 'wp_login', array( __CLASS__, 'record_login' ), 10, 2 );

		// Send members to the hub page when they log in.
		add_filter( 'login_redirect', array( __CLASS__, 'member_login_redirect' ), 10, 3 );

		// Tags, editable by hand on the member's own user screen.
		add_action( 'edit_user_profile', array( __CLASS__, 'tags_field' ) );
		add_action( 'show_user_profile', array( __CLASS__, 'tags_field' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save_tags_field' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save_tags_field' ) );
	}

	/**
	 * The tags box on a member's user screen.
	 *
	 * Most tags arrive on their own, from voting or leaving feedback. This is
	 * for the ones that don't: the label you want to write to a handful of
	 * people about, which no amount of automation is going to guess.
	 *
	 * @param WP_User $user The user being edited.
	 */
	public static function tags_field( $user ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! get_user_meta( $user->ID, self::META_GROUP, true ) ) {
			return; // Not a programme member, so there is nothing to segment.
		}

		$tags   = self::tags( $user->ID );
		$status = self::status_label( self::status( $user->ID ) );
		?>
		<h2><?php esc_html_e( 'Founding Faces', 'founding-faces' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Status', 'founding-faces' ); ?></th>
				<td>
					<p><strong><?php echo esc_html( $status ); ?></strong></p>
					<p class="description"><?php esc_html_e( 'Worked out from the account rather than stored, so it cannot fall out of step. Change it by approving, promoting or withdrawing.', 'founding-faces' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="ff_tags"><?php esc_html_e( 'Tags', 'founding-faces' ); ?></label></th>
				<td>
					<input type="text" name="ff_tags" id="ff_tags" class="large-text" value="<?php echo esc_attr( implode( ', ', $tags ) ); ?>" />
					<p class="description">
						<?php esc_html_e( 'Comma separated. Lower case, hyphens, no spaces: voted, poll-14, gave-feedback. Some are added for you when a member votes or sends feedback. Saving here syncs them to your email platform straight away.', 'founding-faces' ); ?>
					</p>
				</td>
			</tr>
		</table>
		<?php
		wp_nonce_field( 'ff_save_tags', 'ff_tags_nonce' );
	}

	/**
	 * Save the tags box.
	 *
	 * @param int $user_id The user being saved.
	 */
	public static function save_tags_field( $user_id ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! isset( $_POST['ff_tags_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['ff_tags_nonce'] ) ), 'ff_save_tags' ) ) {
			return;
		}

		$raw = isset( $_POST['ff_tags'] ) ? sanitize_text_field( wp_unslash( $_POST['ff_tags'] ) ) : '';

		self::set_tags( $user_id, explode( ',', $raw ) );
		FF_Connectors::sync_member( $user_id );
	}

	/**
	 * Redirect a member to the hub page after they log in.
	 *
	 * Administrators keep the default destination. A member who was sent to log
	 * in for a specific page (e.g. a gated note) is returned there; only the
	 * default "go to the dashboard" case is replaced with the hub.
	 *
	 * @param string           $redirect_to The default redirect destination.
	 * @param string           $requested   The requested redirect_to, if any.
	 * @param WP_User|WP_Error $user        The user logging in.
	 * @return string
	 */
	public static function member_login_redirect( $redirect_to, $requested, $user ) {
		if ( ! ( $user instanceof WP_User ) ) {
			return $redirect_to;
		}
		// Admins (and anyone who can reach wp-admin) keep the default.
		if ( user_can( $user, 'manage_options' ) ) {
			return $redirect_to;
		}
		if ( ! FF_Gating::is_member( $user->ID ) ) {
			return $redirect_to;
		}

		// Respect an explicit destination the member was headed to (a gated note,
		// say); only replace the default wp-admin landing.
		$is_default = ( '' === (string) $requested ) || false !== strpos( (string) $requested, 'wp-admin' );
		if ( ! $is_default ) {
			return $redirect_to;
		}

		$hub = (int) get_option( FF_Messages::OPT_PORTAL_PAGE, 0 );
		$url = $hub ? get_permalink( $hub ) : '';
		return $url ? $url : $redirect_to;
	}

	/**
	 * Record a member's last-login time on a successful login.
	 *
	 * @param string       $user_login The login name (unused).
	 * @param WP_User|null $user       The user who logged in.
	 * @return void
	 */
	public static function record_login( $user_login, $user = null ) {
		if ( ! $user instanceof WP_User ) {
			$user = get_user_by( 'login', $user_login );
		}
		if ( $user ) {
			update_user_meta( $user->ID, self::META_LAST_LOGIN, time() );
		}
	}

	/*
	 * -----------------------------------------------------------------------
	 * Numbering.
	 * A monotonic sequence guarantees "retire, never reuse": the next number is
	 * always one past the highest ever issued, so a gap left by a withdrawal is
	 * never filled.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Issue the next Founding number and advance the sequence.
	 *
	 * @return int The newly assigned number.
	 */
	public static function assign_next_number() {
		$next = (int) get_option( self::OPT_SEQUENCE, 0 ) + 1;
		update_option( self::OPT_SEQUENCE, $next );
		return $next;
	}

	/**
	 * How many places The 35 holds.
	 *
	 * @return int
	 */
	public static function places() {
		$places = (int) get_option( self::OPT_PLACES, 35 );

		return $places > 0 ? $places : 35;
	}

	/**
	 * How many of those places are taken.
	 *
	 * Counts members holding a number who are still active. A withdrawn member
	 * keeps their number on record, for the audit, but their place is free:
	 * that is the whole reason for withdrawing somebody.
	 *
	 * @return int
	 */
	public static function the_35_count() {
		$ids = get_users( array(
			'meta_key'     => self::META_NUMBER, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_compare' => 'EXISTS',
			'fields'       => 'ID',
		) );

		$count = 0;
		foreach ( $ids as $id ) {
			if ( ! get_user_meta( (int) $id, self::META_DEACTIVATED, true ) ) {
				$count++;
			}
		}

		return $count;
	}

	/**
	 * How many places are left, never below zero.
	 *
	 * @return int
	 */
	public static function places_left() {
		return max( 0, self::places() - self::the_35_count() );
	}

	/**
	 * How many of the taken places are held by test accounts.
	 *
	 * Test accounts take real numbers on purpose, so they fill real places.
	 * Worth saying out loud while the programme is being built, so a full
	 * count is not mistaken for thirty-five actual people.
	 *
	 * @return int
	 */
	public static function test_places() {
		$ids = get_users( array(
			'meta_key'     => self::META_NUMBER, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_compare' => 'EXISTS',
			'fields'       => 'ID',
		) );

		$count = 0;
		foreach ( $ids as $id ) {
			if ( get_user_meta( (int) $id, self::META_IS_TEST, true ) && ! get_user_meta( (int) $id, self::META_DEACTIVATED, true ) ) {
				$count++;
			}
		}

		return $count;
	}

	/**
	 * Retire a number so it is recorded as used-and-gone.
	 *
	 * The sequence already sits past this number, so retiring it doesn't change
	 * what gets issued next; the retired list exists for the audit view and for
	 * the guarded test reset in a later stage.
	 *
	 * @param int $number The number to retire.
	 * @return void
	 */
	public static function retire_number( $number ) {
		$number  = (int) $number;
		$retired = (array) get_option( self::OPT_RETIRED, array() );
		if ( ! in_array( $number, $retired, true ) ) {
			$retired[] = $number;
			update_option( self::OPT_RETIRED, $retired );
		}
	}

	/*
	 * -----------------------------------------------------------------------
	 * Approval.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Approve an application into a group, creating the member.
	 *
	 * Creates the WordPress user, assigns the next number if this is The 35,
	 * stores the real name as private meta and the public identity as the
	 * display name, tags the user with the group, links the two records, logs
	 * the event to the spine, and fires the welcome email.
	 *
	 * @param int    $application_id The ff_applications row id.
	 * @param string $group_slug     Either 'the-35' or 'the-circle'.
	 * @return int|WP_Error The new user id, or a WP_Error explaining the failure.
	 */
	public static function approve( $application_id, $group_slug ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ff_applications';

		// Load the application.
		$app = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $application_id )
		);

		if ( ! $app ) {
			return new WP_Error( 'ff_not_found', __( 'That application could not be found.', 'founding-faces' ) );
		}

		// Don't approve the same application twice.
		if ( ! empty( $app->user_id ) ) {
			return new WP_Error( 'ff_already', __( 'That application has already been approved.', 'founding-faces' ) );
		}

		// A WordPress user can't share an email with an existing one.
		if ( email_exists( $app->email ) ) {
			return new WP_Error( 'ff_email_exists', __( 'A WordPress user already exists with that email address.', 'founding-faces' ) );
		}

		// Work out the public identity and assign a number if this is The 35.
		$is_35        = ( 'the-35' === $group_slug );
		$number       = $is_35 ? self::assign_next_number() : null;
		$first_name   = self::first_name_from( $app->name );
		$public_name  = $is_35 ? sprintf( __( 'Founding Face %d', 'founding-faces' ), $number ) : $first_name;

		// Build a unique, sensible username from the email address.
		$username = self::unique_username_from_email( $app->email );

		// Create the WordPress user. A strong random password is set now; the
		// member sets their own via the secure link in the welcome email.
		$user_id = wp_insert_user(
			array(
				'user_login'   => $username,
				'user_email'   => $app->email,
				'user_pass'    => wp_generate_password( 24, true, true ),
				'display_name' => $public_name,
				'nickname'     => $public_name,
				'role'         => 'subscriber',
			)
		);

		if ( is_wp_error( $user_id ) ) {
			// If we'd already advanced the sequence, retire that number so it is
			// never silently reused after this failure.
			if ( $is_35 && $number ) {
				self::retire_number( $number );
			}
			return $user_id;
		}

		// Store the member's meta. The real name lives only here, privately.
		update_user_meta( $user_id, self::META_REAL_NAME, $app->name );
		update_user_meta( $user_id, self::META_PUBLIC_NAME, $public_name );
		update_user_meta( $user_id, self::META_GROUP, $group_slug );
		update_user_meta( $user_id, self::META_APP_ID, (int) $app->id );
		update_user_meta( $user_id, self::META_IS_TEST, (int) $app->is_test );
		// Mirror the stored consent flag onto the member, so the email-sync
		// gate and the account-page toggle both read from one place.
		update_user_meta( $user_id, self::META_CONSENT, (int) $app->consent );
		// Mirror the postcode so the map can read it without ever touching the
		// sensitive application table or the postal address.
		update_user_meta( $user_id, self::META_POSTCODE, $app->postcode );
		if ( $is_35 ) {
			update_user_meta( $user_id, self::META_NUMBER, $number );
		}

		// Tag the user with the group taxonomy term (drives gating and email
		// segmentation later).
		wp_set_object_terms( $user_id, $group_slug, FF_Post_Types::GROUP_TAXONOMY, false );

		// Update the application: mark decided, link the user, record the number.
		$wpdb->update(
			$table,
			array(
				'status'          => $is_35 ? 'approved-35' : 'approved-circle',
				'user_id'         => $user_id,
				'assigned_number' => $number,
			),
			array( 'id' => (int) $app->id ),
			array( '%s', '%d', ( null === $number ) ? null : '%d' ),
			array( '%d' )
		);

		// Record the moment on the spine.
		FF_Interactions::log( $user_id, 'approved', (int) $app->id );

		// Send the group-specific welcome email.
		self::send_welcome_email( $user_id );

		// Let other parts of the plugin react to a new member, the email
		// connector uses this to sync the member to the active platform.
		do_action( 'ff_member_approved', $user_id );

		return $user_id;
	}

	/**
	 * Promote an existing Circle member into The 35.
	 *
	 * The applicant was already approved into The Circle (so they have a member
	 * account and a password). This elevates them: assigns the next Founding
	 * number, moves their group to The 35, updates their public identity, links
	 * the change back to the application, logs it, sends the congratulations
	 * email, and re-syncs them to the email platform in the new group.
	 *
	 * @param int $application_id The ff_applications row id.
	 * @return int|WP_Error The member's user id, or a WP_Error.
	 */
	public static function promote_to_35( $application_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ff_applications';
		$app   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $application_id )
		);

		if ( ! $app || empty( $app->user_id ) ) {
			return new WP_Error( 'ff_no_member', __( 'That application has no member to promote.', 'founding-faces' ) );
		}

		$user_id = (int) $app->user_id;

		// Must currently be a Circle member, still active, not already The 35.
		if ( get_user_meta( $user_id, self::META_DEACTIVATED, true ) ) {
			return new WP_Error( 'ff_deactivated_member', __( 'That member is no longer active.', 'founding-faces' ) );
		}
		if ( self::META_NUMBER && get_user_meta( $user_id, self::META_NUMBER, true ) ) {
			return new WP_Error( 'ff_already_35', __( 'That member is already one of The 35.', 'founding-faces' ) );
		}

		// Assign the next Founding number and build the new public identity.
		$number      = self::assign_next_number();
		$public_name = sprintf(
			/* translators: %d is the Founding number. */
			__( 'Founding Face %d', 'founding-faces' ),
			$number
		);

		// Move the member into The 35.
		update_user_meta( $user_id, self::META_NUMBER, $number );
		update_user_meta( $user_id, self::META_GROUP, 'the-35' );
		update_user_meta( $user_id, self::META_PUBLIC_NAME, $public_name );
		wp_update_user( array(
			'ID'           => $user_id,
			'display_name' => $public_name,
			'nickname'     => $public_name,
		) );
		wp_set_object_terms( $user_id, 'the-35', FF_Post_Types::GROUP_TAXONOMY, false );

		// Reflect the change on the application record.
		$wpdb->update(
			$table,
			array(
				'status'          => 'approved-35',
				'assigned_number' => $number,
			),
			array( 'id' => (int) $app->id ),
			array( '%s', '%d' ),
			array( '%d' )
		);

		// Record the moment and tell the member.
		FF_Interactions::log( $user_id, 'promoted', (int) $app->id );
		FF_Emails::send_promotion( $user_id );

		// Re-sync to the email platform: their group (segment) changed.
		do_action( 'ff_member_approved', $user_id );

		return $user_id;
	}

	/**
	 * Decline an application.
	 *
	 * No user is created; the record is simply marked declined. The sensitive
	 * answers stay in ff_applications for Nick's reference until deleted.
	 *
	 * @param int $application_id The ff_applications row id.
	 * @return true|WP_Error
	 */
	public static function decline( $application_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ff_applications';

		// Read the applicant before updating, so the decline email has a name
		// and address to go to (a declined applicant never has a user account).
		$app = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $application_id )
		);

		$updated = $wpdb->update(
			$table,
			array( 'status' => 'declined' ),
			array( 'id' => (int) $application_id ),
			array( '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'ff_decline_failed', __( 'The application could not be updated.', 'founding-faces' ) );
		}

		// A decision is never silence: tell them, kindly. Sending is skipped
		// automatically if the template body has been emptied in Settings.
		if ( $app && ! empty( $app->email ) ) {
			FF_Emails::send_decline( isset( $app->name ) ? $app->name : '', $app->email );

			// Declined is a status, not a deletion. They stay on the list under
			// it, so they can be written to again if places open up.
			FF_Connectors::sync_applicant( $app, 'declined' );
		}

		return true;
	}

	/**
	 * Withdraw a member: deactivate the account and retire their number.
	 *
	 * The WordPress user is not deleted, so a retired number stays reserved and
	 * the honest record survives. Deletion of personal data is a separate,
	 * deliberate action in the privacy stage.
	 *
	 * @param int $application_id The ff_applications row id.
	 * @return true|WP_Error
	 */
	public static function withdraw( $application_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ff_applications';
		$app   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $application_id )
		);

		if ( ! $app || empty( $app->user_id ) ) {
			return new WP_Error( 'ff_no_member', __( 'That application has no member to withdraw.', 'founding-faces' ) );
		}

		// Retire the number if they had one.
		if ( ! empty( $app->assigned_number ) ) {
			self::retire_number( (int) $app->assigned_number );
		}

		// Deactivate rather than delete: flag the account so login is blocked.
		update_user_meta( (int) $app->user_id, self::META_DEACTIVATED, 1 );

		// Mark the application withdrawn.
		$wpdb->update(
			$table,
			array( 'status' => 'withdrawn' ),
			array( 'id' => (int) $app->id ),
			array( '%s' ),
			array( '%d' )
		);

		// Their status on the platform moves with them. Withdrawing is not
		// unsubscribing: that is the member's own decision and this isn't it.
		FF_Connectors::sync_member( (int) $app->user_id );

		return true;
	}

	/**
	 * Stop a deactivated member from logging in.
	 *
	 * Runs on WordPress's authentication filter. If the user carries the
	 * deactivated flag, login is refused with a clear message.
	 *
	 * @param null|WP_User|WP_Error $user     The user or error so far.
	 * @param string                $username The submitted username.
	 * @param string                $password The submitted password.
	 * @return null|WP_User|WP_Error
	 */
	public static function block_deactivated_login( $user, $username, $password ) {
		if ( $user instanceof WP_User && get_user_meta( $user->ID, self::META_DEACTIVATED, true ) ) {
			return new WP_Error( 'ff_deactivated', __( 'This account is no longer active.', 'founding-faces' ) );
		}
		return $user;
	}

	/*
	 * -----------------------------------------------------------------------
	 * Welcome email.
	 * Interim implementation: a plain group-specific email so the resend button
	 * is testable now. Stage 4 replaces the body of this method with editable
	 * templates and a secure one-time set-password link.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Send the group-specific welcome email to a member.
	 *
	 * @param int $user_id The member's WordPress user id.
	 * @return bool Whether the email was handed to wp_mail successfully.
	 */
	public static function send_welcome_email( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$number = get_user_meta( $user_id, self::META_NUMBER, true );
		$blog   = get_bloginfo( 'name' );

		if ( $number ) {
			/* translators: %d is the member's Founding number. */
			$subject = __( 'Welcome, you are one of The 35', 'founding-faces' );
			$body    = sprintf(
				/* translators: 1: member number, 2: site name. */
				__( "Welcome to Founding Faces.\n\nYou are Founding Face %1\$d.\n\nWe'll send your secure sign-in link shortly so you can set your password and see inside %2\$s.", 'founding-faces' ),
				(int) $number,
				$blog
			);
		} else {
			$subject = __( 'Welcome to the Apotheca community', 'founding-faces' );
			$body    = sprintf(
				/* translators: %s is the site name. */
				__( "Welcome to Founding Faces.\n\nYou're now part of the Apotheca community. We'll send your secure sign-in link shortly so you can set your password and see inside %s.", 'founding-faces' ),
				$blog
			);
		}

		// Let a later stage take over delivery entirely if it wants to.
		if ( has_action( 'ff_send_welcome_email' ) ) {
			do_action( 'ff_send_welcome_email', $user_id );
			return true;
		}

		return wp_mail( $user->user_email, $subject, $body, FF_Emails::headers() );
	}

	/*
	 * -----------------------------------------------------------------------
	 * Moderation request handler.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Process a moderation button press from the admin queue.
	 *
	 * Checks the current user is allowed, verifies the nonce, runs the chosen
	 * action, then redirects back to the queue with a short status message.
	 *
	 * @return void
	 */
	public static function handle_moderation() {
		// Only administrators moderate applications.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'founding-faces' ) );
		}

		$app_id = isset( $_POST['ff_app_id'] ) ? absint( wp_unslash( $_POST['ff_app_id'] ) ) : 0;
		$sub    = isset( $_POST['ff_sub'] ) ? sanitize_key( wp_unslash( $_POST['ff_sub'] ) ) : '';

		// Verify the nonce tied to this specific application and action.
		check_admin_referer( self::MODERATE_ACTION . '_' . $app_id );

		$msg = 'error';

		switch ( $sub ) {
			case 'approve_35':
				$result = self::approve( $app_id, 'the-35' );
				$msg    = is_wp_error( $result ) ? $result->get_error_code() : 'approved_35';
				break;

			case 'approve_circle':
				$result = self::approve( $app_id, 'the-circle' );
				$msg    = is_wp_error( $result ) ? $result->get_error_code() : 'approved_circle';
				break;

			case 'promote_35':
				$result = self::promote_to_35( $app_id );
				$msg    = is_wp_error( $result ) ? $result->get_error_code() : 'promoted_35';
				break;

			case 'decline':
				$result = self::decline( $app_id );
				$msg    = is_wp_error( $result ) ? $result->get_error_code() : 'declined';
				break;

			case 'withdraw':
				$result = self::withdraw( $app_id );
				$msg    = is_wp_error( $result ) ? $result->get_error_code() : 'withdrawn';
				break;

			case 'resend':
				$result = self::resend_welcome( $app_id );
				$msg    = is_wp_error( $result ) ? $result->get_error_code() : 'resent';
				break;
		}

		// Back to the queue with a message code.
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'   => 'founding-faces',
					'ff_msg' => $msg,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Resend the welcome email to the member behind an application.
	 *
	 * @param int $application_id The ff_applications row id.
	 * @return true|WP_Error
	 */
	public static function resend_welcome( $application_id ) {
		global $wpdb;

		$user_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT user_id FROM {$wpdb->prefix}ff_applications WHERE id = %d",
				$application_id
			)
		);

		if ( ! $user_id ) {
			return new WP_Error( 'ff_no_member', __( 'That application has no member to email.', 'founding-faces' ) );
		}

		self::send_welcome_email( (int) $user_id );
		return true;
	}

	/*
	 * -----------------------------------------------------------------------
	 * Small helpers.
	 * -----------------------------------------------------------------------
	 */

	/*
	 * -----------------------------------------------------------------------
	 * Test mode and numbering reset.
	 * Test accounts take real numbers, so a clean reset must zero the sequence
	 * AND clear the retired list together, or testing quietly poisons the launch.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * Whether any real (non-test) numbered member exists.
	 *
	 * The guarded reset refuses to run if this is true, so it physically cannot
	 * disturb a real Founding Face even if mis-clicked.
	 *
	 * @return bool
	 */
	public static function has_real_numbered_member() {
		$ids = get_users( array(
			'meta_key'     => self::META_NUMBER, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_compare' => 'EXISTS',
			'fields'       => 'ID',
		) );
		foreach ( $ids as $uid ) {
			if ( ! get_user_meta( $uid, self::META_IS_TEST, true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Reset the numbering sequence to zero and clear the retired-numbers list.
	 *
	 * Both together: numbers retire and never reuse, so testing leaves retired
	 * numbers behind. Zeroing the sequence alone would still skip those, so the
	 * retired list must be cleared too for a true clean slate.
	 *
	 * @return void
	 */
	public static function reset_numbering() {
		update_option( self::OPT_SEQUENCE, 0 );
		update_option( self::OPT_RETIRED, array() );
	}

	/**
	 * Create a test member: a test-flagged application, approved into a group.
	 *
	 * Test accounts take real numbers (just like real ones), so this exercises
	 * the whole flow, numbering, welcome email, map, without touching real
	 * data. Consent is off, so a test account never syncs to the email platform.
	 *
	 * @param string $group_slug Either 'the-35' or 'the-circle'.
	 * @return int|WP_Error The new user id, or an error.
	 */
	public static function create_test_member( $group_slug, $email = '', $name = '', $consent = false ) {
		global $wpdb;

		$host  = wp_parse_url( home_url(), PHP_URL_HOST );
		$host  = $host ? $host : 'example.com';
		$token = uniqid();

		// An address of your own turns a test account into a seat in the room:
		// everything The 35 is sent arrives where you can read it. Without one
		// the account keeps its unreachable placeholder, which is what stops a
		// shelf of old test accounts bouncing mail and spoiling the domain.
		$email = is_email( $email ) ? sanitize_email( $email ) : '';
		if ( $email && email_exists( $email ) ) {
			return new WP_Error( 'ff_test_email_taken', __( 'There is already an account on that email address.', 'founding-faces' ) );
		}
		$name = trim( wp_strip_all_tags( (string) $name ) );

		// A spread of real postcodes so the map has something to show.
		$postcodes = array( '2000', '3000', '4000', '5000', '6000', '7000', '0800', '2600' );
		$postcode  = $postcodes[ array_rand( $postcodes ) ];

		// A test account with empty fields makes the moderation screen look
		// broken rather than empty: you cannot tell a column that shows
		// nothing from one that is not working. So it carries the kind of
		// answer a real applicant writes, at the kind of length they write it.
		$sample = self::sample_application();

		$now = current_time( 'mysql' );

		$wpdb->insert(
			$wpdb->prefix . 'ff_applications',
			array(
				'created_at'    => $now,
				'name'          => '' !== $name ? $name : $sample['name'],
				'email'         => $email ? $email : self::placeholder_email( $token, $host ),
				'postcode'      => $postcode,
				'instagram'     => $sample['instagram'],
				'skin_concerns' => $sample['concerns'],
				'answers'       => $sample['answers'],
				// Consent only where there is an address that can actually
				// receive, and only because you asked for it on this one.
				'consent'       => ( $email && $consent ) ? 1 : 0,
				'consent_at'    => ( $email && $consent ) ? $now : null,
				'status'        => 'pending',
				'assigned_number' => null,
				'user_id'       => null,
				'is_test'       => 1,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%d' )
		);

		$app_id = (int) $wpdb->insert_id;
		if ( ! $app_id ) {
			return new WP_Error( 'ff_test_failed', __( 'Could not create the test application.', 'founding-faces' ) );
		}

		// Approve it just like a real one, so it takes a real number.
		return self::approve( $app_id, $group_slug );
	}

	/**
	 * A plausible application, for a test account to carry.
	 *
	 * Written the way the people this programme is for actually write: a
	 * specific history, a specific frustration, and a reason that is about the
	 * formulation rather than about free product.
	 *
	 * @return array name, instagram, concerns, answers.
	 */
	private static function sample_application() {
		$people = array(
			array(
				'name'      => 'Marguerite Fenn',
				'instagram' => '@margueritefenn',
				'concerns'  => 'Dryness, early pigmentation, occasional reactivity around the nose',
				'answers'   => "I'm 41 and my skin changed over about a year. I've been on a retinol two nights a week since 2024 and it suits me, but everything else I try either sits on top or stings.\n\nI'd like to join because I'd rather understand what's in a formula than be told it's clean.",
			),
			array(
				'name'      => 'Priya Raman',
				'instagram' => '@priya.raman',
				'concerns'  => 'Sensitivity and redness, worse in winter',
				'answers'   => "My skin reacts to almost every fragranced product, so I've ended up with a routine of four things I'm afraid to change.\n\nI'm interested in watching something get made and understanding why it ends up the way it does.",
			),
			array(
				'name'      => 'Thomas Oyelaran',
				'instagram' => '',
				'concerns'  => 'Texture and dullness, some congestion along the jaw',
				'answers'   => "I've never had a routine beyond a cleanser and whatever moisturiser was on offer. At 38 that has stopped being enough.\n\nI'd like to be told what things do rather than what they promise.",
			),
			array(
				'name'      => 'Jo Whitlam',
				'instagram' => '@jowhitlam',
				'concerns'  => 'Barrier damage after over-exfoliating, tightness after washing',
				'answers'   => "I spent most of last year making my skin worse with acids, which I now understand. It is calmer but it is not back.\n\nI want to follow the reasoning behind a formula, including the versions that do not work.",
			),
		);

		return $people[ array_rand( $people ) ];
	}

	/**
	 * The unreachable address a test account gets when none was given.
	 *
	 * @param string $token A unique string.
	 * @param string $host  The site's host.
	 * @return string
	 */
	public static function placeholder_email( $token, $host ) {
		return 'ff-test-' . $token . '@' . $host;
	}

	/**
	 * Whether an address is one of those unreachable placeholders.
	 *
	 * Anything sent to one bounces, and a run of bounces is how a domain's
	 * reputation goes, so this is what keeps old test accounts out of a send.
	 *
	 * @param string $email The address.
	 * @return bool
	 */
	public static function is_placeholder_email( $email ) {
		return 1 === preg_match( '/^ff-test-[a-z0-9]+@/i', (string) $email );
	}

	/**
	 * Delete one test account and everything it did.
	 *
	 * Allowed whenever the account is test-flagged, including after a real
	 * member has a number and the guarded reset has refused for good. The
	 * reset is refused then because it rewinds the numbering for everybody;
	 * removing one test account rewinds nothing, so there is no reason to
	 * refuse it, and leaving a test account in the programme for ever is a
	 * worse answer than letting it be deleted one at a time.
	 *
	 * @param int $user_id The account to remove.
	 * @return true|WP_Error
	 */
	public static function delete_test_member( $user_id ) {
		global $wpdb;

		$user_id = absint( $user_id );
		if ( ! $user_id || ! get_user_meta( $user_id, self::META_IS_TEST, true ) ) {
			return new WP_Error( 'ff_not_test', __( 'That account is not a test account, so it was not deleted.', 'founding-faces' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/user.php';

		// Their number goes on the retired list, exactly as a withdrawal does,
		// so it is never handed to anybody else.
		$number = get_user_meta( $user_id, self::META_NUMBER, true );
		if ( $number ) {
			self::retire_number( (int) $number );
		}

		$wpdb->delete( $wpdb->prefix . 'ff_applications', array( 'user_id' => $user_id ), array( '%d' ) );
		$wpdb->delete( $wpdb->prefix . 'ff_poll_votes', array( 'member_id' => $user_id ), array( '%d' ) );
		$wpdb->delete( $wpdb->prefix . 'ff_interactions', array( 'member_id' => $user_id ), array( '%d' ) );
		wp_delete_user( $user_id );

		return true;
	}

	/**
	 * Run the guarded test reset: delete test accounts and reset numbering.
	 *
	 * Deletes every test-flagged account (and any leftover test applications),
	 * then zeroes the sequence and clears the retired list, all together, so
	 * the next approved member of The 35 becomes 01 with no gaps. Refuses to run
	 * if any real numbered member exists.
	 *
	 * @return int|WP_Error The number of test accounts removed, or an error.
	 */
	public static function run_test_reset() {
		global $wpdb;

		// Hard guard: never touch anything if a real numbered member exists.
		if ( self::has_real_numbered_member() ) {
			return new WP_Error( 'ff_real_exists', __( 'A real numbered member exists, the reset was refused.', 'founding-faces' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/user.php';

		// Every test-flagged member account.
		$test_ids = get_users( array(
			'meta_key'   => self::META_IS_TEST, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value' => '1', // phpcs:ignore WordPress.DB.SlowDBQuery
			'fields'     => 'ID',
		) );

		$count = 0;
		foreach ( $test_ids as $uid ) {
			$uid = (int) $uid;
			// Remove the test account's rows across the plugin's tables.
			$wpdb->delete( $wpdb->prefix . 'ff_applications', array( 'user_id' => $uid ), array( '%d' ) );
			$wpdb->delete( $wpdb->prefix . 'ff_poll_votes', array( 'member_id' => $uid ), array( '%d' ) );
			$wpdb->delete( $wpdb->prefix . 'ff_interactions', array( 'member_id' => $uid ), array( '%d' ) );
			wp_delete_user( $uid );
			$count++;
		}

		// Remove any leftover test applications that never became members.
		$wpdb->delete( $wpdb->prefix . 'ff_applications', array( 'is_test' => 1 ), array( '%d' ) );

		// Zero the sequence and clear the retired list together, true clean slate.
		self::reset_numbering();

		return $count;
	}

	/*
	 * -----------------------------------------------------------------------
	 * Portal display identity (The 35 only).
	 * A member of The 35 may opt up from their number to also show their first
	 * name, or their full name. The Circle has no public display, so this never
	 * applies to them. Everything member-facing resolves identity through
	 * portal_display_name(), so one preference change updates the whole portal at
	 * once. The members map never reads any of this, it stays anonymous.
	 * -----------------------------------------------------------------------
	 */

	/*
	 * -----------------------------------------------------------------------
	 * Status, and the tags that hang off a member.
	 * -----------------------------------------------------------------------
	 */

	/**
	 * The five states a person can be in, as the email platform sees them.
	 *
	 * @return array Map of slug => label.
	 */
	public static function statuses() {
		return array(
			'applicant'  => __( 'Applicant', 'founding-faces' ),
			'the-35'     => __( 'The 35', 'founding-faces' ),
			'the-circle' => __( 'The Circle', 'founding-faces' ),
			'declined'   => __( 'Declined', 'founding-faces' ),
			'withdrawn'  => __( 'Withdrawn', 'founding-faces' ),
		);
	}

	/**
	 * Where a member stands, worked out rather than stored.
	 *
	 * Nothing here is a second copy of anything: withdrawal is the deactivated
	 * flag, The 35 is having a number. A stored status field would be one more
	 * thing to keep in step, and the first thing to go wrong.
	 *
	 * @param int $user_id The member's user id.
	 * @return string A statuses() key.
	 */
	public static function status( $user_id ) {
		if ( get_user_meta( $user_id, self::META_DEACTIVATED, true ) ) {
			return 'withdrawn';
		}

		$number = get_user_meta( $user_id, self::META_NUMBER, true );
		if ( '' !== (string) $number ) {
			return 'the-35';
		}

		return 'the-circle';
	}

	/**
	 * A status label from its slug.
	 *
	 * @param string $slug A statuses() key.
	 * @return string
	 */
	public static function status_label( $slug ) {
		$all = self::statuses();
		return isset( $all[ $slug ] ) ? $all[ $slug ] : $slug;
	}

	/**
	 * A member's tags.
	 *
	 * @param int $user_id The member's user id.
	 * @return array A list of slugs, in the order they were added.
	 */
	public static function tags( $user_id ) {
		$tags = get_user_meta( $user_id, self::META_TAGS, true );
		return is_array( $tags ) ? array_values( $tags ) : array();
	}

	/**
	 * Replace a member's tags outright.
	 *
	 * @param int   $user_id The member's user id.
	 * @param array $tags    The tags to keep.
	 * @return array The tags as stored.
	 */
	public static function set_tags( $user_id, $tags ) {
		$clean = array();

		foreach ( (array) $tags as $tag ) {
			$tag = self::clean_tag( $tag );
			if ( '' !== $tag && ! in_array( $tag, $clean, true ) ) {
				$clean[] = $tag;
			}
		}

		update_user_meta( $user_id, self::META_TAGS, $clean );

		return $clean;
	}

	/**
	 * Add one tag, and push the change out to the email platform.
	 *
	 * Silent when the member already has it, so this can be called from
	 * anywhere something happens without first checking whether it is news.
	 *
	 * @param int    $user_id The member's user id.
	 * @param string $tag     The tag.
	 * @return bool Whether anything changed.
	 */
	public static function add_tag( $user_id, $tag ) {
		$tag = self::clean_tag( $tag );
		if ( '' === $tag ) {
			return false;
		}

		$tags = self::tags( $user_id );
		if ( in_array( $tag, $tags, true ) ) {
			return false;
		}

		$tags[] = $tag;
		self::set_tags( $user_id, $tags );
		FF_Connectors::sync_member( $user_id );

		return true;
	}

	/**
	 * Remove one tag, and push the change out.
	 *
	 * @param int    $user_id The member's user id.
	 * @param string $tag     The tag.
	 * @return bool Whether anything changed.
	 */
	public static function remove_tag( $user_id, $tag ) {
		$tag  = self::clean_tag( $tag );
		$tags = self::tags( $user_id );

		if ( ! in_array( $tag, $tags, true ) ) {
			return false;
		}

		self::set_tags( $user_id, array_diff( $tags, array( $tag ) ) );
		FF_Connectors::sync_member( $user_id );

		return true;
	}

	/**
	 * A tag reduced to something safe to segment on.
	 *
	 * Lower case, hyphens, no pipes: the pipe is the separator Campaign Monitor
	 * gets, and a tag containing one would split itself in two.
	 *
	 * @param string $tag The tag as given.
	 * @return string
	 */
	private static function clean_tag( $tag ) {
		$tag = strtolower( trim( (string) $tag ) );
		$tag = preg_replace( '/[^a-z0-9\-_]+/', '-', $tag );
		$tag = preg_replace( '/-+/', '-', $tag );

		return trim( (string) $tag, '-' );
	}

	/**
	 * The three display tiers for The 35, most private first.
	 *
	 * @return array Map of tier key => human label.
	 */
	public static function display_tiers() {
		return array(
			'number'       => __( 'Number only', 'founding-faces' ),
			'first_number' => __( 'First name and number', 'founding-faces' ),
			'full_number'  => __( 'Full name and number', 'founding-faces' ),
		);
	}

	/**
	 * The member's chosen display tier, defaulting to the most private.
	 *
	 * @param int $user_id The member's user id.
	 * @return string One of the display_tiers() keys.
	 */
	public static function display_tier( $user_id ) {
		$tier = get_user_meta( $user_id, self::META_DISPLAY_TIER, true );
		return array_key_exists( $tier, self::display_tiers() ) ? $tier : 'number';
	}

	/**
	 * Resolve how a member's identity should read in the members portal.
	 *
	 * For The 35 this honours their chosen tier (number only by default; first
	 * name and number; or full name and number). A name tier with no stored name
	 * safely falls back to the number. For The Circle it returns their existing
	 * public name (first name) unchanged. This is the single place portal
	 * identity is computed, so changing the preference updates it everywhere.
	 *
	 * @param int $user_id The member's user id.
	 * @return string
	 */
	public static function portal_display_name( $user_id ) {
		$number = get_user_meta( $user_id, self::META_NUMBER, true );

		// The Circle (no number): unchanged, their stored public name.
		if ( ! $number ) {
			$public = get_user_meta( $user_id, self::META_PUBLIC_NAME, true );
			if ( $public ) {
				return $public;
			}
			$user = get_userdata( $user_id );
			return $user ? $user->display_name : '';
		}

		// The 35: the number is always present; a name is a deliberate opt-up.
		$number_label = sprintf(
			/* translators: %d is the member's Founding number. */
			__( 'Founding Face %d', 'founding-faces' ),
			(int) $number
		);
		$tier = self::display_tier( $user_id );
		$real = trim( (string) get_user_meta( $user_id, self::META_REAL_NAME, true ) );

		if ( '' !== $real && 'full_number' === $tier ) {
			/* translators: 1: the member's name, 2: "Founding Face N". */
			return sprintf( __( '%1$s, %2$s', 'founding-faces' ), $real, $number_label );
		}
		if ( '' !== $real && 'first_number' === $tier ) {
			$first = preg_split( '/\s+/', $real )[0];
			/* translators: 1: the member's name, 2: "Founding Face N". */
			return sprintf( __( '%1$s, %2$s', 'founding-faces' ), $first, $number_label );
		}

		return $number_label;
	}

	/**
	 * The label to show Nick for a member in admin screens.
	 *
	 * Governing principle 1: Nick always sees who someone is. So this returns the
	 * private real name, falling back to the portal identity, then the number.
	 *
	 * @param int $user_id The member's user id.
	 * @return string
	 */
	public static function admin_label( $user_id ) {
		$real = trim( (string) get_user_meta( $user_id, self::META_REAL_NAME, true ) );
		if ( '' !== $real ) {
			return $real;
		}
		return self::portal_display_name( $user_id );
	}

	/**
	 * Recompute and store a The 35 member's portal identity from their tier.
	 *
	 * Keeps the stored public name and WordPress display name in step with the
	 * resolved identity, so any consumer that reads those (not just the live
	 * resolver) reflects the preference too. No effect for The Circle.
	 *
	 * @param int $user_id The member's user id.
	 * @return void
	 */
	public static function sync_portal_identity( $user_id ) {
		if ( ! get_user_meta( $user_id, self::META_NUMBER, true ) ) {
			return;
		}
		$display = self::portal_display_name( $user_id );
		update_user_meta( $user_id, self::META_PUBLIC_NAME, $display );
		wp_update_user( array(
			'ID'           => $user_id,
			'display_name' => $display,
			'nickname'     => $display,
		) );
	}

	/**
	 * Pull a first name out of a full name, for The Circle's public identity.
	 *
	 * @param string $full_name The applicant's full name.
	 * @return string The first word, or the whole string if there's no space.
	 */
	private static function first_name_from( $full_name ) {
		$full_name = trim( (string) $full_name );
		if ( '' === $full_name ) {
			return __( 'Member', 'founding-faces' );
		}
		$parts = preg_split( '/\s+/', $full_name );
		return $parts[0];
	}

	/**
	 * Build a unique WordPress username from an email address.
	 *
	 * Uses the part before the @, cleaned to a safe username, then appends a
	 * number if that login is already taken.
	 *
	 * @param string $email The applicant's email.
	 * @return string A username that isn't yet in use.
	 */
	private static function unique_username_from_email( $email ) {
		$base = sanitize_user( current( explode( '@', $email ) ), true );
		if ( '' === $base ) {
			$base = 'member';
		}

		$username = $base;
		$suffix   = 1;
		while ( username_exists( $username ) ) {
			$suffix++;
			$username = $base . $suffix;
		}
		return $username;
	}
}
