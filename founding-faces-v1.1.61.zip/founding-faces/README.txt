=== Founding Faces ===
Contributors: KDNA
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.1.61
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Runs the entire private membership programme for Apotheca: applications,
moderation into The 35 or The Circle, member creation, formulation notes,
polls, an anonymous members map, and email-platform sync.

== Description ==

Founding Faces is a single, lean plugin that runs the Apotheca private
membership programme end to end. It is built in stages; each stage installs
and is testable on its own.

Governing principles:

1. Members are a number to the public, never to Nick.
2. Publication, not conversation. No feeds, chat or notifications.
3. Everything is tagged to member and date from the start.
4. Lean, always. Native WordPress over libraries; nothing loads where the
   plugin isn't running.

== Build progress ==

Stage 1: Foundation & data layer
* Plugin activates cleanly.
* Three custom tables created: ff_applications, ff_poll_votes, ff_interactions.
* Products (ff_product) and Notes (ff_note) post types registered.
* Group taxonomy (ff_group) registered on users, seeded with the two terms
  "The 35" and "The Circle".

Stage 2: Application form & status lookup
* Front-end application form via [ff_application_form] shortcode (works in
  Elementor too), storing submissions to ff_applications as pending with the
  consent flag and a timestamp.
* Four-digit Australian postcode field, validated server-side, for the map.
* Logged-out status lookup via [ff_status_lookup], enter your email, see
  pending or decided, without exposing group or number.
* All input sanitised, all output escaped, every submission nonce-protected.

Stage 3: Moderation & member creation
* Admin "Founding Faces" menu with a moderation queue (pending count bubble),
  tabbed by status, showing each application's details.
* Approve into The 35 or The Circle; The 35 gets the next sequential Founding
  number from a monotonic sequence, so a withdrawn number is retired and never
  reused.
* Automatic WordPress user creation on approval, with the real name stored as
  private user meta and the public identity (number, or first name) as the
  display name. Application and member stay two linked records.
* Withdraw deactivates the account (never deletes) and retires the number;
  deactivated members can't log in.
* Resend-welcome-email button. Every action nonce- and capability-checked.
* Interaction-log spine helper (FF_Interactions) in use from approval onward.

Stage 4: Welcome emails & account access
* Group-specific welcome emails on approval, from editable templates on a new
  Settings page (placeholders for name, number, group, links, etc.).
* The 35 email states the assigned Founding number; The Circle email welcomes
  them to the Apotheca community.
* Secure set-password link, a one-time token (SHA-256 hashed, 7-day expiry).
  Members set their own password; a plain-text password is never emailed.
* Set-password and "resend my set-up link" screens live on the WordPress login
  page, so an expired link is never a dead end and no page needs creating.

Stage 5: Email connector + Campaign Monitor
* Abstract FF_Connector contract with a manager that holds the one active
  connector (only one at a time), plus the Campaign Monitor add-on.
* On approval a consented member is synced with name, email, group and number;
  group and number travel as custom fields (Campaign Monitor has no tags).
* Consent is enforced: nothing syncs unless the stored consent flag is true.
  Test accounts are never synced to the live list.
* API key and list ID on the Settings page; the Group and Number custom fields
  are created on the list automatically. Uses WordPress's HTTP API, no SDK.

Stage 6: Products & notes with gating
* Notes (ff_note) are structured records: linked product, date, version number,
  development stage (in development / stability testing / passed / failed),
  a gallery of images and video, and a per-note audience flag (everyone /
  the-35-only), all entered in a clean "Note details" metabox with a
  media-library gallery picker.
* Server-side gating (FF_Gating): can_view_note() plus member / The 35 / The
  Circle checks, the single source of truth for who sees what.
* Elementor "Show to" visibility condition on every element (Everyone /
  Logged-out / All members / The 35 / The Circle), enforced via should_render
  so gated content is never produced or sent to the browser.
* Notes and Products kept out of the REST API to close any path around the gate.

Stage 7: Frontend display
* A note is designed once and rendered automatically: every note (single or in
  a list) goes through one render_note_card() template, so publishing note 30
  is just filling in fields, it appears already styled and on-brand.
* Components as shortcodes (Elementor-compatible): [ff_note], [ff_notes]
  (newest first, filterable by stage with filter chips), [ff_product_header],
  [ff_home] (a hybrid home: latest-notes feed above a products list), and
  [ff_note_gallery] (the note's images and video as a slider).
* Product metabox adds a current stage and a "where it's up to" line.
* Apotheca brand tokens baked into the components; the note markup is
  filterable (ff_render_note) so Elementor Pro Theme Builder can override it.
* Every component runs the 35-only gate server-side: gated notes are filtered
  out before any markup exists, so unauthorised members never receive them.
* First views recorded to the interaction spine (note_viewed) for the later
  personal-history page.

Stage 8: Poll widget
* Polls as a non-public ff_poll type: question, two-or-more options each with an
  optional image, per-poll audience (everyone / the-35-only), open/closed
  status, an "active poll" flag, and an outcome/reasoning field.
* Elementor Atomic widget (Founding Faces Poll): pick a poll or the active one,
  with alignment, accent colour and spacing controls defaulting to Apotheca
  tokens. has_widget_inner_wrapper() correct, single wrapper div. Also a
  [ff_poll] shortcode.
* Results hidden until the member votes; then the aggregate is revealed. Closed
  polls show the aggregate plus Nick's reasoning.
* Votes stored per member in ff_poll_votes (one per member per poll) and logged
  to ff_interactions (vote_cast). Front end is aggregate-only.
* Admin "who voted for what" view on the poll screen: each option's count and
  the members (real name + number) who chose it. Never exposed on the frontend.

Stage 9: Personal history page
* [ff_history] shortcode: a logged-in member sees their number and group, the
  polls they voted in and how they voted, the notes they've read, and any
  feedback they've shared.
* Reads only the current member's own rows from ff_poll_votes and
  ff_interactions, the member id always comes from the session, never the
  request, so no other member's data is ever visible.
* This is the seed of the launch "fingerprint", the same data, later made
  presentable and optionally public with consent.

Stage 10: The members map
* [ff_members_map] shortcode: an anonymous dot per member, placed from their
  postcode via a bundled Australian postcode-to-coordinates table (3,170
  postcodes), no external API call.
* Leaflet (bundled locally, no CDN) with the pale grey Positron OpenStreetMap
  style as the base map, from a no-key provider. The tile URL is a single
  setting so it can be repointed later.
* Settings for per-tier dot colour and size (The 35 vs The Circle); dots are
  semi-transparent so dense areas glow, with a tiny stable jitter so shared
  postcodes spread into a soft cluster.
* Reads postcode only (mirrored to user meta on approval), never the postal
  address; no names, no labels, nothing clickable. Deactivated and test
  accounts are excluded. Only coordinates and tier reach the browser.

Bundled data attribution: Australian postcode coordinates derived from the
Matthew Proctor Australian postcodes dataset (matthewproctor.com), deduplicated
to one centroid per postcode.

Stage 11: Account settings
* [ff_account] page: change email (with a confirmation link sent to the new
  address), change password (secure token reset, the same mechanism as the
  welcome link), and edit name.
* Email-consent toggle that writes back through the connector, turning it off
  unsubscribes at Campaign Monitor, not just locally; turning it on re-syncs.
* Self-service data export (CSV) and delete buttons, calling the shared privacy
  core (FF_Privacy): export gathers the whole record; delete removes the
  application and personal meta, unsubscribes, retires (never reuses) the
  number, and anonymises/deactivates the account.
* Number, group and standing are shown read-only, Nick's to control, never the
  member's to edit.

Stage 12: Privacy & admin tools
* Privacy & Tools admin page: per-member CSV export, delete-with-number-
  retention (personal data removed, number retired never reused), and a consent
  audit (who consented and when) in one members table.
* Test mode: create test members (they take real numbers to exercise the whole
  flow; consent off so they never sync to the email platform).
* Guarded reset: deletes ALL test accounts, zeroes the numbering sequence and
  clears the retired list, together, so the next real The 35 member is 01.
  Refuses to run if any real numbered member exists, and requires typing the
  word RESET, not a single click.

Stage 13: Klaviyo add-on
* Second connector implementing the same FF_Connector contract, for when
  Klaviyo is purchased; group sent as BOTH a tag and a profile property.

Stage 14 (this release), Members map Elementor widget & add-on split:
* The members map is now a native Elementor widget (Founding Faces Map, Atomic
  architecture) wrapping the same renderer. The [ff_members_map] shortcode
  still works as a fallback, the widget doesn't replace it.
* Widget controls: centre point (defaults to the centre of Australia), default
  zoom, min/max zoom, scroll-wheel zoom (default off), pan/drag with an option
  to lock panning to Australia's bounds, zoom buttons on/off, map height; dot
  colour/size per tier, dot opacity, optional dot border; base tile source
  (defaults to the plugin Positron setting), container background/border/radius,
  and an optional legend with position. All map behaviour options are standard
  Leaflet options. Still reads postcode only, nothing clickable.
* Leaflet and the widget assets load only where a map is present.
* The connectors are now SEPARATE add-on plugins ("Founding Faces, Campaign
  Monitor" and "Founding Faces, Klaviyo"), each in its own zip. The core
  exposes an 'ff_register_connectors' hook they register through, so the core
  no longer depends on any connector being installed. Install only the platform
  you use; only one is active at a time.

== Changelog ==

= 1.1.61 =
* Test accounts now carry a believable application: a name, an Instagram
  handle, real skin concerns and a few sentences about why they applied. An
  account with every field blank makes the moderation screen look broken
  rather than empty, since a column showing nothing reads the same as one that
  is not working.
* The no-em-dash rule is applied on the way out as well as on the way in. It
  was enforced when copy is saved, which never reached text typed into an
  Elementor widget field or saved before the rule existed. Every piece of
  author copy the plugin renders now passes through it.

= 1.1.60 =
* The posting list now carries what they wrote when they applied as well:
  Instagram, skin concerns, the answer to "tell us a little about your skin
  and why you'd like to join", their email consent and the date they applied.
  The label columns stay first, so the left of the sheet is still ready for a
  mail merge.
* "Unit / care of" is now "Unit, level or care of", on the form as well as in
  the file, with a line explaining what belongs there. It is the optional
  second line of an address: a level or suite, a building name, or a care-of.
  A unit number usually goes in the street line, as 3/45 Smith Street.

= 1.1.59 =
* The 35 can give a postal address, in their own account area, so samples have
  somewhere to go. Street, unit or care of, suburb, state, postcode and
  country, with the browser's own address autofill wired up.
* The Circle are never asked. They receive no samples, and a programme that
  collects an address it has no use for is collecting it for no reason.
* A change emails you, with the new address and the previous one side by side,
  so a label already written can be corrected before the next sendout rather
  than coming back through the post.
* A new posting list on Privacy & Tools: every active member of The 35 in
  number order, with their address, as a CSV that opens in Excel or Numbers.
  Members who have not filled theirs in are listed with Postable set to No, so
  it doubles as the list of who to chase.
* The address is part of a member's own data export, and is removed with the
  rest of their details when they delete their data.
* A member who moves also moves on the members map, which reads the postcode
  from the address rather than keeping the one they applied with.

= 1.1.58 =
* While test accounts hold numbers, "Approve into The 35" is replaced by a
  single button reading "Reset the test accounts". There is no version of this
  where keeping them is right, so there is no longer a question to answer: the
  button that has to be pressed first is the only one offered.
* That replaces a confirmation dialog whose wording asked whether to clear the
  test accounts and whose OK button approved the member anyway. A browser
  dialog can only say OK and Cancel, so the fix was to stop asking.
* The button runs the same guarded reset as Privacy & Tools, which refuses
  outright if a real member holds a number, and it is only ever offered in the
  state where that guard is already satisfied.

= 1.1.57 =
* Approving or promoting into The 35 now asks before it acts, in the words
  that matter at that moment. While test accounts still hold numbers it says
  so and warns that a real number blocks the test reset for good. With every
  place taken it says that instead, and warns about making a thirty-sixth. A
  banner at the top of a screen is easy to scroll past; a question at the
  moment of clicking is not.
* Approving into The Circle is unaffected, since it issues no number and
  closes no door.

= 1.1.56 =
* The applications screen warns, while test accounts still hold numbers and no
  real member has one yet, that they must be cleared before the first real
  approval. The guarded reset refuses to run once a real number exists, and
  the numbering cannot be put back afterwards, so this is the one moment the
  warning is useful.
* A "Delete test account" button on each test account in Privacy & Tools,
  which works whether or not the reset is still available. It removes that
  account, its votes and its history, and retires its number.

= 1.1.55 =
* The applications screen now counts The 35. A line at the top reads "The 35:
  28 of 35 places taken", and says how many of those are test accounts, since
  test accounts take real numbers.
* Once every place is taken, the button that would create a thirty-sixth is
  wrapped in a red box saying so, and asks for confirmation. The same goes for
  "Promote → The 35" on a Circle member.
* Nothing is blocked. A member can leave and their place is genuinely free
  again, and a plugin that refused would be in the way. It only makes the
  consequence impossible to walk past.
* Withdrawing a member frees their place. Their number stays retired, as it
  always has, so it is never issued twice.
* The number of places is a setting, defaulting to 35.

= 1.1.54 =
* The small print under the email card now takes a size and a line height of
  its own, both on the Settings screen beside the wording. Line height is a
  multiple of the size, so 1 sets the lines solid. The unsubscribe link takes
  the same two, so the pair reads as one block.
* The phone-sized rule used to force that type to a fixed 12px, which would
  have overruled the setting. It follows the setting now.

= 1.1.53 =
* Fixed: sending a note to The 35 failed at the mail service with "subject is
  required". The new-note email's subject and body were registered as settings
  but had no fields on the Emails screen, and saving that screen writes every
  setting registered on it, so both were quietly blanked the first time it was
  saved.
* The fields are there now, under "New-note email", with the placeholders
  listed.
* Any email template that is blank now falls back to the wording the plugin
  ships with, rather than sending an empty subject or an empty email. Clearing
  the declined-application body still means send nothing, since that one is
  meant to be silenced.

= 1.1.52 =
* Fixed: the "viewing as" switcher in the toolbar did nothing, while the same
  setting on your own profile worked. It changed the preview by adding
  arguments to whatever screen you were standing on, and a screen is somebody
  else's: it can redirect, rewrite or drop an argument it does not recognise,
  and when it does the switch fails silently. It now posts to an endpoint of
  its own and returns you to the page you were on.

= 1.1.51 =
* The "viewing as" switcher now confirms what it did, reading the setting back
  from the database rather than repeating the click, so a switch that fails to
  save says so instead of agreeing with you.
* The nonce on that link was being lowercased before it was checked, which can
  refuse a perfectly valid request. It is checked as sent now.
* The switch link is built from the current page with its own arguments
  stripped first, so switching twice from one screen cannot stack them up.

= 1.1.50 =
* Fixed: filtering the notes list brought the rows back as bare headings,
  without the picture, the blurb or the date under the title, while the
  unfiltered page above had all three.
* Two faults behind it. The settings that describe how a row is built lived on
  the Load more button, which only exists while there are more notes to load,
  so a filter leaving a handful of notes took them away with it. They now live
  on the section, which is always there. And the script was never sending the
  picture and blurb settings at all, so even with the button present the
  server had to guess.

= 1.1.49 =
* Fixed: a note with a long title dropped its whole text column below the
  picture while its neighbours kept theirs beside, so cards in the same grid
  were laid out differently for no reason a reader could see. The text column
  now always sits beside the picture and takes whatever room is left.

= 1.1.48 =
* Video links on a note, as a repeater: add as many YouTube or Vimeo links as
  you like, in the order you want them, and they follow the gallery in the
  slider. They cost the site nothing to serve and adapt to a weak connection,
  but a link is a link, so anyone who has it can watch.
* Clicking a linked video opens it in the lightbox at its own proportions,
  which is the only way to watch a 16:9 clip properly from a square gallery.
* An uploaded clip now fits inside the frame rather than being cropped to it.
  A still cropped to a square loses its edges, which is usually fine; a 16:9
  clip cropped to a square loses a third of what is going on.
* The gallery's height control governs the player and the embed as well as
  the images, so one frame still holds all three.

= 1.1.47 =
* A gallery holding one image now opens a single image in the lightbox. It was
  opening as a slideshow of one, so clicking through took you from the image
  back to the same image.
* Two galleries on a page are now two separate slideshows. They shared one
  group name before, so paging through either could walk into the other one's
  images.

= 1.1.46 =
* The diagnostics now account for the crop. With "crop to fill", an upright
  frame on a landscape photograph is filled by its height and most of its
  width is discarded, so measuring width against width reported room to spare
  where there was none. It reads the actual fit and scales by the edge that
  governs.
* It also reports what the file weighs, in kilobytes and per megapixel, which
  is how an over-compressed re-encode gives itself away: full resolution,
  almost no bytes. Under about 120KB per megapixel is worth a look.

= 1.1.45 =
* Fixed: the image diagnostics switch was registered in the Video section
  rather than the Gallery one, so it sat under a heading nothing to do with
  it. It is now in Gallery, under "Clicking an image".

= 1.1.44 =
* A "Show image diagnostics" switch on the Note Gallery widget. Under each
  image it prints what the file really is, which file the browser chose, how
  big the frame ended up, the screen's pixel density, and how far the file had
  to be enlarged to fill the frame. It also lists every size WordPress made of
  that image.
* Administrators only, so it can be left on while you work without a member
  ever seeing it.

= 1.1.43 =
* Choosing Full for the gallery now really means full. WordPress hands the
  browser every size it made plus a guess at how wide the slot is, and that
  guess comes from the file rather than from the page, so in a container wider
  than the original the browser could settle on a smaller file than the one
  chosen. With Full chosen the list is withheld and the full file is the only
  option.
* A note in the gallery's image controls about what a frame bigger than the
  photograph does, and what a crop costs, since neither can be fixed by any
  setting.

= 1.1.42 =
* The number has its own controls, apart from the words around it, so
  "{count} founding faces across Australia" can carry a large accent figure in
  an ordinary sentence. Typography, colour, background, border, corner radius
  and padding, covering {count}, {the35} and {circle} alike.

= 1.1.41 =
* The member count keeps its full style controls wherever it sits, in the key
  as well as above or below the map: typography, colour, alignment,
  background, border, corner radius, shadow, padding and margin. One set of
  controls, so they no longer change under you when the position does.
* A line above the count, for separating the total from the two keys, with
  its own colour, thickness and the space above it.
* A new Key style section, which the key box never had: typography, text
  colour, background, border, corner radius, shadow, padding, how far it sits
  from the map edge, the space between its lines and the space between a dot
  and its label.

= 1.1.40 =
* Fixed: the no-poll message was laid out as though it were a poll, so on a
  two or three column archive it wrapped inside one column's width with the
  rest of the row empty beside it. It now takes the whole row.

= 1.1.39 =
* The empty Active tab now shows the wording from "When there is no poll",
  the message you already wrote, rather than a line of its own. It is the same
  moment, and asking for it in two fields is how one of them ends up
  forgotten. Clearing both fields still shows nothing at all.
* The separate "When the open tab is empty" field has gone with it. The past
  tab keeps its own, since nothing else covers that moment.

= 1.1.38 =
* The member count can now sit inside the map key, under The Circle, which is
  where it belongs: it is the sum of the two lines above it. That is the new
  default, with above and below the map still there.
* In the key it takes the key's own styling rather than carrying its own, so
  the box stays one thing. With the key switched off it goes above the map
  instead, since showing the number is what the switch was for.

= 1.1.37 =
* The map can show how many members are on it, above or below the map, with a
  switch to turn it on. Off by default.
* The wording is yours: {count} is everyone on the map, {the35} is The 35 and
  {circle} is the rest. It defaults to "{count} founding faces across
  Australia".
* The number is counted from the dots the map is drawn from, so the two can
  never disagree, and in the Elementor editor it counts the sample dots, which
  means the line can be styled before there is a member on it.
* A Member count style section covers typography, colour, alignment,
  background, border, corner radius, shadow, padding and margin.

= 1.1.36 =
* Both tabs are now always there, with the current polls in front. A tab row
  that appears and disappears with the polls behind it is not navigation, and
  it was the reason a page holding only past polls showed no tabs at all.
* An empty tab says so. Two new fields set what it says, defaulting to "No
  poll open at the moment." and "No past polls yet."
* The open tab is always the one in front, whether or not there is a poll in
  it. A member arriving at the page is being asked something, not handed an
  archive.

= 1.1.35 =
* A poll now has three states that say what they do. Open is taking votes.
  Closed stops the voting and shows the result and your reasoning, with the
  poll staying where it is among the current ones. Moved to past polls files
  it in the archive. To take a poll off the site, set it back to Draft.
* "Auto-hide at" is now "Move to past polls at", which is what it does. It no
  longer removes the poll from the site, so a poll that had quietly vanished
  past its old hide time comes back as a past poll.
* Open and past, in the tabs and the stacked sections, now splits current
  from archived rather than voting from finished. A poll that has just closed
  stands with the current ones, result and all, until you file it.
* Anything marked hidden by 1.1.33 becomes a past poll.
* The On the site column reads Open, Closed with its result on show, In the
  past polls, or Draft, with the date when a schedule did it.

= 1.1.34 =
* A poll taken off the site by its auto-hide time now says so, on the poll
  itself and in the On the site column, with the date it happened and what to
  do about it. A hide time set months earlier is the one state that was
  impossible to work out from the poll screen.
* The auto-hide field says plainly that it outranks the status: once it
  passes, the poll leaves the site whatever the status says.

= 1.1.33 =
* One poll widget, not two. Everything the Polls Archive did is now a "Show"
  option on Founding Faces Poll: the latest poll, all current polls, open and
  past polls in sections or tabs, or one specific poll. Columns, heights, gap,
  the tab layout and both labels come with it.
* The old Polls Archive widget is off the widget panel but still registered,
  so a page already using it keeps working and can still be edited. Replace it
  when you next touch that page.
* Closing a poll no longer makes it disappear. The status dropdown now has
  three choices: open, closed and kept in the past polls, or hidden. Before
  this, closing a poll with no close or hide time set took it off the site
  entirely, which is why a closed poll could vanish with nothing to say where
  it went. Polls already in that state stay hidden, so nothing reappears
  unasked; switch one to "Closed" to put it in the past polls.
* The polls list has two new columns, whether a poll is on the site and how
  many votes it has had, so a poll you cannot find explains itself.
* Fixed: the Elementor editor showed the no-poll message rather than the
  sample polls whenever that message had been written, which is why the tabs
  never appeared on the canvas.

= 1.1.32 =
* The polls archive can now be tabs rather than one section under the other,
  with the open polls on the first tab and the past ones on the second.
* Both labels are yours to write, in the content tab, and they name the
  headings in the stacked layout as well as the tabs. {count} in a label
  becomes how many polls are in that section, so "Past polls (12)" keeps
  itself up to date.
* Tabs need both sides to have something in them. With no open poll, or none
  closed yet, the archive falls back to a single list rather than offering a
  choice of one.
* A Tabs style section covers alignment, gap, equal or natural widths, space
  below the row, typography, padding and corner radius, with separate normal,
  current and hover states for colour, background, border and shadow. The tabs
  are drawn with nothing on them, so every line of that is yours.
* The tabs work from the keyboard: left and right walk the row, Home and End
  go to its ends, and only the current tab is a tab stop.
* The Elementor editor shows the tabbed layout with sample polls on both
  sides, so a tab row can be styled before a poll has ever closed.

= 1.1.31 =
* A new note can now be announced to The 35. A "Tell The 35" box on the note
  itself sends an email with a link to it. The Circle is not included: they
  cannot see the vault notes anyway, and a list that size belongs in the email
  platform.
* Nothing is sent on publishing. Publishing is how a note is saved, and notes
  get edited and republished, so it is a button you press, with a record of
  when it was pressed, who pressed it and how many it reached.
* The send goes out in batches, ten at a time with five minutes between by
  default, both settable. Thirty-five identical emails leaving a shared host
  inside a second looks like a spam run to whoever receives them.
* Consent is read again as each batch goes, so an unsubscribe part way through
  a send is honoured rather than arriving late. There is a "send the next batch
  now" button and a stop button while one is running.
* The announcement is a seventh email template, editable and previewable on the
  Emails screen with the rest, and it carries the usual unsubscribe link.
* A test member can now be given a real name and email address, so putting your
  own address on one in The 35 means everything the group is sent arrives where
  you can read it. A test account still holding its generated placeholder
  address is left out of a send, since mail to it only bounces.

= 1.1.30 =
* Video in the note gallery. Add a clip in the same place as the images and it
  takes its turn in the order you chose them, in the slider, on the note card,
  and through the JetEngine gallery callback.
* It is the same field and the same list of attachments as before, so there is
  nothing to migrate and no second gallery to keep in step.
* A new Video section on the Note Gallery widget: player controls, play on
  arrival, loop and start muted. Play on arrival is always silent, because no
  phone will start a video with sound on a page nobody has touched yet.
* The slider holds still while a video is playing and pauses whatever was
  playing when it moves, so sound never carries over from a slide nobody is
  looking at.
* Images and video share one frame, so the height, fit and corner radius set
  for the images govern a clip in the same gallery.
* The Elementor editor's sample gallery now has a video in it, so the player
  can be styled before a note carries a clip.
* In the Member Archive the thumbnail stays a still. A video reaches it only
  through a poster frame set on the attachment.

= 1.1.27 =
* The whole note row is now the link to its note, not just the title. It is a
  link laid over the row rather than one wrapped around it, since the title
  and the picture are already links, and it is hidden from screen readers and
  skipped by the keyboard so the title link stays the one that speaks.
* The title colour control now reaches the title's link as well. Colouring the
  span around it did nothing, because a link takes its colour from the theme.
  The hover colour answers to the row too, since the row-wide link sits over
  the title and takes the pointer.
* New hover controls for note rows: background, border colour and shadow. A
  row that is a link wants something to say so.
* The product text section is now named "Product text (above the title)"
  rather than "Product label", and gains an alignment control.

= 1.1.26 =
* With a picture or a blurb switched on, the date now sits under the title
  rather than off at the right-hand end of the line, where the wrap was
  dropping it beneath the picture.
* Three new spacing controls: a margin for the title, a margin for the date,
  and, in the "Note picture and blurb" section, the gap between the product,
  the title and the date, and the gap above the blurb.

= 1.1.25 =
* The blurb now runs the full width of the row, under the picture, the title
  and the date, rather than sharing the narrow column between them. It was
  reading as one word a line.
* A new "Note picture and blurb" style section holds what was previously left
  to the stylesheet: width, height, fit, focus, corner radius, border, shadow
  and the gap to the title for the picture, and typography, colour, alignment,
  maximum width and margin for the blurb.
* The picture rules name the class and an img inside it, so the image
  optimiser's picture wrapper cannot take the crop back.

= 1.1.24 =
* The Member Archive widget can now show a photograph and a short blurb beside
  each note, the way the Notes widget does. Two new controls sit in the notes
  part of the content tab: "Show note image" and "Blurb words", the latter set
  to 0, meaning off, so nothing changes until you ask for it.
* The photograph is the note's first gallery image. A note without images, or
  without body copy, simply leaves that part out rather than holding a gap.
* The blurb is plain text, so any formatting or shortcodes in the note are
  stripped rather than rendered in miniature.
* Load more carries both settings, so the second page of notes looks like the
  first.

= 1.1.23 =
* Natural origin sits on a line of its own, under the version, date and pH,
  the way the stage badge already does. Its label and figure together are as
  wide as the other three combined, so it was wrapping out of the middle of
  them.
* That also takes away the separator left hanging after the pH. Separators join
  items within a line and never trail off the end of one, and the stray bar was
  the join to an item that had wrapped away.

= 1.1.22 =
* The pH can be a range. A second, optional box on the note turns 5.0 into
  5.0 - 5.5, and the page reads it back the same way. A formula that lands
  between two figures has not been measured badly, it has been specified.
* The change beside it is measured from the first number, so a range still
  reports how far the formula moved.
* A second figure that is not above the first is ignored rather than printed
  backwards, since "5.5 - 5.2" read back to a member is worse than showing the
  one number that is certainly right.

= 1.1.21 =
* A measured figure now reaches the page exactly as it was typed. Both pH and
  natural origin were being run through a number on the way in, which drops
  trailing zeros, so 94.20 arrived as 94.2. Same quantity, different statement:
  the first says the figure was worked to two places.

= 1.1.20 =
* Natural origin takes two decimal places, so 94.25% can be recorded as it was
  calculated rather than rounded on the way in. The change beside it already
  worked to two, so a shift of 0.05 now shows as 0.05 instead of disappearing.

= 1.1.19 =
* The note card's image grid gets the same treatment as the slider: its height
  and corner radius now reach the image inside the <picture> wrapper, and it
  gains the two controls it never had, how the image fills the height and which
  part of it survives the crop.
* Centre is the default, so a bench shot is no longer cropped down to the part
  of the bench above the bowl.
* The corner radius also goes on the tile around the image, so a linked
  thumbnail is clipped to the same shape rather than squaring off its corners.

= 1.1.18 =
* The same <picture> wrapper fault, in the three other places the plugin draws
  an attachment: the note card's own image grid, the poll option images, and
  the JetEngine gallery callback. All three were styling a wrapper on any site
  running a WebP optimiser.
* The JetEngine one used an inline style attribute, which moves to the wrapper
  with nothing left behind and cannot be written against twice. It uses a class
  now, like everything else.

= 1.1.17 =
* Fixed the gallery crop for real, with the cause rather than a guess at it.
  An image optimiser serving WebP wraps each image in a <picture> tag and
  carries our class up onto that wrapper, so every image rule was landing on
  the wrapper while the actual <img> inside was left to Elementor's own
  ".elementor img { height: auto }". The editor never showed it because its
  sample images are plain img tags that never get wrapped.
* Every image rule now names both the element and any img inside it, and is
  weighted to outrank ".elementor img", which also fixes the corner radius that
  would not apply on the front end.

= 1.1.16 =
* Fixed 1.1.15, which sent the image height out as a custom property and broke
  it: an image with a height set fell back to its own proportions, so a tall
  photo rendered tall. The height, fit and crop position go straight onto the
  image again, which always worked. Only the conditions that caused the
  original fault are gone.
* The stylesheet still holds cover and centre as the defaults, so a height set
  on its own crops from the middle rather than stretching.

= 1.1.15 =
* Fixed: the gallery's crop settings applied in the editor and not on the front
  end, so an image given a height was stretched to fill it rather than cropped.
  Both settings were hidden behind a condition on the height, and a condition
  is worked out again when the front end's stylesheet is written. One that
  answers differently there than it did in the editor produces exactly this.
* Height, fit and crop position now travel as custom properties, with their
  defaults held in the stylesheet, so a height set on its own crops from the
  centre rather than stretching, whatever else does or does not reach the page.
* Crop position is per device now, like the other two.

= 1.1.14 =
* The Notes widget takes a JetEngine listing template for its cards, which the
  single Note and Home widgets already had and this one did not. So the notes
  under a product can be designed either with the built-in card controls or in
  a listing template, whichever suits.
* Each note is rendered through the listing one at a time rather than handing
  JetEngine the query. That matters: the notes have already been narrowed to
  this product and put past the vault gate, and a query built in JetEngine
  would know about neither, which is how a Circle member ends up seeing a
  35-only note.
* A deleted listing falls back to the built-in card rather than an empty grid.
* The widget defaults to following the product on the page, and the option that
  means "no filter" is now labelled Every product rather than Select a product,
  which said nothing about what it did.

= 1.1.13 =
* A Note Navigation widget for the single note page, stepping to the version
  before and after within the same product. Notes published for other products
  in between are passed over, which is the whole point of it.
* A version the reader is not allowed to see is skipped rather than linked to,
  so a Circle member never lands on a locked page. Their step reaches back to
  the last version they were shown.
* Each link can carry the version it goes to, or the note title, or just the
  label. At the first and last version the link can either disappear or stay in
  place as plain text, which keeps the row from shifting about.
* Icons, wording, layout and every colour are controls. Also [ff_note_nav].

= 1.1.12 =
* A Version column on the notes list, beside the product. Sorted as a number,
  so version 10 comes after version 9 rather than after version 1.

= 1.1.11 =
* A Product column on the notes list, right after the title, and a product
  dropdown above it to filter the list down to one product's notes.
* The product name in the column is itself the filter link, since seeing one
  note for a product is usually the moment you want the rest of them.
* The column sorts too, which groups each product's notes together.

= 1.1.10 =
* Feedback tags by version, not by the act of writing in. Giving feedback on a
  note tags the member feedback-v12, so you can write back to exactly the
  people who commented on that version and tell them what changed because of
  them. "Everyone who ever writes to Nick" is a list nobody asked to be on;
  "everyone who fed back on version 12" is an email worth sending.
* Each note takes an "Email marketing tag" of its own, shown as it will be
  sent, defaulting to the version number. Two products both reaching version 12
  is what that field is for.
* A question that is not about a note tags nothing, and neither does a note
  with no version and no tag. The 'ff_feedback_tag' filter switches it off
  entirely for anyone who would rather the platform knew none of it.

= 1.1.9 =
* Only poll interaction is shared with the email platform. Feedback is a
  private message to Nick, and the fact that somebody writes in is part of what
  makes it private, so neither the count nor the tag leaves the site. What a
  member reads stays here too.
* The gave-feedback tag is withdrawn from anyone who already carries it, on the
  platform as well as here.
* PollsVoted and LastVoted remain, because a poll is a public act in the
  programme's own terms: the answer is counted and the result is published back
  to everyone.

= 1.1.8 =
* Engagement is counted rather than tagged: polls voted in, last voted,
  feedback sent, last feedback, notes read. Five figures that never grow,
  where a tag per poll grows for ever.
* That is the answer to a tag field filling up. Most segments want "voted in
  more than three polls" or "has not voted since March", and neither of those
  needs a tag at all. Tags stay for the specific ones you actually target.

= 1.1.7 =
* Poll tags read as words rather than an id: poll-packaging-colour, not
  poll-14. A number means nothing in a segment builder six months later.
* Each poll takes an "Email marketing tag" of its own, shown on the poll with
  the tag as it will actually be sent. Left empty it comes from the title.
* Long titles are cut at a word and given the poll id, so two questions that
  start the same way stay distinguishable. Worth setting a short tag by hand on
  a long question: Campaign Monitor holds all of a member's tags in one
  250-character field.
* Existing poll-14 style tags are renamed once on update and re-synced.

= 1.1.6 =
* Unsubscribes now come back the other way. A member can also leave from the
  platform's own link at the foot of a campaign, which happens entirely outside
  WordPress, and until now the site carried on emailing somebody who had asked
  it not to.
* The platform is asked once an hour who has left, and their consent is
  switched off here too. You are told each time, with the email saying it came
  from the platform. There is a "Check now" button and a last-checked time on
  the Settings page, under the email platform section.
* The answer is never pushed back where it came from, so the two sides cannot
  chase each other in a loop.
* Which emails consent actually stops: the news and the announcements. A
  set-password link, a password reset and a reply to a message they sent still
  arrive, because an unsubscribe is not a request to be locked out of the
  account. The line is filterable through 'ff_may_email_member'.
* A connector that cannot answer the question returns nothing and the site
  carries on trusting its own record, exactly as before.

= 1.1.5 =
* The data sent to the email platform is split in two: structural state, one
  field each, and one bag of loose labels. Status, member number, display
  preference, application date and postcode are each their own field, because
  each is something a journey branches on. Tags are for everything else.
* Tags are stored in WordPress as a real array and serialised by each connector
  on the way out, so neither platform's idea of a list leaks into the other.
* Status is worked out rather than stored: withdrawn is the deactivated flag,
  The 35 is having a number. A stored copy would be one more thing to keep in
  step and the first thing to go wrong.
* Applicants sync too, as Applicant, so "thanks for applying" can be a journey
  rather than a single email. Declining moves them to Declined and withdrawing
  a member moves them to Withdrawn: neither deletes anybody, and neither is an
  unsubscribe, which is the member's own decision.
* Tags arrive on their own when a member votes (voted, poll-14) or sends
  feedback (gave-feedback), and can be edited by hand on the member's user
  screen. Saving there syncs immediately.

= 1.1.4 =
* Final pH and natural origin, entered on the note rather than the product,
  because they belong to a version of the formula and not to the thing itself.
* The change from the last version is worked out and shown beside each figure,
  so nothing has to be typed twice or remembered when a value is revised.
  Leave a field empty on a version where it was not measured and the comparison
  reaches back to the last one that has a figure.
* The change is computed only against notes the reader is allowed to see, so a
  vault figure cannot be read off a subtraction. A Circle member's change spans
  whatever the vault held back, which is the change since the version they saw.
* The product header shows the current figures, taken from the newest note that
  has them, so there is no second field to keep in step.
* Style controls for both chips, and a "Change since last version" section with
  separate colours for up and down: which direction is good news depends on the
  figure, so that decision is not made for you.

= 1.1.3 =
* Sending settings: sender name, sender email, a reply-to name and address, and
  an optional blind copy of everything that goes to a member.
* Applied to every email the plugin sends, including the tests, the message
  notices and the password links, so a member never gets two emails from two
  different names. Other WordPress emails are left alone.
* The Emails screen shows how the message will arrive, above the subject line,
  and says so plainly when no sender has been set.
* The sender field carries the warning it needs: it has to be an address on
  this site's domain. A Gmail or Outlook address there fails that provider's
  own checks and lands the welcome emails in spam. The reply-to has no such
  constraint, so that one can be any address actually read.

= 1.1.2 =
* The emails read properly on a phone. The card was a fixed 600px, so a phone
  had no choice but to shrink the whole email to make it fit, which is what
  made every word too small. It is now fluid and capped at 600, with a
  conditional block holding Outlook to 600 since Outlook cannot do max-width.
* Below 620px the padding comes in, the body text goes up to 16px rather than
  down, the small print goes up to 12px, and the button runs the full width so
  it can be hit one-handed.
* Long words and addresses wrap instead of forcing the card wider than the
  screen, which was the other way an email ended up zoomed out.
* Text-size adjustment is switched off, so iOS stops resizing type on its own.

= 1.1.1 =
* A link placeholder sitting alone on the line under its sentence is brought up
  onto that sentence. The templates were written when the placeholder produced a
  bare URL, where a line of its own is the only sensible way to set one out. Now
  that it produces a few linked words, the same line break left the link
  stranded. A deliberate blank line still makes it a paragraph of its own.

= 1.1.0 =
* Heading size and weight for the emails, alongside the two heading colours.
  Montserrat is fetched at 400, 600 and 700, so those three are certain; a
  client that falls back to Arial rounds anything else to the nearest weight
  it has.

= 1.0.99 =
* Every em dash removed from the whole plugin: both add-ons, every screen,
  every stylesheet and script, the readme and the code comments. 363 of them.
* The email copy already saved in the database is rewritten once on update.
  Fixing the shipped defaults did nothing for templates that had been edited,
  which is where the ones you were still seeing came from.
* Author copy is filtered on save from here on, so an em dash pasted in from a
  document becomes a comma rather than waiting to be spotted in an inbox.

= 1.0.98 =
* A logo width setting for the emails, in pixels. The width is written as an
  attribute as well as a style, because Outlook ignores the style and would
  otherwise draw the logo at whatever size the file happens to be. On a narrow
  phone it shrinks to fit rather than overflowing the card.

= 1.0.97 =
* The heading band carries the email's own heading again ("Welcome to The 35"),
  not the subject line. A subject has to earn a click from a crowded inbox; a
  heading is read by someone who has already opened the email.
* The gallery's corner radius is applied to the link around each image as well
  as to the image. A linked image paints its own box over the corners, so the
  radius was set and then covered up.
* Updating the plugin now purges the LiteSpeed page cache as well as clearing
  Elementor's generated CSS. Rebuilding the stylesheet is only half of it: the
  pages that link to it are cached too, stylesheet version and all, so a fresh
  file sat on disk while visitors were served the address of the old one.

= 1.0.96 =
* The email layout rebuilt to the agreed design: the logo above the card rather
  than inside it, a full-width heading band across the top of the card with its
  own background and text colours, the message below it, the footer line centred
  inside the card, and the small print outside it, under everything.
* Two new colours: Heading band and Heading text. The old accent colour is now
  just Links, which is the only other thing it was doing.
* New "Small print" field for the disclaimer below the card. Takes {site_name}
  so it follows the site between staging and live. Clear it to leave it off.
* The heading band carries the subject line rather than a second fixed heading.
  Two fields saying nearly the same thing is two fields to keep in step.
* Unsubscribe, at the foot of the welcome and promotion emails. One click, no
  sign-in: the link carries a hash only this site can produce, and it does not
  expire, because an email sits in an inbox for years and a link that quietly
  stops working is worse than no link at all.
* Unsubscribing switches off the consent flag and writes the unsubscribe back to
  the email platform, so a member who has left the list here has left it there
  too. It never touches the account, the number or the history: leaving the
  mailing list is not leaving the programme.
* You are emailed every time, with the member's group stated plainly, so one of
  The 35 going quiet is something you can follow up in person.
* No unsubscribe on the password reset, which was asked for and has to arrive,
  or on the application emails, where there is no account and so no list.
* The preview's unsubscribe link is a sample, like the password link: previewing
  an email should not be able to unsubscribe the member being previewed.

= 1.0.95 =
* Emails set in Montserrat, fetched for the clients that will load a web font,
  with an Outlook conditional that puts Outlook on Arial rather than letting it
  guess. The font stack also lost its quoted names, which is why emails were
  arriving in the reader's default serif: a quoted font name has to survive
  being escaped twice, and when it doesn't the whole declaration is discarded.
* The two link placeholders are written out as a linked phrase now, not as a
  pasted address. "Use this secure link to {set_password_link}" reads as "Use
  this secure link to set your password", with the words carrying the link.
  The wording is filterable through 'ff_email_link_labels'.
* Links in an email body take the heading colour instead of browser blue.
* Colour fields accept a hex with the hash left off. One typed without it was
  rejected outright and saved as nothing, which read back as the shipped
  default, so the colour looked like it had never been set.
* The Settings page now says where each email colour actually lands.
* Every em dash removed from the plugin's copy, in emails and on screen, in
  line with the Apotheca house style.

= 1.0.94 =
* Fixed: a logged-out visitor who opened a restricted page, a gated note or a
  product page was sent to the WordPress login screen, ignoring the login page
  set in Settings. Every one of those redirects now uses your login page, and
  the WordPress screen is only ever used when no login page has been set.
* The page they were trying to reach travels with them, so logging in returns
  them to it rather than dropping them on the hub. A wrong password keeps the
  destination too.
* Guarded against a loop: if the login page is itself given an access level, the
  WordPress login screen is used rather than redirecting the page to itself.

= 1.0.93 =
* New "Emails" screen under Founding Faces: every email the plugin sends, shown
  exactly as a member receives it, with the subject line above it, and a
  "send yourself a test" box underneath. Fill the placeholders with made-up
  details or with a real member's name, number and group.
* A preview never mints a set-password token, so it cannot invalidate a link
  already sitting in a member's inbox, and a test only ever goes to the address
  typed on the form, never to the member being previewed.
* Every email is now built by one method that both the preview and the real
  senders call, so a preview cannot drift out of step with what is sent.
* Elementor's generated CSS is cleared once automatically after the plugin
  updates. A release that widens a style selector used to leave pages serving
  CSS built from the old one, which looks like a control that has stopped
  working, a manual "Regenerate CSS" is no longer needed after an update.

= 1.0.92 =
* Fixed: password fields kept the browser's own black border and ignored every
  Field control in the Style tab, so the password box on the Login widget looked
  nothing like the email box directly above it. Only text, email and text areas
  were ever listed; password, date, telephone, URL and number are now listed too,
  in the stylesheet and in the Elementor controls alike.

= 1.0.91 =
* The Login widget's signed-in message takes an alignment and a margin, which it
  had neither of, only a colour and a typeface, which is not enough to place
  something on a page.
* The signed-in panel it sits in gained its own background, border, corner
  radius, shadow, padding and margin, so it can be a card in its own right
  rather than two lines of text where a form used to be.

= 1.0.90 =
* The Login widget takes a "Show in the editor as" choice: both states one above
  the other, a logged-out visitor (the form), or a signed-in member (the
  message). The canvas only, the front end always shows the right one for
  whoever is looking.
* Fixed at the same time: the editor's two-state preview never ran. The flag that
  asked for it was not among the shortcode's declared attributes, so it was
  dropped before it was read, and the canvas only ever showed the signed-in
  panel, which is exactly why the form could not be styled.
* The signed-in panel is now built in one place rather than twice, with the
  log-out link going nowhere in the editor.

= 1.0.89 =
* The note gallery now moves one way. Forward always slides left and back always
  slides right, at every point in the gallery, reaching the last image and
  pressing forward again carries on into the first instead of rewinding the whole
  strip to get there.
* Done by rotating the track rather than scrolling it, so the strip never has an
  end to rewind from. Nothing is cloned: the lightbox still holds the images the
  note actually has, and the browser is asked for each of them once.
* A dot still jumps straight to its image, rotating a step at a time would be a
  long walk across a gallery of any size.

= 1.0.88 =
* Fixed: the meta row's stylesheet fallback said one line while the widget's
  control said two, so the two-line layout only appeared once Elementor had
  regenerated its CSS. The fallback now matches the control's default.

= 1.0.87 =
* The meta row is now built as two groups, the pills, then the plain text, and
  a "Meta row layout" control puts them on one line or two. Two lines is the new
  default: the stage badge and vault chip together, the version and date beneath.
* Because they are groups rather than loose chips, a narrow card no longer wraps
  at whatever point it runs out of room; the pills stay with the pills.
* "Gap between chips" now spaces the chips within each line, and a new "Gap
  between the two lines" spaces the lines. Alignment applies to both.
* Set per device, so a card can be one line on desktop and two on a phone, or
  the other way round.

= 1.0.86 =
* The mark between the chips now goes between two pieces of plain text and
  nowhere else, so between the version and the date, but never beside the stage
  badge or the vault chip. A pill has an edge of its own, and a mark next to one
  is a second boundary drawn over the first.

= 1.0.85 =
* Every chip on a note now has its own Style section, Stage badge, Version
  number, Date, and The 35 vault chip, each with typography, text colour,
  background, border, corner radius, padding, box shadow and a vertical nudge.
  One typography setting across all four was the wrong shape: a pill, two pieces
  of quiet text and a small-caps marker are three jobs that only looked like one.
* "Badges & chips" now holds what belongs to the row rather than the chips: the
  gap, the alignment, the row's margin, and the separator's controls.
* Two settings change hands. Any typography set under the old shared control now
  applies to the stage badge alone, and the combined "Version & date colour" is
  gone, set the colour in the Version number and Date sections instead.

= 1.0.84 =
* A note's stage, version and date ran into one another. There is now a mark
  between them, "Between the chips" in the Content tab, a "|" by default, any
  wording or none.
* It has its own controls under Badges & chips: colour, typography, the space
  either side (on top of the chip gap, so it can sit tight to one and breathe
  from the other), and a nudge up or down for marks that don't sit on the same
  optical line as the text.
* The mark is hidden from screen readers, it is punctuation for the eye, and
  read out between every chip it would be noise.

= 1.0.83 =
* Cards in a multi-column layout are now equal height by default: every card in
  a row matches the tallest one, so a short note beside a long one no longer
  leaves the row looking half-finished.
* It is a control, not a decision: "Card heights" (or "Note heights" / "Poll
  heights") sits under the Columns control on every widget that has one, Notes,
  Notes Archive, Home, Member Archive and both poll layouts, with "As tall as
  their content" if that is wanted, set per device.

= 1.0.82 =
* Note cards can be shortened: "Body length" takes a number of words or of
  characters, so a long note no longer runs the length of the column. A
  shortened body is plain text, formatting is dropped rather than cut in half ,
  and it can carry a link through to the whole note, with your own wording and
  its own style controls.
* Every part of a note card now has its own switch: title, stage badge, version
  number, date, vault chip, body copy and images. Turn one off and nothing is
  left behind, a card with no title and no chips has no header element holding
  space where they used to be.
* On the Notes, Notes Archive, Single Note and Home widgets, all four. The
  editor samples honour the same settings, so the shortened length can be judged
  where it is set rather than guessed at.
* Shortcode equivalents: body_trim, body_unit ("words" or "characters"),
  body_more, body_more_text, and hide="date,vault" for the parts.

= 1.0.81 =
* Fixed: the Edit Product and Edit Note screens showed no permalink row, so the
  URL was invisible and the slug could not be edited. The editor screen reads
  the post type's "public" flag directly to decide whether to offer it, and both
  types were registered non-public. Both now say what has been true since
  1.0.79: they have a front end.
* Nothing is loosened by that. Both are still excluded from site search, have no
  archive, are removed from the sitemap, are marked noindex, are kept out of the
  REST API, and redirect anyone who isn't a member before rendering.

= 1.0.80 =
* "The product on this page (automatic)" now resolves on a note's page too, to
  the product that note belongs to. On a Single Note template that makes a "more
  from this formulation" block possible without naming a product anywhere. On a
  Single Product template nothing changes.

= 1.0.79 =
* Products have two more stages: Formula finalised and Complete. They are on the
  product only, a note never reaches either, so they don't appear on the note
  editor or as a filter chip on a notes page.
* Products now have their own single URL (/formulation/…), so Elementor Theme
  Builder can preview and target them exactly as it can notes: Products appears
  in Preview Settings and in "Where do you want to display your Template?".
  Build the product page once and every product uses it.
* That page is gated like a note's: a logged-out visitor is sent to log in, a
  non-member is sent away, and products are marked noindex and kept out of the
  sitemap. The slug is "formulation", not "product", so nothing collides with
  WooCommerce.
* The Notes widget and the Product Header widget can now be set to "The product
  on this page (automatic)", which is what makes one template serve them all.
  Asked to follow the page's product where there isn't one, the notes list shows
  its empty state rather than quietly listing every note there is.
* Fixed: a note stayed marked unread after being read. The view was only
  recorded by the Single Note widget, so a Single Note template built from
  dynamic tags never recorded one. Opening the note's page now marks it read
  however that page is built. Designing the template in Elementor does not.
* Permalinks are flushed once on update, so the new product URL works without
  re-saving them by hand.

= 1.0.78 =
* A note's "Trial number" is now "Version number", everywhere it is written or
  read: the field on the note editor, the chip on every note card, the Elementor
  dynamic tag, and the widget's colour control for it.
* The stored meta key stays ff_note_trial. Renaming it would have detached the
  number from every note already published, and nothing outside the plugin reads
  it by name. Nothing needs re-entering.

= 1.0.77 =
* New widget: Founding Faces Note Gallery. The images already stored against a
  note, shown as a slider. Left on automatic it follows whichever note is being
  read, so it can go straight into a Single Note template once.
* One image is not a slider: no arrows, no dots, nothing to interact with. From
  two upwards it loops in both directions and never dead-ends, and the arrows
  take themselves away again on any screen where every image already fits.
* Full control of the arrows: any icon from the library (or the plain chevron),
  icon size, button size, padding, colour, background, border, corner radius and
  shadow, each with a hover state, plus how far in or out from the edge they sit
  and how far down. Nothing about how they look is decided by the plugin.
* Images on show and the gap between them are per device, so three across on
  desktop can be one on a phone. Also: image size, height and how it fills that
  height, corner radius, border, shadow, captions from the media library, dots,
  autoplay with a pause on hover, and slide speed.
* Clicking an image can open Elementor's lightbox, open the full file in a new
  tab, or do nothing.
* Autoplay never runs for a member whose device asks for reduced motion, and
  the slide transition is dropped for them too.
* The gallery obeys the 35-only gate wherever it is placed, not just on the
  note's own page.
* "Which note is this page about?" is now answered in one place, shared by the
  gallery and the feedback form.

= 1.0.76 =
* Notes are now flagged show_in_nav_menus, which is the flag Elementor reads
  directly to decide what its Theme Builder can preview and target. 1.0.75
  filtered Elementor's list, which was not enough, the conditions dialog reads
  the flag itself. Notes now appear both in Preview Settings and in "Where do
  you want to display your Template?" under Singular.
* The cost of that flag is its own meaning: a note is now an addable item in
  Appearance -> Menus. Linking one is a deliberate act, and menu items carry a
  Founding Faces visibility rule, so a note linked by mistake is still gated.

= 1.0.75 =
* Notes now appear in Elementor's Theme Builder preview picker and display
  conditions. Elementor builds that list from post types flagged
  show_in_nav_menus, and notes are deliberately not flagged that way, they are
  not pages anyone links to from a menu. The plugin now tells Elementor about
  them directly instead, which changes nothing about how WordPress treats the
  post type anywhere else.
* Set Preview Settings to Single -> Notes and pick a note; the Single template
  then previews against a real note.

= 1.0.74 =
* Every text field an administrator writes into now accepts HTML, decided in
  one place (class-ff-text.php) instead of field by field. Headings, labels,
  hints, buttons, badges and the map legend take inline markup, bold, italics,
  a link, a line break. Messages and intros take what a post takes.
* Covered: the member archive headings and header subheading, the note filter
  labels, every poll phrase (closed capsule, hint, "Your choice", "Where we
  landed", the vote count), every application-form label, hint, consent line
  and button, the status-lookup heading, intro, label, button and "send it
  again" link, the home widget headings, the "view all notes" link, the login
  form's labels, button and links, the member bar labels, the welcome widget's
  three phrases, and the map legend labels.
* Placeholders stay plain text: they live inside an HTML attribute, where a tag
  can only ever arrive as visible angle brackets.
* No field accepts scripts, styles or iframes. Text a MEMBER writes, feedback,
  messages, their own name, is untouched by this and stays escaped.
* Fixed: the Feedback widget did not attach the note it was placed on unless a
  note ID was typed in by hand, while the [ff_feedback] shortcode did. Both now
  resolve the note the same way, so a feedback form in a Single Note template
  tags every submission with its own note.
* The admin thread view now names and links the note a piece of feedback is
  about.

= 1.0.73 =
* Unread notes can now differ from read ones by more than a background: border,
  corner radius, padding, title colour, product-label colour and date colour,
  alongside the row background and bold title that were already there.
* The section is renamed "Unread notes (badge & row)", the row controls were
  sitting inside a section called '"Unread" badge', which is not where anyone
  would look for them.
* Read rows keep whatever the "Item box" section gives them; every control here
  applies to unread rows only, so setting none leaves the two identical.

= 1.0.72 =
* Fixed: the map's zoom buttons, legend and attribution painted over a sticky
  header. Leaflet numbers its own furniture for a page where the map IS the
  page, panes at 400, controls at 800, corners at 1000, and those numbers
  beat any normal header. The map now forms its own stacking context, so those
  numbers only mean anything inside it and nothing can climb out.
* The widget's own z-index (Elementor → Advanced) still decides where the map
  sits against the rest of the page, which is where that decision belongs.

= 1.0.71 =
* The no-poll message now accepts HTML, links, bold, italics, lists, and a
  blank line starts a new paragraph. It was being escaped, so tags showed as
  text on the page.
* The heading accepts inline HTML (bold, italics, a link, a line break) but not
  block tags, since a paragraph or a list inside a heading is not markup anyone
  means to write.
* Neither field accepts scripts or styles: this is copy, not a place to run
  code.

= 1.0.70 =
* New: a "When there is no poll" section on both poll widgets, a heading and a
  message shown between polls, where the widget used to render nothing at all.
  Both fields are pre-filled and both can be cleared to go back to showing
  nothing.
* New "No-poll message" style section: alignment, background, border, corner
  radius, shadow, padding and margin for the block, plus colour, typography and
  margin for the heading and the message separately.
* The editor preview can be switched between the poll and this message, so the
  copy can be styled without waiting for every poll to close.
* The polls archive widget uses the same copy in place of its built-in "No open
  poll right now" line.

= 1.0.69 =
* The winning-bar colour now takes priority when the member voted for the
  winning option, instead of the your-choice colour. The "Your choice" label
  still marks the row as theirs, so nothing is lost by it.
* Fixed: the stylesheet carried a rule for the member's own bar that painted
  the same colour the base fill already paints, visually nothing, but its
  specificity outranked the widget's winning-bar colour, so a member who voted
  for the winner never saw that colour whatever it was set to. Both states are
  now the widget's to colour.

= 1.0.68 =
* New "Show" control on the poll widget: the latest poll, all current polls, or
  one specific poll.
* "All current polls" lists open polls first, newest first, then closed polls
  while they are still inside their hide time, a decision is worth reading
  after the voting has finished, but only for as long as it was meant to be on
  the site. "The latest poll" is the first of that same order, so it means the
  newest poll still taking votes, falling back to the most recent decision.
* New Columns section for the "all" view: up to four columns set separately for
  desktop, tablet and mobile, with column and row gaps.
* The editor shows three sample polls in that view, one open, two closed, so
  the columns have something to lay out.
* Poll widgets placed before this update keep rendering exactly the poll they
  were set to.

= 1.0.67 =
* Fixed: per-item menu visibility was skipped entirely for administrators, so
  an item set to "Logged-out visitors only" still showed in the header of a
  logged-in administrator. The rules now apply to everyone on the front end,
  which is the only way the person setting them can see them working.
* The admin area still shows the unfiltered menu, and so does the Elementor
  editor, so a header can be designed with every item on the canvas.
* This matches the Elementor "Show to" control, which never had the exemption.

= 1.0.66 =
* "Notes per page" is now a responsive control: a different page size for
  desktop, tablet and mobile. The page is built at the desktop size and the
  script cuts it to the screen's own size before anything is painted, because
  one document is served to every screen, and behind LiteSpeed's page cache,
  the same document is served to every visitor, so the size cannot be decided
  on the server.
* A smaller screen drops the surplus rows with no extra request. The page
  numbers, the "Load more" button and its starting point all follow.
* Elementor's own breakpoints are read from the site's settings, so moving them
  moves these too.
* New: "Open notes in a new tab" on the notes list. It applies to rows loaded
  later as well as the first page, and carries rel="noopener".

= 1.0.65 =
* New "Notes layout" style section: the notes list can run in up to four
  columns, set separately for desktop, tablet and mobile, with its own column
  gap and row gap on each device.
* Only the list becomes a grid. The section heading, the filter bar, the "Load
  more" button and the page numbers are its siblings, so they keep the full
  width underneath however many columns the notes are in.
* New switch to stack each note's date under its title, for when the columns
  are too narrow to share a line.

= 1.0.64 =
* New: numbered pages on the member's notes list, as an alternative to the
  "Load more" button or alongside it. A new Paging control offers "Load more"
  button, Page numbers, or both, with both, a member can jump to roughly the
  right page and then keep loading from there.
* Long lists show a window of numbers rather than all of them: the first and
  last pages, the two either side of the current one, and a "…" where pages
  have been left out.
* The numbers are built on the server and returned with every request, so a
  filter that changes how many pages there are comes back with a pager that
  already matches. Jumping to a page loads only that page's rows.
* New "Page numbers" style section: alignment, typography, Normal/Hover/Current
  colours and borders, corner radius, padding, the gap between numbers, margin,
  and the colour of the "…".

= 1.0.63 =
* The Elementor editor now shows sample content by default, on the Member
  Archive widget, all five display widgets and the message centre. Samples used
  to appear only when the real render came back empty, so an account holding
  two real notes rendered two real notes, no full page, no "Load more" button,
  nothing to design against. The editor is where the design is made, so it
  shows the full case.
* New "Editor preview" control on each of those widgets, should the real
  content be wanted on the canvas instead.
* The front end is untouched by the setting: every member always sees their own
  real record.

= 1.0.62 =
* "You chose: …" in the votes list is now its own box, the way the Unread
  badge and the poll's closed capsule are. New controls under Item text:
  background, border, corner radius, box shadow, padding and margin, on top of
  the typography and colour already there.
* It hugs its own text rather than stretching the row, and carries no
  background until one is set, so nothing changes until it is styled.

= 1.0.61 =
* New: a "Field wording" section in the application form widget's Content tab.
  Every field gets three fields of its own, its label, its placeholder and the
  hint below it, covering all six questions and the consent checkbox. The
  required-field marker is editable too, and clearing it drops it everywhere.
* Every field is pre-filled with the wording it replaces, so the panel shows
  what is actually on the page. Clearing a hint or a placeholder removes it.
* Clearing a label hides it on screen but keeps it in the markup for screen
  readers, so a field styled down to a placeholder is still one a screen-reader
  user can identify.
* Name, email, skin concerns and "about your skin" gained placeholders, and
  every field gained an optional hint line; previously only postcode and
  Instagram had either.
* The existing Button text and Thank-you message controls keep their saved
  values, and the shortcode's button_label and success_message attributes still
  work as before.

= 1.0.60 =
* Removed the decorative left border from the poll outcome block. It was drawn
  in the stylesheet where nothing in the editor could reach it; the block now
  ships with no border and the widget carries Border, corner-radius and shadow
  controls so any edge treatment is a decision made in Elementor.
* Removed two other hardcoded treatments for the same reason: the white inner
  ring on the member's own result bar, which sat on top of the bar colour set
  in the editor, and the hover ring and accent border on the voting buttons,
  which overrode the button's own border and shadow. The Hover tab now carries
  border colour and box shadow, so hover is styled rather than assumed.
* New: a "Poll card" style section, background, border, corner radius, box
  shadow, padding and margin for the poll as a whole.
* New: full box controls for the "Your choice" label, background, border,
  radius, shadow, padding, margin and a baseline nudge, and for the result row
  the member voted for: background, border, radius and padding.
* Added the missing controls elsewhere in the poll: question alignment, margin
  and padding; border and shadow on the "Poll closed" capsule; border, shadow
  and alignment on the outcome block; box shadow on the voting buttons.
* New: a "Wording" section in the poll widget's Content tab. Every fixed phrase
 , "Poll closed", the hint under the options, "Your choice", "Where we landed"
  and the vote-count line (singular and plural), is now a field, pre-filled
  with the wording it replaces. Clearing a field leaves that line off entirely.
* The wording travels with the poll, so the results shown straight after a
  member votes say the same things as the rest of the poll.

= 1.0.59 =
* The votes list now gives the poll question the full width of the row, and
  drops the date onto the "You chose" line beside the answer. Poll questions
  are sentences, and holding a column open for the date wrapped them early.
* The editor's sample votes use full questions rather than short labels, so
  the row can be styled against the length it will really carry.

= 1.0.58 =
* The editor now draws a full page of sample notes at the widget's own page
  size, instead of four token rows, so the batch size and the "Load more"
  button can be judged on the canvas before a single real note exists. The
  sample titles and products vary rather than repeating one row, and the
  unread ones sit at the top where the real ordering puts them.
* Sample pages are capped at 30 rows, so setting the page size to 100 doesn't
  bury the editor.
* The sample list's button and filters are inert on the canvas: clicking them
  no longer returns a loading error where there is nothing to load.

= 1.0.57 =
* New: each note in the member's notes list can name its product on a small
  line above the title, so a member can see what a note is about before they
  read what happened. Notes with no product attached skip the line rather than
  showing an empty one.
* The line is switchable on the widget and has its own style section, colour,
  typography, background, border, corner radius, padding and margin, and it
  shows in the editor sample so it can be styled before there is any real data.
* The products named in a batch of rows are loaded in one query, so the label
  costs nothing per row as the list grows.

= 1.0.56 =
* New: filters on the member's notes list, each switchable on the widget ,
  read/unread, product, type (development stage), date period (last 30 days,
  3 months, 12 months) and sort (unread first, newest, oldest). Changing one
  refreshes the list in place over AJAX, without a page reload and without
  losing the filter bar.
* Product and stage filtering happens in the database rather than by fetching
  everything and sifting in PHP, and the date filter measures the note's own
  date, not when it happened to be read.
* Sorting by newest or oldest treats the list as one run ordered by the note's
  date; "unread first" keeps the two groups apart. Read rows show when the
  member opened them, unread rows show the note's own date.
* New: full style controls for the filter bar, label colour and typography,
  select background, text, border, radius and padding, plus gap and margin.
* Every filter value is validated server-side against the offered options, so a
  hand-edited request can't reach for anything the bar doesn't offer, and the
  group gate still runs on every note.

= 1.0.55 =
* New: the Member Archive notes list is paged, with a "Load more" button that
  fetches the next batch over AJAX without reloading the page. Set the batch
  size on the widget ("Notes per page", 10 by default; 0 shows everything at
  once). Each request returns only that next batch, so a member with hundreds of
  notes never waits on one long list, and the unread-first order holds across
  pages.
* New: full style controls for the "Load more" button, typography, normal and
  hover colours, border, radius, padding, alignment and margin, and it shows in
  the Elementor editor whatever the page size, so it can be styled without first
  creating enough notes to trigger it.
* The AJAX endpoint takes the member id from the session, never the request, and
  every note still passes the group gate, so it can only ever return the
  caller's own list.

= 1.0.54 =
* Change: the Member Archive's "Notes you've read" section is now simply
  "Notes". It lists every note the member is allowed to see, unread ones first,
  each with an "Unread" badge and a bolder title, then the read ones ordered by
  when they were opened. Previously it only listed notes already read, which is
  the one thing a member doesn't need help finding.
* Change: a note counts as read only when the member opens its own page, not
  when a card appears in a list. Marking on list render (added in 1.0.47)
  emptied the unread list the moment a member landed on the hub, since the feed
  there silently marked everything read before they had chosen to read anything.
  This also keeps the menu count bubble honest.
* New: style controls for the "Unread" badge on the Member Archive widget ,
  background, text colour, typography, padding, radius and gap, plus an unread
  row background and a bold-the-unread-titles switch.

= 1.0.53 =
* New: a Founding Faces Nav Menu widget. It renders a WordPress menu from
  Appearance → Menus, with every per-item setting intact (group visibility, the
  login/logout swap, the count bubble), but as an Elementor widget, so the
  links and the count circle are both styled in the editor, live, instead of
  through a settings page. Full controls for the links (typography, normal /
  hover / active colours and backgrounds, underline, padding, radius), the
  layout (direction, alignment, gap), hover sub-menus, and the circle
  (background, number colour and typography, size, inner padding, radius,
  border, gap, vertical alignment and the raise-above-the-text nudge).
* Change: the global "Unread count bubble" settings are gone, replaced by the
  widget's own controls. The bubble keeps sensible built-in defaults wherever it
  appears, so a theme-rendered menu still looks right; style it by using the Nav
  Menu widget.

= 1.0.52 =
* New: baseline controls for the unread count bubble, so it can sit above the
  menu text rather than beside it. A "Raise above the text" nudge lifts it
  superscript style without moving the line it sits on, and a vertical-alignment
  choice (middle, top, superscript, top/bottom of the text, baseline) sets the
  starting point.
* New: inner padding for the bubble, so the number sits comfortably in the
  centre of the circle. Clearing the circle size lets the padding decide how big
  the circle is instead.
* Both are on the Settings page for nav-menu items, and as Elementor controls on
  the Member Bar widget.

= 1.0.51 =
* New: a message thread now shows which product and note it is about, under the
  subject. Feedback is always left on a note, and a note carries its product, so
  the chain note to product tells a member (and Nick) what the conversation
  concerns. A general question has no reference, so it shows no context line
  rather than a misleading one.
* New: the unread count bubble can be styled on the Settings page, background,
  number colour, circle size, number size, corner radius and the gap from the
  label. Nav menu items are rendered by the theme (or Elementor's Nav Menu
  widget), which has no Founding Faces controls of its own, so the bubble is
  styled globally instead. The Member Bar widget's own Elementor controls still
  override these wherever it is used.

= 1.0.50 =
* Fix: editor dummy content now covers every widget, and no longer depends on
  who is looking. The remaining widgets keyed off "is the viewer a member?",
  which is true for Nick, so a member with no messages, no history or no
  account activity yet saw a real empty state instead of the samples. They now
  fall back to samples whenever the real render is empty:
  * Messages, a sample conversation list with the "New message" badge.
  * Member Archive, sample votes, notes and feedback.
  * Account, the sample profile panel.
* New: editor samples for the widgets that previously had none at all.
  * Login, the form and the signed-in panel are both rendered, with a sample
    error notice. Previously a signed-in administrator only ever saw the
    "You're signed in" panel, so the form itself could never be styled.
  * Members Map, sample dots across the Australian capitals, so dot colour,
    size and opacity can be previewed before there are members.
  * Application form, the success notice shown above the form as a sample (it
    normally replaces the form, so it was impossible to style).
  * Feedback and Ask, the "message sent" notice shown as a sample.

= 1.0.49 =
* Fix: the editor dummy content added in 1.0.45 never appeared for an
  administrator. It was shown only when the viewer failed the members-area
  check, and an administrator always passes it, so the person designing the
  page was the one person who could never see the samples. The samples now key
  off the render itself: if the real output is empty, a gate notice or an
  empty state, the sample stands in.
* New: the Status Lookup widget now previews its result in the editor, the
  status notice, the "Didn't receive it?" prompt and the "Send it again" button
  all appear as samples, since they otherwise only exist after a real
  submission. The form stays visible alongside them, so everything can be
  styled in one pass.

= 1.0.48 =
* Fix: declining an application sent no email at all, while the status lookup
  told the applicant to check an inbox that had nothing in it. A declined
  applicant is now emailed, from a template editable on the Settings page
  alongside the two welcome emails. Clearing the body field declines silently.
* New: a "Send it again" button under the status lookup result. It re-sends to
  the address already on file, a fresh welcome email with a brand-new
  set-password link for an approved member (which also fixes an expired
  seven-day token), the decline email for a declined applicant, or the received
  confirmation for one still pending. The reply is identical in every case,
  including for an unknown address, so the lookup still never reveals the
  decision and can't be used to test whether someone applied. Rate-limited to
  one send per address every fifteen minutes.
* New: the Status Lookup widget gained a heading and body copy, each with full
  style controls (colour, typography, alignment, margin, padding), plus style
  controls for the "send it again" prompt and button.
* New: an optional "Hide the form after a successful lookup" switch on the
  Status Lookup widget, with a "check another email" link back. An unrecognised
  email always keeps the form up so it can be corrected.

= 1.0.47 =
* Change: the notes bubble now counts genuinely unread notes rather than notes
  published since the member's last login, a session where they read two of five
  leaves three on the bubble instead of clearing it. A note counts as read once
  it has been rendered to that member, and the gate still applies, so a Circle
  member only ever counts notes their group may see.
* Fix: reading notes in a list (the hub feed, a product's notes, the archive) now
  records the view. Previously only a single-note page did, so notes read in a
  list would never clear the count.
* New: Founding Faces Member Bar widget, a header strip of Messages / Notes /
  Polls links, each with its own count circle, plus an optional Log in / Log out
  link. Full style controls for the circle (background, number colour and
  typography, size, radius, border) and its position, either beside the label or
  floating on the top-right corner like a mini-cart.
* New: the count bubble shows a sample number while designing in the Elementor
  editor or the Customizer, so it is always visible to style even when nothing is
  actually unread.

= 1.0.46 =
* New: a dynamic Log in / Log out menu item. Set it per item in Appearance →
  Menus: it shows "Log in" (linking to your login page) when logged out and
  "Log out" when logged in, swapping automatically. "Log in only" and "Log out
  only" modes hide the item when it doesn't apply.
* New: an unread count bubble on any menu item, mini-cart style. Choose the
  source per item: unread private messages, new notes since the member's last
  visit, open polls they haven't voted in, or everything combined. The bubble is
  hidden entirely at zero and for logged-out visitors, and only ever counts the
  viewer's own messages and content their group may see.
* New: a Founding Faces Login widget (and [ff_login] shortcode), a skin over
  WordPress's own login handler, with the shared form Style tab plus link and
  signed-in-panel controls. A member who is already signed in sees a short
  message and a log-out link instead of the form.
* New: Settings → login page URL, after-login and after-logout destinations, and
  the two menu labels. Leaving the after-login field empty uses the members hub
  page, which follows the site between staging and live.
* Fix: a failed login from a custom login page returns to that page with a clear
  message, rather than dumping the member on wp-login.php.

= 1.0.45 =
* Change: decorative underlines removed from the built-in design (the accent rule
  under the Home and Member Archive section headings, and the line under the
  product header). Every heading now has an "Underline" switch instead, with its
  own colour, thickness and gap, so it's there only when wanted.
* New: full Style tabs on the display widgets, Notes, Notes Archive, Single Note,
  Product Header and Home now control the card (background, border, radius,
  shadow, padding, margin), the title, the meta row, badges and chips, the body,
  the gallery, the filter bar/chips and the "View all" link, each with typography,
  colour, alignment, margin and padding.
* New: the Poll and Polls Archive widgets gained voting-button, outcome-block and
  section-heading style controls, plus a gap control for the archive grid.
* New: representative dummy content in the Elementor editor. Notes, note cards,
  product headers, the products list, filter bars and polls all preview with
  sample data in the real markup, so every element can be styled before any real
  content exists (or when the designer isn't a member).
* New: the Single Note widget and each section of the Home widget (latest notes,
  products) can now render through a JetEngine listing template instead of the
  default layout, falling back to the default if the listing is missing.
* Fix: every Founding Faces widget now fills its container's width. The
  components no longer impose their own max-width, so the Elementor container
  governs the width as it does for any other widget.

= 1.0.44 =
* Change: the poll "your choice" label is now stored as "Your choice" (capital
  Y), so "Normal" in the typography control shows a naturally capitalised label
  rather than all-lowercase.

= 1.0.43 =
* New: vote-count styling on both poll widgets, the "X votes" line under the
  results now has its own colour, typography, and top-spacing controls, in the
  "Question & labels" Style section.

= 1.0.42 =
* Fix: the poll "your choice" label now respects the typography control's
  text-transform. The label no longer forces uppercase by default (so "Default"
  shows natural case), and "Capitalize" now renders "Your Choice" correctly, the
  label is an inline-block, so it's read as its own word rather than running into
  the option name (which was why the "y" in "your" stayed lowercase).

= 1.0.41 =
* New: "Your choice" styling on both poll widgets, the your-choice bar colour
  (which takes priority when an option is both winning and the member's choice),
  plus the "your choice" label colour, typography, and a gap control between the
  answer and the label.

= 1.0.40 =
* New: full result-bar styling on both poll widgets (Poll and Polls Archive).
  Set the bar colour, the WINNING bar colour (the option with the most votes),
  the your-choice bar colour, the empty-track colour, plus bar height and corner
  radius. Question, option-label and percentage colours too.
* Change: the "poll closed" message is now a styleable capsule ("Poll closed")
  shown above the question, with its own alignment, colours, typography, padding
  and radius controls. The old line beneath the results is removed; your
  "Where we landed" outcome text still shows when set.

= 1.0.39 =
* New: schedule a poll's close and hide. Each poll now has optional "Auto-close
  at" and "Auto-hide at" date/times. At the close time the poll stops taking
  votes and shows the final results and your reasoning; at the hide time it
  disappears from the site entirely. Set the hide time a little after the close
  time to give members a window to see the final votes. If neither time is set,
  choosing "Closed" in the poll's Status makes it disappear straight away. Times
  are entered and shown in your site's timezone. (Note: with full-page caching
  such as LiteSpeed, a scheduled change may not appear until the cache refreshes
  for that page.)

= 1.0.38 =
* Fix: admin "view as a member" preview now works for page access. is_member()
  resolves the current user's id before checking their group, which meant the
  previewed group was skipped and an "All members" page wrongly redirected the
  previewing admin. group_of() now applies the preview whenever it resolves the
  current viewer, so The 35 / The Circle previews reach their allowed pages.

= 1.0.37 =
* New: admin "view as a member" preview. From your own profile (or the toolbar
  switcher), pick The 35 or The Circle and browse the site exactly as that group
  does, gated notes, polls, pages and menu items included, and blocked from the
  other tier's content just like a real member. It only affects you; switch back
  to "Administrator" any time. A "Viewing as…" indicator shows in the toolbar.
* New: the Polls Archive widget has a "Show" option, open poll then past polls
  (default), open only, or past only, so you can place two widgets (one open,
  one past) and style each area differently.

= 1.0.36 =
* New: "Founding Faces Polls Archive" widget for a polls page, shows any open
  poll first (votable, or results if the member has voted), then every past poll
  with its results and outcome. All gated. A Columns control lays them out in a
  grid.
* New: a Columns control on the Notes and Notes Archive widgets, so notes can be
  shown in a 1–4 column grid (responsive) alongside the product / type / date
  filters.

= 1.0.35 =
* New: members are redirected to your hub page when they log in. Set it under
  Settings -> Members access -> "Members hub / portal page" (the same page used
  for the message-reply link). Members headed to a specific gated page still land
  there; admins keep the dashboard.
* New: the Notes widget can now show a "View all" link (with your text and a
  chosen page) beneath the list, ideal for a "latest 5 notes" block on the hub
  that links to the full notes page. (It already had a "Maximum notes" number.)
* New: "Founding Faces Notes Archive" widget for the dedicated notes page, a
  filter bar (Product, Type/stage, Newest/Oldest) over every note the member may
  see. Filters live in the URL so a view can be bookmarked. Each filter can be
  toggled off.
* Note: the Poll widget already hides itself when there's no active poll, so it
  can sit on the hub and only appear when a poll is live.

= 1.0.34 =
* New: "Founding Faces Welcome" Elementor widget, a personalised greeting built
  from editable before / middle / after text around the member's own first name
  and Founding number (e.g. "Hi Sarah, Founding Member 4, welcome back."). Toggle
  the name and number on/off independently, choose the HTML tag, and style the
  whole line plus the name and number separately (full Style tab). Shows the real
  first name because the member only ever sees their own greeting; The Circle has
  no number, so that part simply doesn't show for them.

= 1.0.33 =
* New: the members table under Privacy & Tools now shows a "Last login" column
  with the date and time of each member's most recent sign-in (or "Never").
  Recording starts from this update, so existing members show "Never" until
  their next login.

= 1.0.32 =
* New: members-only content is now explicitly kept out of search engines. Every
  note and every access-restricted page/post is marked "noindex, nofollow" (both
  a robots meta tag and an X-Robots-Tag header), and restricted pages are dropped
  from the sitemap (notes already were). Combined with the existing redirects,
  member URLs won't be indexed or listed by Google. Tip: set your members portal
  pages' "Founding Faces Access" to All members / The 35 / The Circle so they get
  this treatment too.

= 1.0.31 =
* Fix (important): the "Founding Faces Visibility / Show to" control was calling
  Elementor's get_settings_for_display() inside the should_render filter, which
  fires for EVERY container, section and widget on the page. That prematurely
  finalised each element's display settings, so containers lost their applied
  width/flex values on the front end and collapsed to content width, a page-
  wide layout bug that only appeared with the plugin active (and not in the
  editor). It now reads the raw setting with get_settings(), so element widths
  render exactly as designed. This fixes forms/columns rendering too narrow.

= 1.0.30 =
* Privacy: deleting a member now also removes their private messages and every
  attachment file (from the protected directory, and any legacy public upload) ,
  so no personal words or files are left behind. This runs only on a data
  delete (self-service "Delete my data" or the admin privacy tool); withdrawal
  still just deactivates and keeps the record.
* Privacy: a member's data export (CSV) now includes a "Private messages" block
  with their full conversation history, so an export is genuinely complete.

= 1.0.29 =
* New: a "Members portal page" setting (Founding Faces -> Settings -> Members
  access). Choose the page that hosts the Messages widget; the "Open my portal"
  button in reply emails points there. It's stored as a page (not a URL), so it
  resolves to the correct address on staging and live automatically.

= 1.0.28 =
* Security: message attachments are now private. New uploads are stored in a
  protected directory (uploads/founding-faces-private, with a deny .htaccess and
  no directory listing) instead of the public uploads folder, under a random
  name. Every attachment is served only through a gated endpoint that checks the
  viewer is the thread's own member or an administrator, direct URL access is
  denied. Notification-email attachment links require signing in.
  Note for NGINX hosts: .htaccess is ignored by NGINX, so also deny web access
  to /wp-content/uploads/founding-faces-private/ in your server config; the
  gated endpoint still enforces access either way, and file paths are random and
  never exposed.
* Database: adds attachment_path to ff_messages (schema 1.1.2), applied on
  update. Any attachment from 1.0.27 keeps working via its stored link.

= 1.0.27 =
* New: messages can carry an attachment, an image or PDF (JPG, PNG, GIF or PDF,
  up to 8 MB). The type is validated by real content, not just the file name.
  Attachments show inline in the conversation (image thumbnail or a file link),
  both in the member's portal and in Nick's admin reply view, and are linked in
  the notification emails. Nick can attach files to his replies too.
* New: the Member Archive widget gains a "Private messages (conversations)"
  section, so a member's own conversations with Nick can be shown on any page
  built from that widget, with its own style controls (badge, links, bubbles).
* Database: adds attachment columns to ff_messages (schema 1.1.1), applied
  automatically on update.

= 1.0.26 =
* New: a private member <-> admin concierge channel. Members can give feedback
  on a note or ask a private question; Nick reads and replies from a new
  "Messages" admin screen; the member is emailed the reply (branded) and sees a
  "New message" flag in their portal, where they can read and reply. Strictly
  private and one relationship deep -- always a member and Nick, never
  member-to-member, never public -- so it keeps the "publication, not
  conversation" principle. Adds three widgets/shortcodes: "Founding Faces
  Feedback" [ff_feedback], "Founding Faces Ask a Question" [ff_ask] and
  "Founding Faces Messages" [ff_messages] (place on the portal homepage).
  Feedback also fills the personal-history "Feedback you've shared" section.
* Database: adds the ff_messages table (schema 1.1.0). Created automatically on
  update -- no reactivation needed.

= 1.0.25 =
* New: display-name preference for The 35, on the account-settings page. A
  member can choose how they appear in the members portal across three tiers,
  defaulting to the most private: number only ("Founding Face 4"), first name
  and number ("Sarah, Founding Face 4"), or full name and number ("Sarah Chen,
  Founding Face 4"). It reuses the private real name already on file -- no new
  name is collected. The Circle does not get this control (their login is
  access-only, with no public display). Identity is resolved centrally through
  FF_Members::portal_display_name(), so one change updates the whole portal at
  once. It never affects the members map, which always stays anonymous.

= 1.0.24 =
* Fix: the plugin's Elementor widgets now fill their container on the FRONT END,
  not just in the editor. In optimized-markup (Atomic) mode the widget's inner
  wrapper is stripped, so inside a horizontal (row) flex container the widget
  shrank to its content width and looked half-width even at "Max width: 100%".
  The widget wrappers are now forced to width:100%, so the container governs the
  width as intended. Affects the Application Form, Status Lookup, Account and
  Member Archive widgets.

= 1.0.23 =
* Fix: the Application Form and Status Lookup widgets now fill their Elementor
  container instead of being capped at 560px, so the front end matches the
  editor. The widget's "Form box -> Max width" control still lets you cap it.
* New: a reassurance note under the Instagram field ("Optional, and only used
  privately to review your application -- it's never shown to other members or
  on the map"), so the optional handle never appears to conflict with the
  anonymity promise. The handle remains private: admin-only, never public.

= 1.0.22 =
* New: promote a Circle member into The 35. Approved-into-Circle rows now have
  a "Promote -> The 35" button that assigns their Founding number, moves them to
  The 35, and sends a "Congratulations, you're one of The 35" email (editable in
  Settings). You still choose 35 or Circle at approval as before.
* New: "New applications" setting. Turn on "Automatically accept new applicants
  into The Circle" once The 35 is chosen, and valid applications become Circle
  members instantly (welcome email sent) with no clicks. Leave it off during the
  selection window to review every application by hand.
* New: spam protection on the application form -- an invisible honeypot field
  plus a too-fast-submit timing trap. Bot submissions are silently dropped, so
  they never become members (important with auto-accept on). No configuration
  and no third-party service needed.
* New: branded HTML email design applied to every programme email (welcome,
  promotion, password reset, application received) -- logo, heading, brand
  colours and a real button. All editable under Settings -> Email design. The
  secure "Set your password" button is now added automatically.
* New: an "application received" email sent the moment someone applies (when
  applications are held for manual review), editable in Settings.

= 1.0.21 =
* New: every shortcode now has a matching Elementor widget. Added three new
  widgets with full, scoped Style tabs -- "Founding Faces Application Form" and
  "Founding Faces Status Lookup" (form box, labels, fields, hints, submit
  button with hover, and success/error messages), and "Founding Faces Account"
  (page, title, standing box, section blocks, secondary buttons, plus the shared
  form controls). The Account widget shows a styling sample in the Elementor
  editor. Shared form controls live in a single trait so the two form widgets
  stay consistent. The shortcodes still work unchanged.

= 1.0.20 =
* New: the Member Archive header's group pill ("The 35" / "The Circle") now has
  full styling controls -- border, corner radius, padding and margin -- on top
  of the existing typography, colour and background.

= 1.0.19 =
* Fix: removed the empty gap that appeared under the Member Archive header's
  background colour. The subheading paragraph's default bottom margin was
  collapsing through the header's bottom edge; it is now zeroed so the
  background ends flush with the content.

= 1.0.18 =
* New: per-menu-item visibility. Appearance -> Menus now has a "Founding Faces
  visibility" dropdown on each item (Everyone / Logged-out / All members / The
  35 / The Circle); items the viewer can't see are removed from the menu on the
  front end (a hidden parent hides its children). Admins see the full menu.

= 1.0.17 =
* Change: header has no bottom gap by default (removed the residual margin).
  A Content toggle "Line under header" (default Remove) turns the divider on;
  its thickness, colour and spacing controls appear only when it is on.

= 1.0.16 =
* Change: Style-tab controls now match the selected Section, pick "Header" and
  you only see header styles; pick a list section and you see its styles; "Full
  record" shows everything. Votes-only, feedback-only and link controls appear
  only when relevant.

= 1.0.15 =
* Change: the header subheading is now an editable text field (blank hides it),
  replacing the show/hide toggle; the matching style control is labelled
  "Subheading".

= 1.0.14 =
* New: "Line under header" controls (thickness, colour, spacing) so a divider
  can be added and styled in the widget. Off by default.

= 1.0.13 =
* Change: the date now sits as a small right-hand column at the bottom of each
  item, instead of on its own row (no more big gap under the left column).
* Change: removed the default line under the number & group header; added a
  "Show intro line under header" toggle (off by default).
* Change: feedback items redesigned, the product/where-it's-for is a linked
  heading with the date on the right, and the member's feedback text runs full
  width beneath (supports long text). New "Feedback text" style controls.
  (Feedback text is supplied via the ff_feedback_text filter by the feedback-
  capture feature, added later.)

= 1.0.12 =
* Change: the four activity widgets are replaced by ONE "Founding Faces Member
  Archive" widget with a Section selector (Full record / Header / Votes / Notes
  / Feedback), drop it multiple times to build any layout.
* New: a full Style tab, typography, colour, background, padding, margin,
  border and radius for the header, section headings, section box, items, and
  item text (title / sub text / date), plus note-link colours.
* New: notes in "Notes you've read" now link to the note's own page (toggle).
* If you placed the old My Activity / My Votes / My Notes / My Feedback widgets,
  re-add them as the Member Archive widget.

= 1.0.11 =
* New: the member-activity widgets (My Activity / My Votes / My Notes / My
  Feedback) show on-brand sample data in the Elementor editor, so they can be
  styled before there are any members. The live front end still shows each
  member their own real data (or the login prompt).

= 1.0.10 =
* New: "Note, First image" dynamic tag (single image) for the Elementor Image
  widget. The existing "Note, Image gallery" tag is for gallery/carousel
  widgets; a single Image widget needs this single-image tag.

= 1.0.9 =
* New: member-activity Elementor widgets, "My Activity" (with section toggles
  and editable headings), plus "My Votes", "My Notes Read" and "My Feedback".
  Each reads only the signed-in member's own data; admins see a placeholder
  when building.
* New: "Member, My number" and "Member, My group" dynamic tags, for designing
  the activity header freely.
* New: notes now have a single URL (slug /note/), so Elementor Theme Builder
  can target them with a Single template and display conditions. The single
  view is gated server-side (wrong viewers are redirected before render), notes
  stay out of REST and the sitemap, and loop gating is unchanged. Rewrite rules
  are flushed once automatically.

= 1.0.8 =
* New: Elementor dynamic tags in a "Founding Faces" group, Note Stage, Trial
  number, Date, Audience, Product name, and Image gallery. Use them in an
  Elementor (Pro) Loop Item to design the note card visually: click a widget's
  dynamic (database) icon and pick the field. Reads the note being looped.

= 1.0.7 =
* New: JetEngine integration. Note meta is available to JetEngine Dynamic Field
  widgets via the "Post Meta" source (keys: ff_note_product, ff_note_date,
  ff_note_trial, ff_note_stage, ff_note_gallery, ff_note_audience), plus
  Founding Faces callbacks in the Dynamic Field Callback dropdown to render a
  stage label/badge, the audience label, the product name, and the image
  gallery. 35-only notes stay gated in JetEngine listings (see 1.0.4).

= 1.0.6 =
* Change (map): removed the "Leaflet" attribution prefix (not legally required).
  The OpenStreetMap / CARTO data attribution remains, as it is required.

= 1.0.5 =
* Fix (map): test members now appear on the map (they exist to exercise the
  whole flow, map included, and are cleared by the reset before launch). Only
  the external email sync still excludes test accounts.
* New: the Privacy & Tools members table shows each member's postcode, so it's
  clear where a member sits on the map.

= 1.0.4 =
* Fix (map): the tile URL setting no longer strips Leaflet's {z}/{x}/{y}
  placeholders when saved. esc_url_raw was removing the curly braces, which
  broke tile loading and left the map grey after any settings save. The map
  also falls back to the working default if a stored tile URL looks broken.
* New: query-level gating for notes. 35-only notes are now excluded at the
  query source for anyone who isn't in The 35, so a JetEngine Listing Grid,
  an Elementor Pro Loop, or any WP_Query over ff_note stays gated with no
  extra work. Admins and The 35 still see everything.

= 1.0.3 =
* New: native Elementor widgets for the note display, Founding Faces Notes
  (notes by product, stage filter), Single Note, Product Header, and Home. The
  [ff_note]/[ff_notes]/[ff_product_header]/[ff_home] shortcodes still work.
* Change: administrators can now preview members-area content (notes, home) on
  the front end and in the Elementor editor, so pages can be built.

= 1.0.2 =
* Fix: when there are no members with postcodes yet, the map now frames the
  whole of Australia instead of sitting zoomed in on the empty centre.

= 1.0.1 =
* Fix: the Polls admin menu now registers reliably (where polls are created).
* Fix: the members map initialises correctly inside the Elementor editor and
  when the widget is added live.
* Change: the anonymous members map now renders for everyone (it exposes no
  personal data); restrict it with the Elementor "Show to" control or page
  access if desired.
* New: page-level access control, a "Founding Faces Access" box on every Page
  and Post (Public / All members / The 35 / The Circle) that redirects
  unauthorised visitors, with a restricted-page redirect setting.

= 1.0.0 =
* Stage 1: foundation and data layer.
* Stage 2: front-end application form and logged-out status lookup.
* Stage 3: admin moderation queue, member creation, numbering, resend.
* Stage 4: templated welcome emails, secure set-password token, login screens.
* Stage 5: email-connector interface and Campaign Monitor add-on (consent-gated).
* Stage 6: structured notes, per-note gating, Elementor visibility condition.
* Stage 7: designed-once note template, display components, hybrid home screen.
* Stage 8: interactive poll widget, aggregate results, admin who-voted view.
* Stage 9: personal history page reading only the member's own spine rows.
* Stage 10: anonymous members map (bundled postcodes, Leaflet, postcode-only).
* Stage 11: account settings, consent write-back, self-service export/delete.
* Stage 12: privacy admin tools, consent audit, guarded test-mode reset.
* Stage 13: Klaviyo add-on (group as tag + property), consent-gated.
* Stage 14: members-map Elementor widget; connectors split into add-on plugins.
